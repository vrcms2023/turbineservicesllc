import{e as Y,af as z,c as G,u as S,r,j as e,A as W,aL as q,T as $,L as w,g as L,R as M,M as D,b as J,U as K,V as X,aN as Z,W as Q,p as ee,ap as se}from"./index-KkEaZk_x.js";import{D as ae}from"./DeleteDialog-Bx6G4tYg.js";import{N as te}from"./index-DivwJYVl.js";import{D as ne,C as ie,P as oe}from"./dnd.esm-MbzDj5Vw.js";import{S as re}from"./SkeltonNews-D79ATcj0.js";const le=Y.div`
  .card {
    min-height: 380px;
    background-color: ${({theme:s})=>s.newsCardBg};
    color: ${({theme:s})=>s.newsCardTextColor};
    margin-bottom: 30px;
    border-radius: 8px;
    border: 1px solid ${({theme:s})=>s.grayddd};
    overflow: hidden;

    .ql-editor {
      padding: 0 !important;
    }

    .cardInfo {
      h5 {
        font-size: 1.1rem !important;
        color: ${({theme:s})=>s.gray444};
      }
      .newsDate {
        color: ${({theme:s})=>s.clientSecondaryColor};
      }

      a {
        font-size: .9rem
      }
    }

    .title {
      color: ${({theme:s})=>s.newsCardTitleColor};
    }

    img {
      // height: 160px;
      // width: 100%;
      // object-fit: cover;
      // object-position: bottom;
    }

    .card-body {
      // a {
      //     color:${({theme:s})=>s.primaryColor} !important;

      //     &:hover {
      //         color:${({theme:s})=>s.secondaryColor} !important;
      //     }
      // }
    }
  }

  .homeNews img {
    height: 240px;
    width: 100%;
    object-fit: cover;
  }
  .adminView {
    img {
      width: 80px !important;
      height: 80px;
    }

    .moreLink {
      font-size: .9rem
    }
  }
`,we=({addNewsState:s,news:l,setNews:c,setResponseData:f,pagetype:m,searchQuery:n,setNewsEditState:x})=>{const d=z(),N={news:!1},{isLoading:u}=G(t=>t.loader),{isAdmin:k,hasPermission:I}=S(),[g,_]=r.useState(N),[b,E]=r.useState(!1),[T,C]=r.useState({}),[p,P]=r.useState({}),[F,y]=r.useState(!1),[R,v]=r.useState(!1),A=(t,a,i)=>{C(i),_(o=>({...o,[t]:a})),E(!b),x(!a),document.body.style.overflow="hidden"};r.useEffect(()=>{const t=async()=>{try{const a=await J.get("/appNews/clientAppNews/");(a==null?void 0:a.status)===200&&(m==="home"?c(a==null?void 0:a.data):f(a==null?void 0:a.data))}catch{console.log("unable to access ulr because of server is down")}};(g.news||!s)&&!n&&t()},[g.news,s,m,n]);const U=(t,a)=>{const i=async()=>{if((await se.delete(`appNews/updateAppNews/${t}/`)).status===204){const j=l.filter(h=>h.id!==t);c(j)}};Q.confirmAlert({customUI:({onClose:o})=>e.jsx(ae,{onClose:o,callback:i,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:a})," News?"]})})})},B=t=>{P(t),y(!0),v(!0)},H=()=>{y(!1),v(!1)},O=async t=>{const{source:a,destination:i}=t;if(!i)return!0;const o=K(l,a.index,i.index),j=X(o,"news_position"),h=await V(j);h.length>0&&c(h)},V=async t=>{var a;try{let i=await ee.put("/appNews/updateNewsIndex/",t);if((a=i==null?void 0:i.data)!=null&&a.appNews)return i.data.appNews}catch{console.log("unable to save news position")}};return e.jsxs(e.Fragment,{children:[u?e.jsx("div",{className:"row",children:[1,2,3,4].map((t,a)=>e.jsx("div",{className:"col-md-6 col-lg-3 mb-4 mb-lg-0",children:e.jsx(re,{})},a))}):"",e.jsx(ne,{onDragEnd:O,children:e.jsx(ie,{droppableId:"NewsList",id:"newsList",children:(t,a)=>e.jsxs("div",{className:"row",ref:t.innerRef,...t.droppableProps,children:[l.length>0?l.map((i,o)=>e.jsx(ce,{item:i,index:o,handleModel:B,DeleteNews:U,editHandler:A},i.id)):e.jsx("div",{className:"text-center",children:k&&I?e.jsx(e.Fragment,{children:d.pathname==="/news"?e.jsx("p",{className:"text-center fs-6",children:"Please add news items"}):e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"text-center fs-6",children:"Currently there are no news items found."}),e.jsx(W,{AncherLabel:"Go To News",Ancherpath:"/news",AncherClass:"btn btn-secondary d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})]})}):e.jsx("p",{className:"text-center fs-6",children:!u&&"Currently there are no news items found."})}),t.placeholder]})})}),g.news&&e.jsx("div",{className:"adminEditTestmonial  selected",children:e.jsx(te,{editHandler:A,editCarousel:T,setEditCarousel:C,componentType:"news",popupTitle:"Edit News",imageGetURL:"appNews/createAppNews/",imagePostURL:"appNews/createAppNews/",imageUpdateURL:"appNews/updateAppNews/",imageDeleteURL:"appNews/updateAppNews/",imageLabel:"Add News Image",showDescription:!1,showExtraFormFields:q()})}),F?e.jsx("div",{className:"newsModel ",children:e.jsxs("div",{className:"newsModalWrapper p-4 bg-white shadow-lg",children:[e.jsxs("div",{className:"d-flex justify-content-between align-items-center gap-4 mb-1 pb-2 border-bottom",children:[e.jsx($,{title:p.news_title,cssClass:"fw-medium"}),e.jsx(w,{onClick:H,className:"text-secondary ",children:e.jsx("i",{className:"fa fa-times fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"my-3 newsDetails",children:[e.jsx("img",{className:"w-100 mb-3",style:{height:"240px",objectFit:"cover"},src:L(p.path),alt:p.news_title}),p.news_description?e.jsx(M,{data:p.news_description,className:"",showMorelink:!1}):"update new description"]})]})}):"",R&&e.jsx(D,{}),b&&e.jsx(D,{})]})},ce=({item:s,index:l,handleModel:c,DeleteNews:f,editHandler:m})=>{const{isAdmin:n,hasPermission:x}=S();return e.jsx(oe,{isDragDisabled:!n,index:l,draggableId:s.id,id:s.id,children:d=>e.jsx("div",{className:`${n?"col-12":"col-sm-6 col-lg-3 px-4"} image`,ref:d.innerRef,...d.draggableProps,children:e.jsx("div",{className:`col-md-12 col-lg-12 ${n?"px-3":""}`,children:e.jsx(le,{children:e.jsx("div",{className:`card homeNews ${n?"border-0 adminView mb-0":""}`,style:{minHeight:n?"auto":""},children:e.jsxs("div",{className:`${n?"d-flex align-items-center p-2 px-3 mb-3 border rounded":""} `,children:[!n&&e.jsx("img",{src:L(s.path),className:"img-fluid",alt:s.alternitivetext}),n&&x?e.jsx("i",{className:"fa fa-bars text-secondary","aria-hidden":"true",...d.dragHandleProps}):"",e.jsxs("div",{className:"w-100",style:{display:"flex",justifyContent:"space-between"},children:[e.jsxs("div",{className:`${n?"px-3 d-flex align-items-center gap-3":"cardInfo p-3"}`,children:[e.jsx($,{title:s.news_title?s.news_title:"Update news Title",cssClass:`lineClamp lc2 fs-6 ${n&&"border-0"}`,subTitleClassess:""}),!n&&e.jsx("small",{className:"newsDate d-block mb-3",children:Z(s.created_at).format("MMM DD, YYYY")}),!n&&e.jsx("div",{className:`card-text  ${n?"mb-0":"mb-2"}`,children:s.news_description?e.jsx(M,{data:s==null?void 0:s.news_description,className:`lineClamp ${n?"lc1":"lc2"}`,showMorelink:!1}):"update new description"}),e.jsx(w,{className:"moreLink",onClick:()=>c(s),children:"More.."})]}),n&&x&&e.jsxs("div",{className:"d-flex justify-content-end gap-2",children:[e.jsx(w,{onClick:()=>m("news",!0,s),className:" p-2",children:e.jsx("i",{className:"fa fa-pencil fs-5 text-warning","aria-hidden":"true"})}),e.jsx(w,{onClick:N=>f(s.id,s.news_title),className:"p-2",children:e.jsx("i",{className:"fa fa-trash-o fs-5 text-danger","aria-hidden":"true"})})]})]})]})})})},s.id)})},s.id)};export{we as H};
