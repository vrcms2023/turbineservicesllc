import{r,f as V,A as X,q as Y,W as R,a0 as T,o as q,j as e,T as M,B as z,L as C,a1 as Z,w as $,y as E,i as O,a2 as G,k as ee,e as se,a3 as ae,z as te,a as ie,h as re,b as ne,a4 as ce,a5 as le,E as J,R as oe,d as de,M as ue}from"./index-CFMgf3GR.js";import{l as K}from"./DeleteDialog-DYq_Tv7r.js";import{B as pe,I as me}from"./index-DEOmiT_T.js";import{D as Q}from"./DeleteDialog-C3cfI3IF.js";import{E as ge}from"./Error-H8Ud19OW.js";import{g as fe,d as he}from"./menuUtil-Bs60CYql.js";import{N as ve}from"./index-C1W97hLs.js";import{i as W,g as xe,h as be}from"./dynamicFormFields-p6VsA-z_.js";import"./FileUpload-BH0pK46L.js";import"./SkeletonImage-Drz9HbZA.js";const Se=({setSelectedServiceProject:l,selectedServiceProject:x,pageType:g})=>{const[o,c]=r.useState(""),[k,b]=r.useState(""),[L,s]=r.useState([]),[n,N]=r.useState(""),[j,U]=r.useState(""),_=r.useRef(!0),[F,y]=r.useState(!1),{serviceMenu:u,serviceerror:P}=V(a=>a.serviceMenu),{menuList:S}=V(a=>a.auth),d=r.useRef(null),f=X(),H=Y(),w=a=>{b(""),c(a.target.value)},i=a=>{O(a),l(a)};r.useEffect(()=>{U(R("userName"))},[]);async function p(a){if(o===""){b("Please Enter Service  name");return}let t="",h={services_page_title:o,created_by:j,pageType:g,publish:!!n.publish};try{if(n!=null&&n.id){const B=Z.cloneDeep(n);h.id=n.id,h.updated_by=j,t=await $.put(`/services/updateService/${n.id}/`,h),A(t.data.services,!0,n.services_page_title),c(""),N({})}else t=await $.post("/services/createService/",h),A(t.data.services,!1,"");(t==null?void 0:t.status)===201||(t==null?void 0:t.status)===200?(E.success(`${o} service is created `),c(""),f(T()),l(t.data.services)):b(t.data.message)}catch{b(`${o} is already register`),E.error(`${o} is already register`)}}r.useEffect(()=>{(u==null?void 0:u.length)===0&&_.current?(_.current=!1,f(T())):u&&s(u),(u==null?void 0:u.length)===0&&(q("pageLoadServiceID"),q("pageLoadServiceName"))},[u]);const m=async a=>{try{let t=await $.patch(`/services/publishService/${a.id}/`,{publish:!a.publish});if(t.status===200){let h=t.data.services;E.success(`Service ${h.publish?"published":"un published"} successfully`),l(t.data.services),f(T())}}catch{console.log("unable to publish the services")}},v=a=>{D(),a.id;const t=a.services_page_title,h=async()=>{(await $.delete(`/services/updateService/${a.id}/`)).status===204&&(await he(S,a),f(T()),f(G()),E.success(`${t} is deleted`))};K.confirmAlert({customUI:({onClose:B})=>e.jsx(Q,{onClose:B,callback:h,message:`deleting the ${t} Service?`})})},I=a=>{c(a==null?void 0:a.services_page_title),N(a),y(!0),d.current&&d.current.focus()},D=()=>{c(""),N({}),y(!1)},A=async(a,t,h)=>{await fe(S,H,a,t,h),f(G())};return e.jsxs("div",{className:"pb-3 border border-0",children:[e.jsx(M,{title:"Create New Service Page",cssClass:"p-3 fs-6 text-dark"}),e.jsx("hr",{className:"m-0 mb-5"}),e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row",children:[k?e.jsx(ge,{children:k}):"",e.jsxs("div",{className:`col-md-6 pb-2 pb-md-0 
          d-flex flex-column justify-content-start align-items-center 
          text-center 
          addPageForm`,children:[e.jsx("input",{type:"text",className:`form-control py-4 text-center fs-4  ${F?"border border-warning text-warning":""}`,name:"services_page_title",id:"",value:o,placeholder:"Add Service Name",onChange:w,ref:d}),e.jsxs("div",{className:"d-flex gap-2",children:[e.jsx(z,{type:"submit",cssClass:"btn btn-secondary mt-3",handlerChange:p,label:n!=null&&n.id?"Change Name":"Save"}),n!=null&&n.id?e.jsx(z,{cssClass:"btn btn-primary mt-3",handlerChange:D,label:"Cancel"}):""]})]}),e.jsx("div",{className:"col-md-6 servicePageLinks",children:e.jsx("ul",{children:L&&L.map(a=>e.jsxs("li",{className:`d-flex justify-content-between align-items-center p-1 px-3
                     ${F&&a.id===(n==null?void 0:n.id)?"border border-warning":""} 
              ${a.id===(x==null?void 0:x.id)?"border border-1 border-info shadow-md":""}`,children:[e.jsx("div",{className:"w-50",children:e.jsxs(C,{onClick:t=>i(a),className:"text-dark pageTitle",children:[a.services_page_title," "]})}),e.jsxs("div",{className:"w-50 text-end",children:[e.jsx(C,{onClick:()=>m(a),title:a.publish?"Page Published":"Page Not Published",children:a.publish?e.jsx("span",{className:"text-success fs-5 fw-bold",children:"P"}):e.jsx("span",{className:"fs-5 fw-bold notPublished",children:"P"})}),e.jsxs(C,{onClick:()=>I(a),children:[" ",e.jsx("i",{className:"fa fa-pencil text-warning fs-5 mx-3","aria-hidden":"true"})]}),e.jsxs(C,{onClick:()=>v(a),children:[" ",e.jsx("i",{className:"fa fa-trash-o text-danger fs-5","aria-hidden":"true"})]})]})]},a.id))})})]})})]})},we=ee.div`
    background-color: ${({theme:l})=>l.white};

    .services {
      ul, ol {
        margin: 40px 25px;

        li {
            padding: 15px;
          }
      }
    }
      
      .services ul 
      
      .normalCSS,
      .flipCSS {
      }
      
      .flipCSS {
        flex-direction: row-reverse;
      }
      
      .servicesPage {
        ul, ol {
            margin: 15px 10px;

            li {
                border-bottom: 1px solid ${({theme:l})=>l.lightgray};
                padding: 12px 7px;
              }
        }

        img {
            object-fit: cover;
            object-position: center;
            width: 100%;
            // height: 100%;
        }
      }
      
      
      
      .servicePageLinks {

        // width: 600px; 
        // margin: 0 auto;
        height: 120px;
        overflow-y: scroll;
}
        
        li {
            cursor: pointer;

            span.notPublished {
              color: #ccc !important;
            }
          }

        .pageTitle {
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
            overflow: hidden;
            // height: 20px;
          }
      }
      
      .addPageForm {
        // background-color: ${({theme:l})=>l.teritoryColor};
        // width: 600px; 
        // margin: 0 auto;
      }

      .servicePageLinks {
        background-color: ${({theme:l})=>l.white};
      }

      
`,Ie=()=>{const l={addSection:!1,editSection:!1,banner:!1,briefIntro:!1},x="services",{isAdmin:g,hasPermission:o}=se(),[c,k]=r.useState(l),[b,L]=r.useState(!1),[s,n]=r.useState({}),[N,j]=r.useState([]),[U,_]=r.useState(),[F,y]=r.useState({});let{uid:u}=ae();const P=te(),S=R("pageLoadServiceID"),d=R("pageLoadServiceName");r.useEffect(()=>{const i=document.getElementById("ServicesnavbarDropdown");i&&i.classList.add("active")}),r.useEffect(()=>{S&&d&&f(S),_(d),n({id:S,services_page_title:d})},[u,S]),r.useEffect(()=>{ie()},[]),r.useEffect(()=>{s!=null&&s.id&&(y({serviceID:s?s==null?void 0:s.id:"",services_page_title:s?s==null?void 0:s.services_page_title:""}),_(re(s==null?void 0:s.services_page_title)),f(s.id))},[s]);const f=async i=>{if(!i&&!R("access")){P("/");return}try{let p=await ne.get(`/services/getSelectedClientService/${i}/`);if(j(ce(p.data.servicesFeatures)),window.history.replaceState&&g){const m=`${le()}/services/${d}/`;window.history.pushState({},null,m)}}catch{console.log("Unable to get the intro")}},H=i=>{const p=i.id,m=i.feature_title,v=async()=>{if((await $.delete(`/services/updateFeatureService/${p}/`)).status===204){const D=N.filter(A=>A.id!==p);j(D),E.success(`${m} is deleted`)}};K.confirmAlert({customUI:({onClose:I})=>e.jsx(Q,{onClose:I,callback:v,message:`deleting the ${m} Service?`})})};r.useEffect(()=>{!c.editSection&&!c.addSection&&(s==null?void 0:s.id)!==void 0&&f(s.id)},[c.editSection,c.addSection]);const w=(i,p,m)=>{if(k(v=>({...v,[i]:p})),L(!b),m!=null&&m.id){let v=m;v.services_page_title=s==null?void 0:s.services_page_title,y(v)}document.body.style.overflow="hidden"};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[g&&o&&e.jsx(J,{editHandler:()=>w("banner",!0)}),e.jsx(pe,{getBannerAPIURL:`banner/clientBannerIntro/${x}-${d}-banner/`,bannerState:c.banner,pageLoadServiceName:d})]}),c.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(me,{editHandler:w,componentType:"banner",popupTitle:`Service ${d?"-"+d:""} Banner`,pageType:`${x}-${d}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:xe(`${x}-${U}-banner`),dimensions:W("banner")})}),e.jsxs(we,{children:[g&&o&&e.jsx(Se,{setSelectedServiceProject:n,selectedServiceProject:s,pageType:"service"}),e.jsx("div",{className:g&&o?"container-fluid my-md-3 servicesPage":"container my-md-3 servicesPage",id:"servicesPage",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12",children:[g&&o&&(s==null?void 0:s.id)&&e.jsxs("div",{className:"d-flex justify-content-center align-items-center my-4 p-2 border border-info",children:[e.jsxs("span",{className:"mx-2 text-dark",children:[" ","Add new section in",e.jsx("span",{className:"text-dark fw-bold mx-1",children:s.services_page_title}),"page"]}),e.jsx("button",{type:"submit",className:"btn btn-outline px-3",onClick:()=>w("addSection",!0),children:e.jsx("i",{className:"fa fa-plus","aria-hidden":"true"})})]}),c.editSection||c.addSection?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(ve,{editHandler:w,category:"services",editCarousel:F,setEditCarousel:y,componentType:`${c.editSection?"editSection":"addSection"}`,imageGetURL:"services/createServiceFeatures/",imagePostURL:"services/createServiceFeatures/",imageUpdateURL:"services/updateFeatureService/",imageDeleteURL:"services/updateFeatureService/",imageLabel:"Add Service Banner",showDescription:!1,showExtraFormFields:be(s?s==null?void 0:s.id:"",s?s==null?void 0:s.services_page_title:""),dimensions:W("addService")})}):"",e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-12 col-md-8"})}),N.map((i,p)=>e.jsxs("div",{className:`row my-5 ${g?"border border-warning mb-3 position-relative":""} ${p%2===0?"normalCSS":"flipCSS"}`,children:[g&&o&&e.jsxs(e.Fragment,{children:[e.jsx(J,{editHandler:()=>w("editSection",!0,i)}),e.jsx(C,{className:"deleteSection",onClick:()=>H(i),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"col-md-8 px-5",children:[e.jsx(M,{title:i.feature_title?i.feature_title:"Update Feature title",cssClass:"fs-1 fw-bold mt-3 mb-1"}),e.jsx(M,{title:i.feature_sub_title?i.feature_sub_title:"Update Feature sub title",cssClass:"fs-5 text-secondary mb-2"}),e.jsx(oe,{data:i.feature_description,className:""})]}),e.jsx("div",{className:"col-md-4",children:e.jsx("img",{src:de(i.path),alt:""})})]},i.id))]})})})]}),b&&e.jsx(ue,{})]})};export{Ie as default};
