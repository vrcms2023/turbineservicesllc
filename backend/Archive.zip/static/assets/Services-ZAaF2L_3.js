import{r as i,c as G,v as ce,af as le,t as de,J as H,ag as X,h as ue,ah as R,ai as ae,j as e,T as Z,m as fe,B as te,A as xe,L as z,p as T,y as U,W as pe,aj as ie,e as ve,u as be,ak as Se,s as re,a as we,al as ye,b as Ne,am as _e,_ as je,E as ne,I as Ce,a0 as oe,d as Le,an as ke,R as $e,g as Ee,M as Fe,a6 as Ie,a7 as Ae}from"./index-KkEaZk_x.js";import{B as De}from"./index-D-Sl_dAm.js";import{D as ge}from"./DeleteDialog-Bx6G4tYg.js";import{g as Be,d as Re}from"./menuUtil-CwDo7gLp.js";import{N as He}from"./index-DivwJYVl.js";import{S as Te}from"./ShowHideToggle-DRXWoIR0.js";import"./Styled-PageBanner-BV1wktGo.js";const Ue=({setSelectedServiceProject:c,selectedServiceProject:S,pageType:f,isNewServiceCreated:m})=>{const[h,M]=i.useState(!1),[N,K]=i.useState(!1),s=i.useRef(null),[$,E]=i.useState(86),[F,O]=i.useState(!0),[x,_]=i.useState(""),[C,I]=i.useState(""),[A,w]=i.useState([]),[o,j]=i.useState(""),[L,ee]=i.useState(""),D=i.useRef(!0),[V,y]=i.useState(!1),{serviceMenu:n,serviceerror:se}=G(a=>a.serviceMenu),{menuList:P,menuRawList:me}=G(a=>a.auth),W=i.useRef(null),v=ce(),Q=le(),B=de(),q=a=>{I(""),_(a.target.value)},J=a=>{m.current=!1,B(a.page_url,{replace:!0})};i.useEffect(()=>{ee(H("userName"))},[]),i.useEffect(()=>{if(n.length>0){let a=X.filter(n,d=>{var p;return((p=d==null?void 0:d.page_url)==null?void 0:p.toLowerCase())!=="/services/addservices"});const r=ue(a,"service_postion");w(r)}else w(n)},[n]);async function Y(a){if(x===""){I("Please Enter Service  name");return}let r="",d={services_page_title:x,created_by:L,pageType:f,publish:!!(o!=null&&o.publish)};try{if(o!=null&&o.id){const p=X.cloneDeep(o);d.id=o.id,d.updated_by=L,d.page_url=o.page_url,r=await T.put(`/services/updateService/${o.id}/`,d),b(r.data.services,!0,o.services_page_title),_(""),j({})}else{const p=n[0],he=Math.floor(parseInt(p==null?void 0:p.service_postion)/10);d.service_postion=he*10+n.length+1,d.page_url=`/services/${x.replace(/\s/g,"").toLowerCase()}`,r=await T.post("/services/createService/",d),b(r.data.services,!1,"")}if((r==null?void 0:r.status)===201||(r==null?void 0:r.status)===200){const p=r.data.services;U.success(`${x} service is created `),_(""),v(R()),m.current=!0,c(p),B(p.page_url,{replace:!0})}else I(r.data.message)}catch{I(`${x} is already register`),U.error(`${x} is already register`)}}i.useEffect(()=>{(n==null?void 0:n.length)===0&&D.current&&(D.current=!1,v(R())),(n==null?void 0:n.length)===0&&(ae("pageLoadServiceID"),ae("pageLoadServiceName"))},[n]);const t=async a=>{try{let r=await T.patch(`/services/publishService/${a.id}/`,{publish:!a.publish});if(r.status===200){let d=r.data.services;U.success(`Service ${d.publish?"published":"un published"} successfully`),c(r.data.services),v(R())}}catch{console.log("unable to publish the services")}},u=a=>{g(),a.id;const r=a.services_page_title,d=async()=>{(await T.delete(`/services/updateService/${a.id}/`)).status===204&&(await Re(a.menu_ID),v(R()),v(ie()),U.success(`${r} is deleted`))};pe.confirmAlert({customUI:({onClose:p})=>e.jsx(ge,{onClose:p,callback:d,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:r})," Service?"]})})})},l=a=>{_(a==null?void 0:a.services_page_title),j(a),y(!0),W.current&&W.current.focus()},g=()=>{_(""),j({}),y(!1),m.current=!1},b=async(a,r,d)=>{await Be(P,Q,a,r,d),v(R()),v(ie())},k=()=>{if(s.current){const a=s.current.scrollHeight,r=a>320?320:a;E(N?86:r),K(!N)}};return e.jsxs("div",{className:"pb-3 border border-0",children:[e.jsx(Z,{title:"Create New Service Page",cssClass:"p-3 fs-6 text-dark"}),e.jsx("hr",{className:"m-0 mb-5"}),e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row",children:[C?e.jsx(fe,{children:C}):"",e.jsxs("div",{className:`col-md-6 pb-2 pb-md-0 
          d-flex flex-column justify-content-start align-items-center 
          text-center 
          addPageForm`,children:[e.jsx("input",{type:"text",className:`form-control py-4 text-center fs-4  ${V?"border border-warning text-warning":""}`,name:"services_page_title",id:"",value:x,placeholder:x||h?"":"Add Service Name",onChange:q,onFocus:()=>M(!0),onBlur:()=>M(!1),ref:W}),e.jsxs("div",{className:"d-flex gap-2",children:[e.jsx(te,{type:"submit",cssClass:h||x?"btn btn-primary mt-2":"btn btn-secondary mt-2",handlerChange:Y,label:o!=null&&o.id?"Change Name":"SAVE"}),o!=null&&o.id?e.jsx(te,{cssClass:"btn btn-outline mt-2",handlerChange:g,label:"Cancel"}):""]})]}),e.jsxs("div",{className:"col-md-6 p-0 servicePageLinks",children:[e.jsx("ul",{ref:s,style:{height:`${$}px`,maxHeight:"320px",overflowY:N&&s.current&&s.current.scrollHeight>320&&"auto",transition:"height 0.3s ease"},children:A&&A.map(a=>e.jsxs("li",{className:`d-flex justify-content-between align-items-center py-1
                     ${V&&a.id===(o==null?void 0:o.id)?"border border-warning":""} 
              ${a.id===(S==null?void 0:S.id)?"border border-1 border-info shadow-md":""}`,children:[e.jsx("div",{className:"w-50",children:e.jsx(xe,{Ancherpath:a.page_url,AncherClass:"text-dark pageTitle",AncherLabel:a.services_page_title,handleModel:r=>J(a)})}),e.jsxs("div",{className:"w-50 text-end publishState",children:[e.jsx(z,{onClick:()=>t(a),title:a.publish?"Page Published":"Page Not Published",children:a.publish?e.jsx("span",{className:"text-success fs-5 fw-bold",children:"P"}):e.jsx("span",{className:"fs-5 fw-bold notPublished",children:"P"})}),e.jsxs(z,{onClick:()=>l(a),children:[" ",e.jsx("i",{className:"fa fa-pencil text-warning fs-5 mx-3","aria-hidden":"true"})]}),e.jsxs(z,{onClick:()=>u(a),children:[" ",e.jsx("i",{className:"fa fa-trash-o text-danger fs-5","aria-hidden":"true"})]})]})]},a.id))}),F&&e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-12 text-end",children:e.jsx("a",{href:"#",className:"btn viewAllServices",onClick:()=>k(),children:N?"FEW ONLY":"SHOW ALL.."})})})]})]})})]})},Me=ve.div`
    background-color: ${({theme:c})=>c.white};

    .services {
      ul, ol {
        margin: 40px 25px;

        li {
            padding: 15px;
          }
      }
    }
      
    .normalCSS img, .flipCSS img {
      width: 100%;
      height: 100%;
      // max-height: 280px;
      box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);

    }
      
    .normalCSS, .flipCSS {
      // padding: 24px 10px;
      margin-top: 48px !important;
      border: 1px solid ${({theme:c})=>c.verylightgray} !important;
    }
      
    .flipCSS {
      flex-direction: row-reverse;
      background: #fbfbfb;
      // margin-bottom: 48px;

      @media (max-width: 768px) {
        padding: 0;
        margin: 0px;
      }
    }
      
    .servicesPage {
      ul, ol {
          margin: 15px 10px;

          li {
              border-bottom: 1px solid ${({theme:c})=>c.lightgray};
              padding: 12px 7px;
            }
      }

      img {
          object-fit: cover;
          object-position: center;
          width: 100%;
          // height: 100%;
      }

      p, p span, ol span, ul span {
        color: ${({theme:c})=>c.gray444} !important;
      }

      .quill {
        background: none !important;
      }
      .ql-editor {
        padding: 1rem 0 0 !important;
      }
    }
      .viewAllServices {
        padding: 8px !important;
        font-weight: 600 !important;
        font-size: .8rem;
      }

      ul {
        overflow-y: auto;
        border: 1px solid ${({theme:c})=>c.lightgray};
      }
      li {
        padding: 5px 10px;
        cursor: pointer;
        span.notPublished {
          color: #ccc !important;
        }

        .publishState a {
          text-decoration: none !important;
        }

        &:hover {
          background:  ${({theme:c})=>c.verylightgray};
          

          a {
          text-decoration: none !important;
        }

        }
      }
      
      
      .servicePageLinks {
        background-color: ${({theme:c})=>c.white};
        // width: 600px; 
        // margin: 0 auto;
        // height: 120px;
        // overflow-y: scroll;
      }
        
        li {
            cursor: pointer;

            span.notPublished {
              color: #ccc !important;
            }
          }

        .pageTitle {
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
            overflow: hidden;
            // height: 20px;
          }

      
      .addPageForm {
        // background-color: ${({theme:c})=>c.teritoryColor};
        // width: 600px; 
        // margin: 0 auto;
      }

      
`,Ge=()=>{var B,q,J,Y;const c={addSection:!1,editSection:!1,banner:!1,briefIntro:!1},S="services",{isAdmin:f,hasPermission:m}=be(),[h,M]=i.useState(c),[N,K]=i.useState(!1),[s,$]=i.useState({}),[E,F]=i.useState([]),[O,x]=i.useState(),[_,C]=i.useState({});let{uid:I}=Se();const A=de();H("pageLoadServiceID");const w=H("pageLoadServiceName");H("pageLoadServiceURL");const o=le(),j=i.useRef(!1),{serviceMenu:L,serviceerror:ee}=G(t=>t.serviceMenu);i.useEffect(()=>{var u;const t=o.pathname;if(t&&L.length>0&&!j.current){const l=ue(L,"service_postion"),g=X.filter(l,b=>{var k;return((k=b==null?void 0:b.page_url)==null?void 0:k.toLowerCase())===t})[0];g?(re(g),$(g)):(A((u=l[0])==null?void 0:u.page_url),re(l[0]),$(l[0])),F([])}},[o,L]),i.useEffect(()=>{const t=document.getElementById("ServicesnavbarDropdown");t&&t.classList.add("active")}),i.useEffect(()=>{we()},[]),i.useEffect(()=>{s!=null&&s.id&&(C({serviceID:s?s==null?void 0:s.id:"",services_page_title:s?s==null?void 0:s.services_page_title:""}),x(ye(s==null?void 0:s.services_page_title)),D(s.id))},[s]);const D=async t=>{if(!t&&!H("access")){A("/");return}try{let u=await Ne.get(`/services/getSelectedClientService/${t}/`);const l=_e(u.data.servicesFeatures);F(l)}catch{console.log("Unable to get the intro")}},V=t=>{const u=t.id,l=t.feature_title,g=async()=>{if((await T.delete(`/services/updateFeatureService/${u}/`)).status===204){const k=E.filter(a=>a.id!==u);F(k),U.success(`${l} is deleted`)}};pe.confirmAlert({customUI:({onClose:b})=>e.jsx(ge,{onClose:b,callback:g,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:l})," Service?"]})})})};i.useEffect(()=>{!h.editSection&&!h.addSection&&(s==null?void 0:s.id)!==void 0&&D(s.id)},[h.editSection,h.addSection]);const y=(t,u,l)=>{if(M(g=>({...g,[t]:u})),K(!N),l!=null&&l.id){let g=l;g.services_page_title=s==null?void 0:s.services_page_title,C(g),j.current=!1}document.body.style.overflow="hidden"},[n,se]=i.useState([]),P=ce(),{error:me,success:W,showHideList:v}=G(t=>t.showHide);i.useEffect(()=>{v.length>0&&se(je(v))},[v]);const Q=async(t,u)=>{if(t)P(Ie(t));else{const l={componentName:u.toLowerCase(),pageType:S};P(Ae(l))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(B=n==null?void 0:n.servicebanner)!=null&&B.visibility&&f&&m?"border border-info mb-2":"",children:[f&&m&&e.jsx(Te,{showhideStatus:(q=n==null?void 0:n.servicebanner)==null?void 0:q.visibility,title:"Banner",componentName:"servicebanner",showHideHandler:Q,id:(J=n==null?void 0:n.servicebanner)==null?void 0:J.id}),((Y=n==null?void 0:n.servicebanner)==null?void 0:Y.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[f&&m&&e.jsx(ne,{editHandler:()=>y("banner",!0)}),e.jsx(De,{getBannerAPIURL:`banner/clientBannerIntro/${S}-${w}-banner/`,bannerState:h.banner,pageLoadServiceName:w})]}),h.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Ce,{editHandler:y,componentType:"banner",popupTitle:`Service ${w?"-"+w:""} Banner`,pageType:`${S}-${w}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:Le(`${S}-${O}-banner`),dimensions:oe("banner")})})]})]}),e.jsxs(Me,{children:[f&&m&&e.jsx(Ue,{setSelectedServiceProject:$,selectedServiceProject:s,pageType:"service",isNewServiceCreated:j}),e.jsx("div",{className:f&&m?"container-fluid my-md-3 servicesPage":"container my-md-3 servicesPage",id:"servicesPage",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12",children:[f&&m&&(s==null?void 0:s.id)&&s.page_url!=="/services/addservices"&&e.jsxs("div",{className:"d-flex justify-content-center align-items-center my-4 p-2 border border-info",children:[e.jsxs("span",{className:"mx-2 text-dark",children:[" ","Add new section in",e.jsx("span",{className:"text-dark fw-bold mx-1",children:s.services_page_title}),"page"]}),e.jsx("button",{type:"submit",className:"btn btn-outline px-3",onClick:()=>y("addSection",!0),children:e.jsx("i",{className:"fa fa-plus","aria-hidden":"true"})})]}),h.editSection||h.addSection?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(He,{editHandler:y,category:"services",editCarousel:_,setEditCarousel:C,componentType:`${h.editSection?"editSection":"addSection"}`,imageGetURL:"services/createServiceFeatures/",imagePostURL:"services/createServiceFeatures/",imageUpdateURL:"services/updateFeatureService/",imageDeleteURL:"services/updateFeatureService/",imageLabel:"Add Service Banner",showDescription:!1,showExtraFormFields:ke(s?s==null?void 0:s.id:"",s?s==null?void 0:s.services_page_title:"",s?s==null?void 0:s.page_url:""),dimensions:oe("addService")})}):"",e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-12 col-md-8"})}),s.page_url!=="/services/addservices"&&E.map((t,u)=>e.jsxs("div",{className:`row my-5 ${f?"border border-warning mb-3 position-relative":""} ${u%2===0?"normalCSS":"flipCSS"}`,children:[f&&m&&e.jsxs(e.Fragment,{children:[e.jsx(ne,{editHandler:()=>y("editSection",!0,t)}),e.jsx(z,{className:"deleteSection",onClick:()=>V(t),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"col-md-8 p-4 p-5",children:[t.feature_title&&e.jsx(Z,{title:t.feature_title?t.feature_title:"Update Feature title",cssClass:"fs-3 mb-2 title"}),t.feature_sub_title&&e.jsx(Z,{title:t.feature_sub_title?t.feature_sub_title:"Update Feature sub title",cssClass:"fs-5 text-secondary mb-2"}),t.feature_description&&e.jsx($e,{data:t.feature_description,className:"",showMorelink:!1})]}),e.jsx("div",{className:"col-md-4 px-0",children:e.jsx("img",{src:Ee(t.path),alt:""})})]},t.id))]})})})]}),N&&e.jsx(Fe,{})]})};export{Ge as default};
