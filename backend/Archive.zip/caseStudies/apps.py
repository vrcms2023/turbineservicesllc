from django.apps import AppConfig


class CasestudiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caseStudies'
