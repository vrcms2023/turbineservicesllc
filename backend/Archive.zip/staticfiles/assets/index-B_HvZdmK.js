import{k as w,r as i,W as _,j as a,t as D,a9 as $,T as h,d as E,x as F,b as P}from"./index-BT6f_GGI.js";import{F as z}from"./FileUpload-DrThB9ch.js";import"./DeleteDialog-CLwNYl9P.js";import{S as M}from"./SkeletonImage-DvS_a_VR.js";const K=w.div`
    background-color: ${({theme:e})=>e.transparent};
    padding: 16px 0;

    @media(max-width: 768px) {
      padding-bottom: 0;
    }

  p {
    color: ${({theme:e})=>e.textColor};
  }

  .briefIntro { 
    // margin: 40px 0 0px;

    @media(max-width: 768px) {
      margin: 0px;
    }
  }

  .briefIntro h5 {
    color: ${({theme:e})=>e.gray222};
  }

  .briefIntro h3 {
    font-size: 2.5rem;
    color: ${({theme:e})=>e.briefIntroTitleColor};
  }
`,Q=({editHandler:e,componentType:o,popupTitle:l,pageType:c,category:d="banner",extraFormParamas:m,showDescription:p=!0,showExtraFormFields:x,dimensions:t,imageLabel:r="Add Image",imagePostURL:b="banner/createBannerIntro/",imageGetURL:s="banner/clientBannerIntro/",imageUpdateURL:j="banner/updateBannerIntro/",imageDeleteURL:U="banner/updateBannerIntro/",validTypes:v="image/png,image/jpeg"})=>{const y="a62d7759-a e6b-4e49-a129-1ee208c6789d",[S,T]=i.useState(""),[g,C]=i.useState([]),[G,I]=i.useState(!1),[B,H]=i.useState({id:y}),[N,u]=i.useState({}),[L,k]=i.useState(""),f=()=>{e(o,!1),document.body.style.overflow=""};return i.useEffect(()=>{T(_("userName"))},[]),i.useEffect(()=>{(async()=>{try{const n=await $.get(`${s}${c}/`);(n==null?void 0:n.status)===200&&n.data.imageModel&&(k(n.data.imageModel),u(n.data.imageModel))}catch{console.log("unable to access ulr because of server is down")}})()},[g]),a.jsxs("div",{className:"",children:[a.jsx(D,{closeHandler:f,title:l}),a.jsx("hr",{className:"m-0 text-black"}),a.jsx("div",{className:"container my-3",children:a.jsx("div",{className:"row py-0",children:a.jsx("div",{className:"col-md-12 mb-5 mb-md-0 px-0",children:a.jsx("div",{className:"container px-0 px-md-auto",children:a.jsx(z,{title:r,project:B,updated_by:S,category:d,gallerysetState:C,maxFiles:1,galleryState:g,validTypes:v,descriptionTitle:"Caption",titleTitle:"Title",alternitivetextTitle:"SEO title",saveState:I,showDescription:p,buttonLable:"Save",editImage:N,setEditCarousel:u,imagePostURL:b,imageUpdateURL:j,extraFormParamas:m,showExtraFormFields:x,dimensions:t,closeHandler:f})})})})})]})},A=w.div`
  .pageBanner {
    img {
      object-fit: cover;
      // object-position: center;
      height: 240px;
    }
    .titleCaption {
      position: absolute;
      top: 0;
      bottom: 0px;
      left: 0;
      right: 0;
      background-color: rgba(0, 0, 0, 0.3);
      padding: 10px 100px 40px;

      .title {
        color: ${({theme:e})=>e.pageBannerTitleColor};
        font-family: "PT Sans Narrow", sans-serif;
        font-weight: 700 !important;
        letter-spacing: 0.25rem;
        font-size: 3.5rem !important;
        text-shadow: 0px 4px 0 rgba(0,0,0, .3)
        margin: 0px;
      }
      .subTitle {
        color: ${({theme:e})=>e.pageBannerSubTitleColor};
        font-weight: normal !important;
        font-family: "PT Sans Narrow", sans-serif;
        letter-spacing: .3rem;
        text-transform: uppercase !important;
      }
      .description {
        color: ${({theme:e})=>e.pageBannerTextColor};
      }

      .title,
      .description {
        // width: 50%;
      }
    }

    @media (max-width: 576px) {
      img {
        height: 230px;
      }

      .titleCaption {
        padding: 10px 50px 40px;

        // .title {
        //   overflow: hidden;
        //   display: -webkit-box !important;
        //   -webkit-box-orient: vertical;
        //   -webkit-line-clamp: 2;
        // }

        // .subTitle {
        //   display: none;
        // }

        .title {
          font-size: 2.5rem !important;
        }

        .description {
          width: 100%;
          font-size: 1rem !important;
          overflow: hidden;
          display: -webkit-box !important;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
        }
      }
    }
  }
`,V=({getBannerAPIURL:e,bannerState:o,pageLoadServiceName:l,bannerTitleCss:c="title text-end fs-2",bannerSubTitleCss:d="subTitle text-end fw-normal",bannerDescriptionCss:m="description text-end d-block mt-2 fs-6",imageCss:p="w-100",bannerContainerCss:x="titleCaption d-flex align-items-end justify-content-end flex-column"})=>{const[t,r]=i.useState([]);return i.useEffect(()=>{o||(async()=>{try{const s=await P.get(e);(s==null?void 0:s.status)===200?r(s.data.imageModel):r({})}catch{r({}),console.log("unable to access ulr because of server is down")}})()},[o,l,e]),a.jsx(A,{children:a.jsxs("div",{className:"pageBanner",children:[a.jsxs("div",{className:t.banner_descripiton&&t.banner_title||t.banner_descripiton||t.banner_title?x:"",children:[t.banner_title!==""&&a.jsx(h,{title:t.banner_title,cssClass:c,mainTitleClassess:"fs-1 fw-bold text-white ",subTitleClassess:""}),t.banner_subTitle!==""&&a.jsx(h,{title:t.banner_subTitle,cssClass:d,mainTitleClassess:"fs-6 mb-2 fw-medium text-white "}),t.banner_descripiton!==""&&a.jsx("small",{className:m,children:t.banner_descripiton})]}),t.path?a.jsx("img",{src:t!=null&&t.path?E(t.path):F(),alt:t.alternitivetext,className:p}):a.jsx(M,{})]})})};export{V as B,Q as I,K as a};
