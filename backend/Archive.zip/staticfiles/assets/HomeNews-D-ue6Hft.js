import{k as G,j as e,ad as m,q,f as W,e as $,r as o,T as L,L as f,d as M,R as k,M as S,b as Z,Y as z,Z as J,ae as K,w as X,a9 as Q}from"./index-B1-fbhTW.js";import{l as ee}from"./DeleteDialog-BPXCEzTV.js";import{D as se}from"./DeleteDialog-CxCWxmD0.js";import{N as ae}from"./index-C6Mo69rr.js";import{D as te,C as ne,P as ie}from"./dnd.esm-D8WMKIXB.js";import{m as le}from"./dynamicFormFields-p6VsA-z_.js";import{A as oe}from"./Ancher-_PdOlk3g.js";const re=G.div`
  .card {
    min-height: 380px;
    background-color: ${({theme:s})=>s.newsCardBg};
    color: ${({theme:s})=>s.newsCardTextColor};
    // margin-bottom: 30px;
    // border-radius: 10px;
    // overflow: hidden;
    border: 0px;

    .title {
      color: ${({theme:s})=>s.newsCardTitleColor};
    }

    img {
      // height: 160px;
      // width: 100%;
      // object-fit: cover;
      // object-position: bottom;
    }

    .card-body {
      // a {
      //     color:${({theme:s})=>s.primaryColor} !important;

      //     &:hover {
      //         color:${({theme:s})=>s.secondaryColor} !important;
      //     }
      // }
    }
    
  }
  .adminView {
    img {
      width: 80px !important;
      height: 80px;
    }

    
  }
`,ce=()=>e.jsxs("div",{className:"",children:[e.jsx(m,{classes:"image width-100"}),e.jsx(m,{classes:"title width-100"}),e.jsx(m,{classes:"text width-100"}),e.jsx(m,{classes:"text width-100"}),e.jsx(m,{classes:"text width-100"})]}),ge=({addNewsState:s,news:r,setNews:c,setResponseData:j,pagetype:x,searchQuery:t,setNewsEditState:w})=>{const d=q(),N={news:!1},{isLoading:b}=W(n=>n.loader),{isAdmin:_,hasPermission:T}=$(),[g,E]=o.useState(N),[C,I]=o.useState(!1),[P,v]=o.useState({}),[p,R]=o.useState({}),[F,y]=o.useState(!1),[U,A]=o.useState(!1),D=(n,a,i)=>{v(i),E(l=>({...l,[n]:a})),I(!C),w(!a),document.body.style.overflow="hidden"};o.useEffect(()=>{const n=async()=>{try{const a=await Z.get("/appNews/clientAppNews/");(a==null?void 0:a.status)===200&&(x==="home"?c(a==null?void 0:a.data):j(a==null?void 0:a.data))}catch{console.log("unable to access ulr because of server is down")}};(g.news||!s)&&!t&&n()},[g.news,s,x,t]);const B=(n,a)=>{const i=async()=>{if((await Q.delete(`appNews/updateAppNews/${n}/`)).status===204){const u=r.filter(h=>h.id!==n);c(u)}};ee.confirmAlert({customUI:({onClose:l})=>e.jsx(se,{onClose:l,callback:i,message:`deleting the ${a} News?`})})},H=n=>{R(n),y(!0),A(!0)},Y=()=>{y(!1),A(!1)},O=async n=>{const{source:a,destination:i}=n;if(!i)return!0;const l=z(r,a.index,i.index),u=J(l,"news_position"),h=await V(u);h.length>0&&c(h)},V=async n=>{var a;try{let i=await X.put("/appNews/updateNewsIndex/",n);if((a=i==null?void 0:i.data)!=null&&a.appNews)return i.data.appNews}catch{console.log("unable to save news position")}};return e.jsxs(e.Fragment,{children:[b?e.jsx("div",{className:"row",children:[1,2,3,4].map((n,a)=>e.jsx("div",{className:"col-md-6 col-lg-3 mb-4 mb-lg-0",children:e.jsx(ce,{})},a))}):"",e.jsx(te,{onDragEnd:O,children:e.jsx(ne,{droppableId:"NewsList",id:"newsList",children:(n,a)=>e.jsxs("div",{className:"row",ref:n.innerRef,...n.droppableProps,children:[r.length>0?r.map((i,l)=>e.jsx(de,{item:i,index:l,handleModel:H,DeleteNews:B,editHandler:D},i.id)):e.jsx("div",{className:"text-center",children:_&&T?e.jsx(e.Fragment,{children:d.pathname==="/news"?e.jsx("p",{className:"text-center fs-6",children:"Please add news items"}):e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"text-center fs-6",children:"Currently there are no news items found."}),e.jsx(oe,{AncherLabel:"Go To News",Ancherpath:"/news",AncherClass:"btn btn-secondary d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})]})}):e.jsx("p",{className:"text-center fs-6",children:!b&&"Currently there are no news items found."})}),n.placeholder]})})}),g.news&&e.jsx("div",{className:"adminEditTestmonial  selected",children:e.jsx(ae,{editHandler:D,editCarousel:P,setEditCarousel:v,componentType:"news",popupTitle:"News",imageGetURL:"appNews/createAppNews/",imagePostURL:"appNews/createAppNews/",imageUpdateURL:"appNews/updateAppNews/",imageDeleteURL:"appNews/updateAppNews/",imageLabel:"Add News Image",showDescription:!1,showExtraFormFields:le()})}),F?e.jsx("div",{className:"newsModel ",children:e.jsxs("div",{className:"newsModalWrapper p-4 bg-white shadow-lg",children:[e.jsxs("div",{className:"d-flex justify-content-between align-items-center gap-4 mb-1 pb-2 border-bottom",children:[e.jsx(L,{title:p.news_title,cssClass:"fw-medium"}),e.jsx(f,{onClick:Y,className:"text-secondary ",children:e.jsx("i",{className:"fa fa-times fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"my-3 newsDetails",children:[e.jsx("div",{className:"text-center",children:e.jsx("img",{className:"w-auto mb-3",style:{height:"240px",objectFit:"cover"},src:M(p.path),alt:p.news_title})}),p.news_description?e.jsx(k,{data:p.news_description,className:""}):"update new description"]})]})}):"",U&&e.jsx(S,{}),C&&e.jsx(S,{})]})},de=({item:s,index:r,handleModel:c,DeleteNews:j,editHandler:x})=>{const{isAdmin:t,hasPermission:w}=$();return e.jsx(ie,{isDragDisabled:!t,index:r,draggableId:s.id,id:s.id,children:d=>e.jsx("div",{className:`${t?"col-12":"col-sm-6 col-lg-4 px-2 px-md-4 px-lg-5"} image`,ref:d.innerRef,...d.draggableProps,children:e.jsx("div",{className:`col-md-12 col-lg-12 ${t?"px-3":""}`,children:e.jsx(re,{children:e.jsx("div",{className:`card homeNews ${t?"adminView":""}`,style:{minHeight:t?"auto":""},children:e.jsxs("div",{className:`${t?"d-flex align-items-center p-2 px-3 mb-3 border rounded":""} `,children:[!t&&e.jsx("img",{src:M(s.path),className:"img-fluid rounded-3",alt:s.alternitivetext}),t&&w?e.jsx("i",{className:"fa fa-bars text-secondary","aria-hidden":"true",...d.dragHandleProps}):"",e.jsxs("div",{className:"w-100",style:{display:"flex",justifyContent:"space-between"},children:[e.jsxs("div",{className:`${t?"px-3":"py-3"}`,children:[e.jsx(L,{title:s.news_title?s.news_title:"Update news Title",cssClass:`fs-6 lineClamp lc2 ${!t&&"fw-bold"}`,mainTitleClassess:` fw-medium lh-sm lineClamp lc1 ${t?"fs-6":"fs-5"}`,subTitleClassess:""}),!t&&e.jsx("small",{className:"d-block mb-3",children:K(s.created_at).format("MMM DD, YYYY")}),!t&&e.jsx("div",{className:`card-text  ${t?"mb-0":"mb-2"}`,children:s.news_description?e.jsx(k,{data:s==null?void 0:s.news_description,className:`lineClamp ${t?"lc1":"lc2"}`}):"update new description"}),e.jsx(f,{className:"moreLink",onClick:()=>c(s),children:"More.."})]}),t&&w&&e.jsxs("div",{className:"d-flex justify-content-end gap-2",children:[e.jsx(f,{onClick:()=>x("news",!0,s),className:" p-2",children:e.jsx("i",{className:"fa fa-pencil fs-5 text-warning","aria-hidden":"true"})}),e.jsx(f,{onClick:N=>j(s.id,s.news_title),className:"p-2",children:e.jsx("i",{className:"fa fa-trash-o fs-5 text-danger","aria-hidden":"true"})})]})]})]})})})},s.id)})},s.id)};export{ge as H};
