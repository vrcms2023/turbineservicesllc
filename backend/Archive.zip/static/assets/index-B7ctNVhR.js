import{r as V,j as e,g as dt,T as pe,R as ut,L as fe,u as ft,c as ye,s as kn,E as ce,I as pn,d as mn,M as pt,b as xe,e as me,f as mt,h as De,A as lt,i as Tn,k as ht,l as vt,m as hn,n as Pn,o as Te,B as gt,p as Ce,y as bt,q as _n,t as En,v as yt,w as Mn,x as In,z as Ln,S as vn,C as be,D as we,F as Oe,G as Rn,H as gn,J as Dn,K as zr,O as An,P as Vn,Q as zn,U as Hn,V as Bn,W as Fn,X as bn,Y as Un,a as qn,Z as Wn,_ as Zn,$ as $n,a0 as ge,a1 as Hr,a2 as Kn,a3 as We,a4 as Qn,a5 as Gn,a6 as Xn,a7 as Yn}from"./index-KkEaZk_x.js";import{C as Ze}from"./Carousel-DZW7TTAD.js";import{A as ze}from"./ImgTitleIntoForm-List-D0FE11WN.js";import{A as Jn,a as He}from"./Styled-ABriefAbout-qdeg0EBZ.js";import{H as ei}from"./HomeNews-BIJJPbmE.js";import{B as ti}from"./index-D-Sl_dAm.js";import ri from"./HomeServices-Bxiy0xxi.js";import{D as ni}from"./DynamicCarousel-DlRR4Dcm.js";import{I as Br}from"./Styled-ImageGallery-DjnuXzmH.js";import{P as ii}from"./Product-D_52Bh-N.js";import{S as ie}from"./ShowHideToggle-DRXWoIR0.js";import{D as ai,C as si,P as oi}from"./dnd.esm-MbzDj5Vw.js";import{D as li}from"./DeleteDialog-Bx6G4tYg.js";import{N as ci}from"./NoteComponent-CepPlIts.js";import"./index-DivwJYVl.js";import"./SkeltonNews-D79ATcj0.js";import"./Styled-PageBanner-BV1wktGo.js";const di=({testimonis:a})=>{const[l,h]=V.useState(0);V.useEffect(()=>{if((a==null?void 0:a.length)>1){const m=(a==null?void 0:a.length)-1;l<0&&h(m),l>m&&h(0)}},[l,a]),V.useEffect(()=>{if((a==null?void 0:a.length)>1){let m=setInterval(()=>{h(l+1)},5e3);return()=>{clearInterval(m)}}},[l,a]);const j=a==null?void 0:a.map((m,v)=>{let S="nextSlide";return v===l&&(S="activeSlide"),(v===l-1||l===0&&v===(a==null?void 0:a.length)-1)&&(S="lastSlide"),e.jsxs("div",{className:`${S} article position-absolute`,children:[m.path?e.jsx("img",{src:dt(m.path),className:"rounded-circle my-4 testimonialImg shadow-lg",alt:"User"}):e.jsx("i",{className:"fa fa-user","aria-hidden":"true"}),e.jsx(pe,{title:m.testimonial_title,cssClass:"mb-2 px-3 fs-3 fw-bold text-md-center title"}),e.jsx(ut,{data:m==null?void 0:m.testimonial_description,showMorelink:!1,className:"w-75 m-auto mt-3 mb-5 px-3 px-md-5 fs-6"}),e.jsxs("div",{className:"d-flex justify-content-center gap-5",children:[e.jsxs(fe,{to:"",onClick:()=>h(l+1),children:[" ",e.jsx("i",{className:"fa fa-chevron-left fs-3","aria-hidden":"true"})]}),e.jsxs(fe,{to:"",onClick:()=>h(l-1),children:[" ",e.jsx("i",{className:"fa fa-chevron-right fs-3","aria-hidden":"true"})]})]})]},m.id)});return e.jsx(e.Fragment,{children:j})},Fr="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAfcSURBVHgB7Vy/c9NIFH5xwgwd8V+AEmCGDlNedaajO+jocDquIvwFOB0d0F13TsdVkIoS03HVmZ4QpbsKm+5u8uu+L3lmVutdS7KllZzzN6ORdyVLu5/e27f79u2KLLHEEkv8f7EiNUIURes48Yh4Xl1d5W85OTmJ9ZYRjhgYSU1QGYFKVrvRaLTPzs7urKystOSCvCwY4T8D/Ofz6elpH+l+VaQGJZCkgbAOKv8LKt+WAoFn9nHsygWZsQRCEAJBXBuEPS+atCnoQTJ3wWNfSkapBM5I3CHuj3EegYRztYTURjxDwqjid7I+SKVyp0wiSyEQxEUg4fcMxB3ieIf7BjAUmVXv1q1bLZAbgZw2kjzSSKVE7pSh2oUTCO62ITHPxW8QBjj2UKFeURXiB8M7H+DnU7mw4E7gnV28ckcKRGEEpkkd8j/i6H758qUvJeLmzZu06ts0VK7rtN44Hhb18QohkG0dJOCtOKQuFHGOMkVappZ9DQTGOLaKaBvnJlBV9qXjEo3AMxSyJxXixo0b7DaxSYnsa1q+VzIHVmUOgLznIO+FnU+pQ+F+QuE+ScUYDoeDa9eu7aFMEZK3zWvIu49rMhqNPsqMmJlAJa/ruLTz9evXDgr1j9QEKMsIRP7RbDapcW3zGtvseUiciUBVW1vyqLK/HhwczKUSZQIk9kHWoRq6q+N8JfE7SMytMbnbQDUYH6xskncPKjuQBQDq0NI6JIye1qEvOZCLQLVsfHFkZC8UeWN4SGRd7ubp4jQkByDq7BZEZh5euLVo5BEsM62wlb3OvqzkQOY2UI3GIyt7B23eb7KgQJs3sA0LrXWe9jCTCqvqHljZPVjbLbkE2NjY+GCNoDKrciYV5kjCTLMnz8G5XBJwaCcX3u4xMqtyKoHqknpsvbAUz0ZVoDcbdUy0h5RI1j3tv6kE0p9nZQ1CDc9YgSyVKAL7+/s9+g/NPEfdJzCVQJW+tpkH1X0oAYB3v2Q3g8fm5mYuyzgrqFlmOosUTiUQD+hYL9gLpbogbttIdkKQyE60LYUox9Np//ESqP69RNuHacZgwzS7IhKIRFsKgbbOIDrhJRBkta0HxyF9evTX4RRb2aWTqEM5c2BwPpPou99LINq6hPRBGl9LQLCp4BBRKiAR2DMTPu824SSQIuswHu8kMKoikfM1ZlqNiVONfRLYNhOcR6iq31cFiVrXQyu77brXSSDDLcw0PcxSISqSxITG2Zz8yHdlMlbFTGv8SaUITSLnqs00OIlc9zU8f7ZnsmKpAUKSyIl+Mw1OnJP3E94YDQAamnnwutQtDM7l2CUK9RDho5yZaXy8ph0FNiGBV65cicw0DYjUDAEl0TYkE5Z4gsCjo6PETfjS36WGCEEihCfhA11bW4vse9YkANQxsC3hQBKlaIfv8fFxugRiCBeZafsr5IXO4oUkb4xOAa6whAqPQ45N5JpUWjRA5aRsTBAI852wMpDApswBHZwHHUcTDPctwPlx3Uxo4GcCrk+UNNONRtbAby/QFlGFC1djX3eG5GG2sCMB4FLhWJKFuS41RAjyIHEbZhpGZGIlgItA+6ZIaoaAkmcLT2zfMEGg9rQTJLLAUhOEIo9x2FbWKHasRfE5ExKjD9s7XRVCtnkYUERmmot6XPf5nAmJm1HAllSM0AbDdl/5hrROAh3uK69LOwSqsLZ49s9m2ufS83Wk7ZujqtrBKsjTGUlb6/que50EsrF0zI92JDCq6ufpmpMfoEc+9ixm9A7l8KfMM1NloOJOcmIyHaOznu/GadOaPTNNkQ4Vp6LvmwjmDEGe1jGysvu++70EutQ4S7BNUbDboFDDM0cde9NmJKd6Y2YJtikQr41yBCGPcdP2fDiakd1p/0md67CjNymVqMw9CQCue+M5VEgJ6vqXKfk0Hvv7++1p/0mNkV5fXz80o7Q0hviQ8cVSMr59+xbzkADgkjCcnph5kL6ttPdnmm3zxBBvxDXa/GEeeCx+phm+TB5pjZSyY4jfyiWBLpaMzLysMeCZljlwrVmz2fwXP++P81SV51qoVwdw+Qbq8sTK5vKNTMFUuSbMHarML9WBKu/KAgLkPYb09cw8Og1A3t2sz8g1qeRQZYr/K5p/WTDoUq9ExK0uxM4VA56LQJ3Mtl/AUJAPi0Sib7Eh/J5becP4ci93RZsXoz1ktMJ9I/sqVPsR2sS/cf2z1Biqtm9kMkzjGfp8byQnZlovPBwOPzkWL5PEB3U2LLrej2p71brEReIvZAbMvGKdi5d9K8CR3wKRf9J6Sw3AiDOU6b3HJUfyujIj5tozQUm01Zng3gQPMIr5HmLEMg0cYeCjvsdx23H52aySN0YhcX8a/8KIqMi+VvQ+LXnKNGXbqRHK+7CIMXZhgZPqBn/rcIWfI8Q+VlqOacSdOwjgIO3UauMdE5ubm12cvH5D9rW45oTLJorc+gmnxzRivg8oF/1XtneFrrYqnEBCpbFrLxWzoZsoftQZrzjr1gF8PueqdbqVUw3RtPuLlrrEs6VE6D5WXXuKMAUcDcT8MY6GGkfI6+Y5UdYHhdh2qlQCxyCRlIA0iSwIIyXuVQhHbBACxxirHn52ckplKkganvlOt9UL1v8MSqAJdm61HaPVbOninqyxiPSSD9Qg9XXzxsu/CW0aSCqXWehWn+bqIKrl6Pj4OBZPlNQSSyyxxBLh8R88cXSgocvBFQAAAABJRU5ErkJggg==",ui=({title:a,cssClass:l,linkClass:h,moreLink:j,dimensions:m})=>{const v={homecareers:!1},S="homePageCareer",{isAdmin:N,hasPermission:C}=ft(),[f,O]=V.useState(v),[A,Z]=V.useState(!1),[$,B]=V.useState([]),{serviceMenu:M}=ye(D=>D.serviceMenu),te=(D,F)=>{O(X=>({...X,[D]:F})),Z(!A),document.body.style.overflow="hidden"};return V.useEffect(()=>{const D=async()=>{try{const F=await xe.get(`banner/clientBannerIntro/${S}/`);(F==null?void 0:F.status)===200&&B(F.data.imageModel)}catch{console.log("unable to access ulr because of server is down")}};f.homecareers||D()},[f.homecareers]),e.jsxs("div",{className:"row h-100",children:[e.jsx("div",{className:"d-none col-lg-6 p-0 ABriefImg d-md-flex justify-content-center align-items-center",children:e.jsxs("div",{className:"bg-white text-black m-3 ms-lg-5 p-4 py-5",children:[e.jsx("p",{children:e.jsxs("svg",{width:"246",height:"43",viewBox:"0 0 246 43",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{d:"M43.8336 15.4223L42.6937 11.9186C42.6193 11.6897 42.4059 11.5348 42.1648 11.5348H30.2991L26.6727 0.383794C26.5983 0.154886 26.3849 0 26.1438 0H22.4555H18.7684C18.5273 0 18.3138 0.154886 18.2394 0.383794L14.5726 11.6563H2.83525C2.59415 11.6563 2.38075 11.8112 2.30635 12.0401L1.16705 15.5438L0.0272439 19.0475C-0.0471562 19.2764 0.0342938 19.5271 0.229244 19.6686L9.82846 26.6355L6.2015 37.7864C6.1271 38.0153 6.20855 38.2659 6.4035 38.4075L9.38691 40.5727C9.38746 40.5731 9.38816 40.5732 9.38871 40.5736L12.3704 42.7379C12.4681 42.8087 12.5827 42.8439 12.6972 42.8439C12.8118 42.8439 12.9264 42.8087 13.0241 42.7379L22.6234 35.7712L32.1187 42.663C32.2164 42.7338 32.331 42.7691 32.4456 42.7691C32.5602 42.7691 32.6747 42.7338 32.7725 42.663L35.7564 40.4973L38.7399 38.3321C38.9348 38.1905 39.0163 37.9399 38.9419 37.711L35.2751 26.4387L44.7708 19.5466C44.9657 19.405 45.0472 19.1544 44.9728 18.9255L43.8336 15.4223ZM41.7608 12.6458L42.6508 15.3819L39.662 17.5509L33.774 21.8238L33.5847 21.242L32.9959 19.4313L37.6642 16.0434C37.8592 15.9018 37.9406 15.6512 37.8662 15.4223C37.7918 15.1934 37.5784 15.0385 37.3373 15.0385L22.1462 15.038L22.9243 12.6458H26.2074H29.895H41.7608ZM19.6719 19.0475C19.6717 19.0484 19.672 19.0493 19.6717 19.0502L18.4762 22.7262L16.3345 21.172L20.6119 8.02186L21.9353 12.0903L21.7704 12.5972L20.8514 15.4218L19.6719 19.0475ZM24.4343 19.7747L25.6178 23.4127L22.5199 25.6611L19.422 23.413L20.6054 19.7748L24.4343 19.7747ZM21.5738 26.3477L19.4324 27.9019L8.2346 19.7747H12.5164L21.5738 26.3477ZM19.7594 29.038L22.847 26.7973C22.8475 26.797 22.8478 26.7965 22.8483 26.7961L25.9792 24.5239L26.797 27.0387L25.2221 28.1817L15.5994 35.1653L16.9223 31.097L19.7594 29.038ZM25.6035 19.7747H28.2506L32.5276 32.9252L29.0638 30.4104L28.7182 29.3485L25.6035 19.7747ZM28.6547 18.6635H24.8383C24.8375 18.6635 24.8368 18.6637 24.8361 18.6637H20.9668L21.7848 16.1489L35.6256 16.1494L32.1608 18.6637H28.6564C28.6558 18.6638 28.6553 18.6635 28.6547 18.6635ZM25.7397 1.11097L29.1299 11.5348H26.6114L23.2209 1.11097H25.7397ZM15.5058 12.3834C15.5059 12.3831 15.5057 12.3828 15.5058 12.3824L19.1723 1.11097H22.0514L25.4418 11.5348H22.9241L21.1408 6.05274C21.0664 5.82384 20.853 5.66895 20.6118 5.66895C20.3707 5.66895 20.1573 5.82384 20.0829 6.05274L15.3883 20.4852L13.351 19.0069L14.3659 15.8872L15.5058 12.3834ZM3.23925 12.7673H14.2112L13.4328 15.1601H2.4611L3.23925 12.7673ZM1.20995 19.0071L2.1 16.271H13.0715L12.2931 18.6637H6.523C6.2819 18.6637 6.06845 18.8186 5.99405 19.0475C5.91965 19.2764 6.00115 19.5271 6.1961 19.6686L18.4863 28.5885L16.4489 30.0671L16.4473 30.066L13.7931 28.1391L10.8091 25.9739C10.809 25.9739 10.8092 25.9739 10.8091 25.9739L1.20995 19.0071ZM7.3842 37.746L10.7744 27.322L12.8122 28.801L9.42166 39.2245L7.3842 37.746ZM22.2964 34.635C22.296 34.6353 22.2958 34.6356 22.2955 34.6359L12.6972 41.6018L10.3682 39.9112L12.8679 32.2251L13.7584 29.4877L14.8021 30.2451L15.7952 30.9661L14.0125 36.4482C13.9381 36.6771 14.0195 36.9277 14.2145 37.0693C14.41 37.2109 14.6728 37.2109 14.8683 37.0693L27.1587 28.1495L27.9369 30.5416L26.748 31.4045L25.2811 32.4688C25.2807 32.4691 25.2802 32.4692 25.2798 32.4695L22.2964 34.635ZM32.4456 41.5269L23.5695 35.0846L25.6068 33.606L34.4835 40.048L32.4456 41.5269ZM37.7592 37.6706L35.4297 39.3614L26.5531 32.9192L28.1855 31.7345L28.5907 31.4405L33.2586 34.829C33.4541 34.9705 33.7169 34.9705 33.9124 34.829C34.1073 34.6874 34.1888 34.4368 34.1144 34.2079L29.4203 19.7748H31.9379L37.7592 37.6706ZM34.9137 25.3275L34.1355 22.9348L37.1243 20.7658L43.0124 16.4928L43.79 18.8851L34.9137 25.3275Z",fill:"black"}),e.jsx("path",{d:"M77.1197 21.9309C77.0029 19.307 75.3394 17.6744 72.9462 15.6919H68.9186V21.9309H66V3.30115H68.0138H68.9186H73.9968C74.814 3.30115 75.5729 3.44693 76.3317 3.70932C77.0613 4.00086 77.7618 4.43818 78.3163 4.96296C79.5713 6.12915 80.2717 7.73265 80.2717 9.48193C80.2717 11.2604 79.5713 12.8639 78.3163 14.0009C77.8493 14.4674 77.2948 14.8172 76.7111 15.1088C77.2072 15.6044 77.6742 16.1 78.112 16.6831C79.3378 18.2575 79.9507 19.9484 80.0382 21.8143V21.9309H77.1197ZM68.9186 12.7764H73.9968C75.6312 12.7764 77.3532 11.6102 77.3532 9.48193C77.3532 7.35364 75.6312 6.21661 73.9968 6.21661H68.9186V12.7764ZM86.1088 21.9309H83.1903V3.30115H86.1088V21.9309ZM97.6955 22.1933C94.8937 22.1933 91.3038 21.4062 90.1364 20.9688L91.1579 18.2283C92.2378 18.6365 96.7615 19.5694 98.8921 19.1904C99.6217 19.0738 100.205 18.4032 100.322 17.6452C100.439 16.654 99.7093 15.6919 98.2792 15.0213C97.4036 14.6131 95.7692 13.9134 94.4559 13.3595C93.6971 13.0388 93.0258 12.7472 92.6172 12.5723C91.5665 12.1058 90.691 11.377 90.1072 10.5315C89.5527 9.68601 89.2609 8.72391 89.29 7.73265C89.3192 6.79971 89.6111 5.92507 90.1656 5.16705C90.7201 4.37987 91.5081 3.79678 92.4421 3.44693C93.6971 2.9513 95.5066 2.9513 97.8122 3.35946C99.5634 3.70932 101.139 4.20495 101.811 4.43818L100.789 7.17872C100.264 6.97463 98.8337 6.53731 97.2577 6.24577C94.8645 5.77929 93.8138 6.04169 93.4928 6.1583C92.7048 6.44985 92.2378 7.0621 92.2086 7.82012C92.1794 8.6656 92.7923 9.45278 93.8138 9.91925C94.1932 10.065 94.8645 10.3566 95.6233 10.6773C96.9367 11.2604 98.6002 11.9601 99.5342 12.3974C100.877 13.0388 101.869 13.8551 102.511 14.8755C103.124 15.8668 103.357 16.9455 103.212 18.0534C102.949 20.0651 101.373 21.6977 99.4174 22.0476C98.8921 22.135 98.3084 22.1933 97.6955 22.1933ZM117.483 3.30115H120.402V21.9309H117.483V13.447H109.37V21.9309H106.451V3.30115H109.37V10.5315H117.483V3.30115ZM140.715 22.1933C137.913 22.1933 134.323 21.4062 133.156 20.9688L134.177 18.2283C135.257 18.6365 139.781 19.5694 141.912 19.1904C142.641 19.0738 143.225 18.4032 143.342 17.6452C143.458 16.654 142.729 15.6919 141.299 15.0213C140.423 14.6131 138.789 13.9134 137.475 13.3595C136.717 13.0388 136.045 12.7472 135.637 12.5723C134.586 12.1058 133.71 11.377 133.127 10.5315C132.572 9.68601 132.28 8.72391 132.309 7.73265C132.339 6.79971 132.631 5.92507 133.185 5.16705C133.74 4.37987 134.528 3.79678 135.462 3.44693C136.717 2.9513 138.526 2.9513 140.832 3.35946C142.583 3.70932 144.159 4.20495 144.83 4.43818L143.809 7.17872C143.283 6.97463 141.853 6.53731 140.277 6.24577C137.884 5.77929 136.833 6.04169 136.512 6.1583C135.724 6.44985 135.257 7.0621 135.228 7.82012C135.199 8.6656 135.812 9.45278 136.833 9.91925C137.213 10.065 137.884 10.3566 138.643 10.6773C139.956 11.2604 141.62 11.9601 142.554 12.3974C143.896 13.0388 144.888 13.8551 145.531 14.8755C146.143 15.8668 146.377 16.9455 146.231 18.0534C145.968 20.0651 144.392 21.6977 142.437 22.0476C141.912 22.135 141.328 22.1933 140.715 22.1933ZM162.808 3.272V3.30115C162.867 4.90466 162.575 6.59562 161.991 8.25744C160.853 11.5228 158.781 14.1467 157.059 15.9251V21.9309H154.14V15.9251C152.389 14.1467 150.317 11.5228 149.179 8.25744C148.595 6.59562 148.303 4.90466 148.362 3.30115V3.272H151.251C151.105 7.44111 153.732 11.1146 155.6 13.1846C157.438 11.1146 160.065 7.44111 159.919 3.272H162.808ZM173.286 22.1933C170.484 22.1933 166.894 21.4062 165.727 20.9688L166.748 18.2283C167.828 18.6365 172.352 19.5694 174.483 19.1904C175.212 19.0738 175.796 18.4032 175.913 17.6452C176.029 16.654 175.3 15.6919 173.87 15.0213C172.994 14.6131 171.36 13.9134 170.046 13.3595C169.288 13.0388 168.616 12.7472 168.208 12.5723C167.157 12.1058 166.281 11.377 165.698 10.5315C165.143 9.68601 164.851 8.72391 164.881 7.73265C164.91 6.79971 165.202 5.92507 165.756 5.16705C166.311 4.37987 167.099 3.79678 168.033 3.44693C169.288 2.9513 171.097 2.9513 173.403 3.35946C175.154 3.70932 176.73 4.20495 177.401 4.43818L176.38 7.17872C175.854 6.97463 174.424 6.53731 172.848 6.24577C170.455 5.77929 169.404 6.04169 169.083 6.1583C168.295 6.44985 167.828 7.0621 167.799 7.82012C167.77 8.6656 168.383 9.45278 169.404 9.91925C169.784 10.065 170.455 10.3566 171.214 10.6773C172.527 11.2604 174.191 11.9601 175.125 12.3974C176.467 13.0388 177.459 13.8551 178.102 14.8755C178.714 15.8668 178.948 16.9455 178.802 18.0534C178.539 20.0651 176.963 21.6977 175.008 22.0476C174.483 22.135 173.899 22.1933 173.286 22.1933ZM192.957 3.272V6.18746H188.404V21.9309H185.486V6.18746H180.962V3.272H192.957ZM198.94 18.9863H206.849V21.9018H196.021V3.272H206.178V6.18746H198.94V10.5023H205.653V13.4178H198.94V18.9863ZM212.103 21.9309H209.155L211.081 3.272H215.868L219.457 17.6452L223.047 3.272H227.834L229.76 21.9309H226.812L225.236 6.44985L221.15 21.9309H217.765L213.708 6.44985L212.103 21.9309ZM240.442 22.1933C237.64 22.1933 234.05 21.4062 232.883 20.9688L233.904 18.2283C234.984 18.6365 239.508 19.5694 241.638 19.1904C242.368 19.0738 242.952 18.4032 243.069 17.6452C243.185 16.654 242.456 15.6919 241.026 15.0213C240.15 14.6131 238.516 13.9134 237.202 13.3595C236.443 13.0388 235.772 12.7472 235.364 12.5723C234.313 12.1058 233.437 11.377 232.854 10.5315C232.299 9.68601 232.007 8.72391 232.036 7.73265C232.066 6.79971 232.357 5.92507 232.912 5.16705C233.467 4.37987 234.255 3.79678 235.188 3.44693C236.443 2.9513 238.253 2.9513 240.559 3.35946C242.31 3.70932 243.886 4.20495 244.557 4.43818L243.536 7.17872C243.01 6.97463 241.58 6.53731 240.004 6.24577C237.611 5.77929 236.56 6.04169 236.239 6.1583C235.451 6.44985 234.984 7.0621 234.955 7.82012C234.926 8.6656 235.539 9.45278 236.56 9.91925C236.94 10.065 237.611 10.3566 238.37 10.6773C239.683 11.2604 241.347 11.9601 242.281 12.3974C243.623 13.0388 244.615 13.8551 245.257 14.8755C245.87 15.8668 246.104 16.9455 245.958 18.0534C245.695 20.0651 244.119 21.6977 242.164 22.0476C241.638 22.135 241.055 22.1933 240.442 22.1933Z",fill:"black"}),e.jsx("path",{d:"M72.2581 30.2673V31.2866H69.6732V38.2855H68.5849V31.2866H66V30.2673H72.2581ZM76.5572 30.2673V33.5969H80.7179V30.2673H81.8063V38.2855H80.7179V34.6162H76.5572V38.2855H75.4688V30.2673H76.5572ZM87.0123 30.2673V38.2855H85.9239V30.2673H87.0123ZM92.5584 30.2673L96.9799 36.8586H97.0026V30.2673H98.0909V38.2855H96.7078L92.241 31.6943H92.2183V38.2855H91.1299V30.2673H92.5584ZM103.297 30.2673V33.7328H103.388L106.936 30.2673H108.455L104.578 33.9707L108.716 38.2855H107.129L103.388 34.2764H103.297V38.2855H102.209V30.2673H103.297ZM122.167 30.2673V31.2866H119.582V38.2855H118.493V31.2866H115.908V30.2673H122.167ZM130.558 30.2673V31.2866H126.466V33.6762H130.275V34.6955H126.466V37.2663H130.762V38.2855H125.377V30.2673H130.558ZM138.043 30.0635C138.61 30.0635 139.141 30.1692 139.636 30.3806C140.131 30.592 140.537 30.9015 140.855 31.3092L139.948 32.0001C139.456 31.3885 138.81 31.0827 138.009 31.0827C137.14 31.0827 136.424 31.3923 135.861 32.0114C135.298 32.6305 135.016 33.4081 135.016 34.3444C135.016 35.2504 135.294 35.9979 135.849 36.5868C136.405 37.1757 137.125 37.4701 138.009 37.4701C138.893 37.4701 139.593 37.1115 140.106 36.3942L141.025 37.0851C140.707 37.5079 140.284 37.8476 139.755 38.1043C139.226 38.361 138.636 38.4894 137.986 38.4894C137.215 38.4894 136.516 38.3025 135.889 37.9288C135.262 37.5551 134.767 37.0416 134.404 36.3886C134.041 35.7355 133.86 35.0503 133.86 34.3331C133.86 33.0949 134.249 32.0737 135.027 31.2696C135.806 30.4655 136.811 30.0635 138.043 30.0635ZM145.483 30.2673V33.5969H149.643V30.2673H150.732V38.2855H149.643V34.6162H145.483V38.2855H144.394V30.2673H145.483ZM156.244 36.9945L155.291 39.7805H154.362L155.144 36.9945H156.244ZM168.946 30.0635C169.513 30.0635 170.044 30.1692 170.539 30.3806C171.034 30.592 171.44 30.9015 171.757 31.3092L170.851 32.0001C170.359 31.3885 169.713 31.0827 168.912 31.0827C168.043 31.0827 167.327 31.3923 166.763 32.0114C166.2 32.6305 165.919 33.4081 165.919 34.3444C165.919 35.2504 166.197 35.9979 166.752 36.5868C167.308 37.1757 168.028 37.4701 168.912 37.4701C169.796 37.4701 170.495 37.1115 171.009 36.3942L171.928 37.0851C171.61 37.5079 171.187 37.8476 170.658 38.1043C170.129 38.361 169.539 38.4894 168.889 38.4894C168.118 38.4894 167.419 38.3025 166.792 37.9288C166.165 37.5551 165.669 37.0416 165.307 36.3886C164.944 35.7355 164.762 35.0503 164.762 34.3331C164.762 33.0949 165.152 32.0737 165.93 31.2696C166.709 30.4655 167.714 30.0635 168.946 30.0635ZM176.385 30.2673V33.5969H180.546V30.2673H181.634V38.2855H180.546V34.6162H176.385V38.2855H175.297V30.2673H176.385ZM189.437 30.0635C190.631 30.0635 191.627 30.4599 192.424 31.2526C193.221 32.0454 193.62 33.0533 193.62 34.2764C193.62 35.0541 193.442 35.7657 193.087 36.4112C192.732 37.0568 192.231 37.5645 191.585 37.9345C190.939 38.3045 190.223 38.4894 189.437 38.4894C188.658 38.4894 187.948 38.3063 187.305 37.9401C186.663 37.574 186.16 37.0681 185.797 36.4226C185.435 35.777 185.253 35.0616 185.253 34.2764C185.253 33.0836 185.644 32.0831 186.427 31.2753C187.209 30.4675 188.212 30.0635 189.437 30.0635ZM186.41 34.2764C186.41 35.1825 186.693 35.9412 187.26 36.5528C187.827 37.1644 188.552 37.4701 189.437 37.4701C190.306 37.4701 191.028 37.1681 191.602 36.5641C192.177 35.9601 192.464 35.1975 192.464 34.2764C192.464 33.3629 192.18 32.6022 191.613 31.9944C191.047 31.3866 190.317 31.0828 189.425 31.0828C188.564 31.0828 187.846 31.3848 187.271 31.9888C186.697 32.5928 186.41 33.3554 186.41 34.2764ZM200.923 30.0635C202.118 30.0635 203.113 30.4599 203.911 31.2526C204.708 32.0454 205.107 33.0533 205.107 34.2764C205.107 35.0541 204.929 35.7657 204.574 36.4112C204.219 37.0568 203.718 37.5645 203.072 37.9345C202.426 38.3045 201.709 38.4894 200.923 38.4894C200.145 38.4894 199.435 38.3063 198.792 37.9401C198.15 37.574 197.647 37.0681 197.284 36.4226C196.921 35.777 196.74 35.0616 196.74 34.2764C196.74 33.0836 197.131 32.0831 197.913 31.2753C198.696 30.4675 199.699 30.0635 200.923 30.0635ZM197.896 34.2764C197.896 35.1825 198.18 35.9412 198.747 36.5528C199.314 37.1644 200.039 37.4701 200.923 37.4701C201.793 37.4701 202.514 37.1681 203.089 36.5641C203.663 35.9601 203.95 35.1975 203.95 34.2764C203.95 33.3629 203.667 32.6022 203.1 31.9944C202.533 31.3866 201.804 31.0828 200.912 31.0828C200.051 31.0828 199.333 31.3848 198.758 31.9888C198.184 32.5928 197.896 33.3554 197.896 34.2764ZM211.027 30.0635C212.07 30.0635 212.841 30.3693 213.34 30.9809L212.456 31.785C212.32 31.5736 212.127 31.4037 211.877 31.2753C211.628 31.147 211.341 31.0828 211.016 31.0828C210.547 31.0828 210.171 31.198 209.888 31.4282C209.604 31.6585 209.463 31.9548 209.463 32.3172C209.463 32.9213 209.863 33.344 210.664 33.5857L211.673 33.9141C212.24 34.0953 212.673 34.3482 212.971 34.6729C213.27 34.9975 213.419 35.443 213.419 36.0092C213.419 36.7492 213.157 37.3475 212.631 37.8043C212.106 38.261 211.439 38.4895 210.63 38.4895C209.474 38.4895 208.62 38.1195 208.068 37.3796L208.964 36.6095C209.138 36.8813 209.376 37.0927 209.678 37.2437C209.98 37.3947 210.309 37.4702 210.664 37.4702C211.11 37.4702 211.488 37.3418 211.798 37.0851C212.108 36.8284 212.263 36.5113 212.263 36.1338C212.263 35.8545 212.168 35.6204 211.979 35.4317C211.79 35.2429 211.45 35.073 210.959 34.922L210.245 34.6842C209.527 34.4426 209.024 34.1349 208.737 33.7612C208.45 33.3875 208.306 32.9062 208.306 32.3172C208.306 31.6906 208.559 31.1583 209.066 30.7204C209.572 30.2825 210.226 30.0635 211.027 30.0635ZM222.265 30.2673V31.2866H218.172V33.6762H221.981V34.6955H218.172V37.2663H222.469V38.2855H217.083V30.2673H222.265ZM232.212 30.2673V35.2164C232.212 35.8733 232.395 36.4132 232.762 36.8359C233.128 37.2587 233.618 37.4701 234.23 37.4701C234.842 37.4701 235.331 37.2587 235.698 36.8359C236.064 36.4131 236.248 35.8733 236.248 35.2164V30.2673H237.336V35.3976C237.336 35.9488 237.206 36.4641 236.945 36.9435C236.684 37.423 236.314 37.8004 235.834 38.076C235.354 38.3516 234.819 38.4894 234.23 38.4894C233.323 38.4894 232.578 38.1931 231.996 37.6004C231.414 37.0077 231.123 36.2734 231.123 35.3976V30.2673H232.212ZM243.608 30.0635C244.651 30.0635 245.422 30.3693 245.921 30.9809L245.036 31.785C244.9 31.5736 244.708 31.4037 244.458 31.2753C244.209 31.147 243.922 31.0828 243.597 31.0828C243.128 31.0828 242.752 31.198 242.468 31.4282C242.185 31.6585 242.043 31.9548 242.043 32.3172C242.043 32.9213 242.444 33.344 243.245 33.5857L244.254 33.9141C244.821 34.0953 245.254 34.3482 245.552 34.6729C245.851 34.9975 246 35.443 246 36.0092C246 36.7492 245.737 37.3475 245.212 37.8043C244.687 38.261 244.02 38.4895 243.211 38.4895C242.055 38.4895 241.201 38.1195 240.649 37.3796L241.544 36.6095C241.718 36.8813 241.956 37.0927 242.259 37.2437C242.561 37.3947 242.89 37.4702 243.245 37.4702C243.691 37.4702 244.069 37.3418 244.379 37.0851C244.689 36.8284 244.844 36.5113 244.844 36.1338C244.844 35.8545 244.749 35.6204 244.56 35.4317C244.371 35.2429 244.031 35.073 243.54 34.922L242.826 34.6842C242.108 34.4426 241.605 34.1349 241.318 33.7612C241.031 33.3875 240.887 32.9062 240.887 32.3172C240.887 31.6906 241.14 31.1583 241.647 30.7204C242.153 30.2825 242.807 30.0635 243.608 30.0635Z",fill:"black"})]})}),e.jsx("ul",{className:"mt-5 list-unstyled servicesList",children:M.length>0?M.slice(0,3).map((D,F)=>e.jsxs("li",{children:[e.jsx("img",{src:Fr,alt:""}),e.jsx(fe,{to:D.page_url,onClick:()=>{kn(D)},children:D.services_page_title})]},F)):""})]})}),e.jsxs("div",{className:"col-12 col-lg-6 p-4 d-flex justify-content-center align-items-start flex-column position-relative briefServices",children:[N&&C&&e.jsx(ce,{editHandler:()=>te("homecareers",!0),editlabel:"Brief"}),e.jsxs("div",{className:"d-flex align-items-center mb-5",children:[e.jsx("i",{className:"fa fa-angle-left text-muted fs-1 me-2","aria-hidden":"true"}),e.jsx(pe,{title:"OUR WORK LOCATIONS",cssClass:"fs-4 fw-medium"})]}),$?e.jsx(pe,{title:$.banner_title,cssClass:l}):"",e.jsx("p",{className:"lh-lg mt-md-3",children:$!=null&&$.banner_descripiton?$.banner_descripiton:"upload Description"}),e.jsx("div",{children:e.jsx(fe,{to:"/allservices",children:e.jsx("img",{src:Fr,alt:"circlearrow"})})})]}),f.homecareers?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(pn,{editHandler:te,componentType:"homecareers",popupTitle:"Home Careers Banner",pageType:S,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:mn(S),dimensions:m})}):"",A&&e.jsx(pt,{})]})},fi=me.div`

.serviceOffered  {
    img {
        border-radius: 50px;
        height: 350px;
        width: 300px;
        object-fit:cover;
        border: 3px solid ${({theme:a})=>a.gray};
        filter: gray; /* IE6-9 */
        -webkit-filter: grayscale(1); /* Google Chrome, Safari 6+ & Opera 15+ */
        filter: grayscale(1); /* Microsoft Edge and Firefox 35+ */
        object-fit: cover;
        cursor: pointer;
        transition: .9s ease;

        &:hover {
            -webkit-filter: grayscale(0);
            filter: none;
            border: 3px solid ${({theme:a})=>a.black};

            + h4 {
                letter-spacing: 5px;
            }
        }

        + h4 {
           
            letter-spacing: 0px;
            transition: all .4s ease-in;
        }
        
    }
}

@media (max-width: 768px) {
    .serviceOffered  {
        img {
            height: 250px;
            width: 200px;
        }
    }
}

.serviceOffered  + .dcarousel {
    width: 90vw;
    height: 90vh;
    top: 5vh !important;
}

.serviceOffered  + .dcarousel .carousel-item img {
    object-fit: cover;
    width: 90vw !important;
    height: 90vh !important;
    margin: 0 auto;
}
  
`,pi=({getBannerAPIURL:a,componentEdit:l})=>{const[h,j]=V.useState([]),[m,v]=V.useState(!1),[S,N]=V.useState(null);V.useEffect(()=>{const O=async()=>{try{const A=await xe.get(a);if((A==null?void 0:A.status)===200){let Z=Object.keys(A.data);const $=mt(A.data[Z][0]),B=De(A.data[Z],$);j(B)}}catch{console.log("unable to access ulr because of server is down")}};l.serviceOffered||O()},[l.serviceOffered,a]);const C=O=>{const A=h.find(Z=>Z.id===O);v(!m),N(A)},f=()=>{v(!m)};return e.jsxs(fi,{children:[e.jsx("div",{className:"row serviceOffered",children:e.jsx("div",{className:"col-md-10 offset-md-1",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:h.length>0&&(h==null?void 0:h.map((O,A)=>e.jsxs("div",{className:"col-sm-6 col-md-4 mb-4 text-center",children:[e.jsx("img",{src:dt(O==null?void 0:O.path),alt:O.alternitivetext,onClick:()=>C(O.id),className:"img-fluid"}),e.jsx("h4",{className:"my-3 text-uppercase",children:O.carouse_title})]},O.id)))})})})}),m&&e.jsx(ni,{obj:S,all:h,closeCarousel:f}),m&&e.jsx(pt,{closeModel:f})]})},mi=me.div`
    .fatures {
        padding: 80px 0;
        margin-top: 20px;
        margin-bottom: 50px;
        background-color: ${({theme:a})=>a.primaryColor};
        color: ${({theme:a})=>a.white};
        display: flex;
        flex-direction: column;
        justify-content-center;
        align-items: center;

        a {
            color: ${({theme:a})=>a.white};
            svg {
                stroke: ${({theme:a})=>a.white};
            }

        }

        .box1, .box2 {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            gap: 1rem;
            padding: 0;
        }

        .title {
            font-size: 3rem;
        }

        .box1 img, .box2 img {
            width: 30%;
        }

        .box1 {
            background-color: ${({theme:a})=>a.teritoryColor};
            
        }
        .box2 {
            background-color: ${({theme:a})=>a.secondaryColor};
        }
        .decImg {
            width: 100%;
            object-fit: cover;
            object-position: center;
        }

        @media (max-width: 991px) {
            .decImg {
                height: 200px;
                
            }
            .box1, .box2 {
                padding: 25px
            }
        }
}
`,hi="/static/assets/features-img-C8A51Jr8.jpg",vi="/static/assets/features-img1-B_1zXtm0.jpg",gi="data:image/svg+xml,%3csvg%20width='125'%20height='98'%20viewBox='0%200%20125%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M95.3168%2036.4818H65.6293V47.0908C65.6293%2054.6118%2059.3208%2060.7309%2051.5669%2060.7309C43.813%2060.7309%2037.5044%2054.6118%2037.5044%2047.0908V24.0542L24.8286%2031.4426C21.0591%2033.6212%2018.7544%2037.5806%2018.7544%2041.8242V50.785L3.12945%2059.5374C0.141173%2061.2046%20-0.893981%2064.9177%200.844297%2067.8162L16.4693%2094.0734C18.188%2096.972%2022.0161%2097.9571%2025.0044%2096.29L45.1997%2084.98H71.8793C78.7738%2084.98%2084.3793%2079.5429%2084.3793%2072.8555H87.5043C90.9613%2072.8555%2093.7543%2070.1464%2093.7543%2066.7932V54.6687H95.3168C97.9144%2054.6687%20100.004%2052.6416%20100.004%2050.122V41.0286C100.004%2038.5089%2097.9144%2036.4818%2095.3168%2036.4818ZM124.164%2029.3966L108.539%203.13934C106.821%200.240819%20102.993%20-0.744301%20100.004%200.922825L79.809%2012.2328H59.8481C57.5043%2012.2328%2055.2192%2012.8769%2053.227%2014.0704L46.6841%2018.0298C44.8481%2019.1286%2043.7544%2021.0799%2043.7544%2023.1638V47.0908C43.7544%2051.2776%2047.2505%2054.6687%2051.5669%2054.6687C55.8833%2054.6687%2059.3793%2051.2776%2059.3793%2047.0908V30.4196H95.3168C101.352%2030.4196%20106.254%2035.1747%20106.254%2041.0286V46.4278L121.879%2037.6754C124.868%2035.9893%20125.883%2032.2951%20124.164%2029.3966Z'%20fill='white'/%3e%3c/svg%3e",bi="data:image/svg+xml,%3csvg%20width='100'%20height='98'%20viewBox='0%200%20100%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M45.039%2046.1508C44.8843%2039.0425%2043.3309%2032.0284%2040.4623%2025.4854C22.1554%2033.775%208.70752%2049.4158%204.11064%2067.8719C6.80083%2073.8489%2010.7021%2079.2409%2015.5827%2083.7277C20.224%2068.0776%2030.7303%2054.6749%2045.039%2046.1508ZM37.5993%2019.8743C34.5329%2014.6935%2030.6252%2010.0261%2026.0265%206.05174C7.67928%2015.7881%20-3.16776%2035.9452%200.824273%2057.3144C7.5583%2041.0675%2020.6635%2027.5969%2037.5993%2019.8743ZM75.4228%2052.1529C77.1567%2032.641%2069.9186%2013.5398%2055.7651%200.460161C52.8013%200.127794%2045.3616%20-0.615142%2035.8251%202.12199C47.493%2013.8464%2054.2172%2029.3785%2054.6764%2045.6659C61.1017%2049.0921%2068.1438%2051.294%2075.4228%2052.1529ZM50.2811%2054.0102C44.0101%2057.7023%2038.5222%2062.5196%2034.1114%2068.2042C50.644%2079.4069%2071.3098%2082.887%2090.0603%2077.5496C94.0935%2072.3094%2096.988%2066.3299%2098.5685%2059.9733C93.2369%2061.2906%2087.7596%2061.9734%2082.2576%2062.0066C71.2493%2061.987%2060.3015%2059.2499%2050.2811%2054.0102ZM30.4621%2073.5025C27.3975%2078.5858%2025.2805%2084.1383%2023.9901%2089.9645C32.9338%2095.2875%2043.3826%2097.7357%2053.8459%2096.9598C64.3093%2096.1839%2074.2527%2092.2236%2082.2576%2085.6437C59.495%2088.7914%2041.2688%2080.7951%2030.4621%2073.5025ZM66.8137%203.00179C77.9632%2016.7657%2083.4472%2034.5179%2081.8544%2052.583C87.9966%2052.5956%2094.1016%2051.6584%2099.9395%2049.8068C99.9395%2049.4158%20100%2049.0247%20100%2048.6337C100%2027.5578%2086.1489%209.70776%2066.8137%203.00179Z'%20fill='white'/%3e%3c/svg%3e",yi="data:image/svg+xml,%3csvg%20width='100'%20height='98'%20viewBox='0%200%20100%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M97.8754%2075.6416L75.0056%2053.4615C70.4941%2049.0861%2063.7562%2048.2337%2058.3268%2050.8286L37.5077%2030.6374V18.8749L12.5091%200.691406L0.00976493%2012.8137L18.7587%2037.0584H30.887L51.7061%2057.2497C49.05%2062.5153%2049.9093%2069.05%2054.4208%2073.4254L77.2906%2095.6055C80.142%2098.3709%2084.7511%2098.3709%2087.583%2095.6055L97.8754%2085.6235C100.707%2082.8581%20100.707%2078.388%2097.8754%2075.6416ZM64.7913%2043.309C70.3184%2043.309%2075.5134%2045.3925%2079.4194%2049.1808L83.2083%2052.8553C86.294%2051.5484%2089.2235%2049.7301%2091.7625%2047.2677C99.0082%2040.2405%20101.469%2030.3533%2099.1644%2021.3751C98.7347%2019.6704%2096.5278%2019.0833%2095.2388%2020.3334L80.7084%2034.4256L67.4474%2032.2853L65.2405%2019.4242L79.7709%205.33199C81.0599%204.08187%2080.435%201.94152%2078.6577%201.50588C69.4004%20-0.710239%2059.2057%201.67635%2051.9795%208.68457C46.4134%2014.0828%2043.7964%2021.2047%2043.9331%2028.3076L59.9674%2043.8583C61.5493%2043.4984%2063.1898%2043.309%2064.7913%2043.309ZM44.4995%2058.8408L33.4259%2048.1011L3.66191%2076.9864C-1.22064%2081.7217%20-1.22064%2089.3928%203.66191%2094.1281C8.54445%2098.8634%2016.4542%2098.8634%2021.3367%2094.1281L45.476%2070.7169C43.9917%2066.9476%2043.5425%2062.8373%2044.4995%2058.8408ZM12.5091%2090.0937C9.93109%2090.0937%207.82183%2088.048%207.82183%2085.5478C7.82183%2083.0286%209.91156%2081.0019%2012.5091%2081.0019C15.1066%2081.0019%2017.1963%2083.0286%2017.1963%2085.5478C17.1963%2088.048%2015.1066%2090.0937%2012.5091%2090.0937Z'%20fill='white'/%3e%3c/svg%3e",xi="data:image/svg+xml,%3csvg%20width='133'%20height='98'%20viewBox='0%200%20133%2098'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M45.1727%2095.7747L1.94766%2053.5048C-0.64922%2050.9653%20-0.64922%2046.8478%201.94766%2044.3081L11.352%2035.1113C13.9488%2032.5716%2018.1596%2032.5716%2020.7565%2035.1113L49.875%2063.5861L112.243%202.59603C114.84%200.0565321%20119.051%200.0565321%20121.648%202.59603L131.052%2011.7928C133.649%2014.3323%20133.649%2018.4498%20131.052%2020.9895L54.5773%2095.775C51.9801%2098.3145%2047.7696%2098.3145%2045.1727%2095.7747Z'%20fill='white'/%3e%3c/svg%3e",ji=()=>e.jsx(mi,{className:"row",children:e.jsxs("div",{className:"col-md-12 fatures",children:[e.jsxs("div",{className:"container mb-5",children:[e.jsx("h1",{className:"text-center fw-bold title",children:"Our Features"}),e.jsx("p",{className:"text-center mt-3 mb-5",children:"When a consultant takes a new project, they typically start by doing an in-depth analysis of their client's business goals and objectives."}),e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-6 col-md-3 box1",children:[e.jsx("img",{src:gi,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsxs("div",{className:"col-6 col-md-3 box2",children:[e.jsx("img",{src:bi,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsx("div",{className:"col-md-6 p-0",children:e.jsx("img",{src:vi,alt:"",className:"decImg img-fluid"})})]}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6 p-0",children:e.jsx("img",{src:hi,alt:"",className:"decImg img-fluid"})}),e.jsxs("div",{className:"col-6 col-md-3 box1",children:[e.jsx("img",{src:yi,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]}),e.jsxs("div",{className:"col-6 col-md-3 box2",children:[e.jsx("img",{src:xi,alt:"",className:"img-fluid"}),e.jsx("p",{children:"We Help Set Priorities Correctly"})]})]})]}),e.jsx(lt,{AncherLabel:"Know More About",Ancherpath:"/about",AncherClass:"btn btn-outline d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})]})}),Si=me.div`
  background-color: ${({theme:a})=>a.white};
  margin: 64px 0;
  background-attachment: fixed;
  // background-image: url(${Tn});
  background-position: center;
  padding: 120px 0;

  @media (max-width: 480px) {
    padding: 32px 0;
  }


.clients-image-slider{
    display: flex;
    // place-it 
    position: relative;
    overflow: hidden;

    height: 100%;  
    width: 100%;
    justify-content: flex-end;

      &::before,
      &::after {
        background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
        content: '';
        height: 100%;
        width: 15%;
        z-index: 2;
        position: absolute;
      }
    
      &::before {
        left: 0;
        top: 0;
      }
    
      &::after {
        right: 0;
        top: 0;
        background: linear-gradient(to left, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
      }


    .image-slider-track{
      display: flex;
      animation: play 40s linear infinite;
  
      &::hover{
        -webkit-animation-play-state: paused;
        -moz-animation-play-state: paused;
        -o-animation-play-state: paused;
        animation-play-state: paused;
      }
      
      .slide{
        // height: 150px;
        width: 200px;
        display: flex;
        place-items: center;
        padding: 15px;
        perspective: 100px;
        margin-right: 70px;

        &:hover .clientPopOver {
          bottom: 0;
          left: 0;
          right: 0;
          // height: 100%;
        }

        .clientPopOver {
          // top: 0px;
          // z-index: 999;
          // opacity: .8;
          // transition: .5s ease;

          position: absolute;
          bottom: 100%;
          left: 0;
          right: 0;
          background-color: #008CBA;
          overflow: hidden;
          width: 100%;
          // height:0;
          transition: .5s ease;
          opacity: .85;
          
          p {
            margin: 0px 0 5px;
            padding: 0;
            transition: .5s ease;
            justify-content: center;
          align-items: center;
          }
        }

        img{
          height: 100%;
          width:100%;
        }
    }
  }
}

@keyframes play{
    0%{
        transform: translateX(100%);
    }

    100%{
        transform: translateX(-120%);
    }
}

.slider-container {
  .slick-slider {
    overflow: hidden !important;
  }

  .slick-list {
    width: 100% !important;
  }

  .slick-track {
    overflow: hidden !important;
  }
}

.slick-initialized .slick-slide {
  display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 200px !important;
    height: 100px;
    padding: 16px;
    border: 2px dashed ${({theme:a})=>a.grayccc};
    background: white;
    margin: 0 12px;
    cursor: pointer;

  div {
    img {
      margin: 0 auto;
      width: 100%;
      height: 100% !important;
      // box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
    }
  }
}

.ql-editor {
  padding: 10px !imporrant;
  text-align: center;
  max-width: 240px;

  p {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  }
}

    
 
  

`,wi="/static/assets/carousel1-BjDUQ-HC.jpg",Ci="/static/assets/carousel2-oBE5xWYj.jpg",Oi="/static/assets/carousel3-BiZNlBHH.jpg",Ni=me.div`
    // padding: 50px 0;

    .hiligntsContainer {
        bottom: -75px;
        box-shadow: 0px 4px 16px rgba(0, 0, 0, .25);     
    }
    .col-sm-4 {
        &:nth-child(1) {
            background: ${({theme:a})=>a.white};
        }

        &:nth-child(2) {
            background: ${({theme:a})=>a.verylightgray};
        }

        &:nth-child(3) {
            background: ${({theme:a})=>a.white};
        }

        p {
            font-size: .9rem;
            margin: 0px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp:2;
        }
    }
l`,ki="/static/assets/testimonialBg-BxSPVqGQ.jpg",Ur=me.div`

.testimonialsContainer {
  background-image: url(${ki});
    background-position: 50% 0;
    background-repeat: no-repeat;
    padding: 150px;

    @media (max-width: 576px) {
      padding: 10px;
    }
}
    
.testimonials {
    // background-color:${({theme:a})=>a.testimonialsBg}; 
    background-color: rgba(13, 117, 186, .9);
    color:${({theme:a})=>a.testimonialsTextColor};
    border-radius: 8px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    // border: 1px solid ${({theme:a})=>a.gray888};
    // background: rgb(255,255,255);
    // background: linear-gradient(360deg, ${({theme:a})=>a.white} 0%, ${({theme:a})=>a.primaryColor} 100%);
    // border-radius: 30px;
    padding: 48px 0 !important;

    h5 {
      color: ${({theme:a})=>a.white};
      margin-bottom: 1rem;
    }

    .testimonialImg {
        width: 125px;
        height: 125px;
        object-fit: cover;
        box-shadow: 0 5px 5px rgba(0,0,0, .5) !important
      }

      i.fa {
        color:${({theme:a})=>a.testimonialsLinkColor};

        &:hover {
            color: ${({theme:a})=>a.testimonialsLinkHoverColor};
        }
      }

    .title {color:${({theme:a})=>a.testimonialsTextColor}; text-align: left;}
    p {color:${({theme:a})=>a.testimonialsTextColor}; text-align: left;}

    .article {
        /* top: 0;
          left: 0; */
        /* width: 100%;
          height: 100%; */
        opacity: 0;
        transition: all 0.3s linear;
      }
      
      .article.activeSlide {
        opacity: 1;
        transform: translateX(0);
      }
      
      .fa-user {
        font-size: 100px;
      }
      .article.lastSlide {
        // transform: translateX(-100%); 
      }
      
      .article.nextSlide {
        //  transform: translateX(100%); 
      }
}

.ql-editor {
  cursor: pointer;
}

.slick-prev {
  left: -50px !important;

  @media(max-width: 480px) {
    left: -25px !important;
  }
}

.slick-next {
  right: -50px !important;

  @media(max-width: 480px) {
    right: -25px !important;
  }
}

.slick-list {
  
  @media(max-width: 1500px) {
    width: 600px;
  }

  @media(max-width: 1300px) {
    width: 500px;
  }

  @media(max-width: 1024px) {
    width: 400px;
  }

  @media(max-width: 480px) {
    width: 300px;
  }
}


`,Ti=me.div`
    .randomServices img {
        border-top-right-radius: 10px;
        border-bottom-right-radius: 10px;
        height: 320px;
        object-fit: cover;
        filter: grayscale(100%);
        transition: filter 0.3s ease-in-out, transform 0.3s ease-in-out;

        &:hover {
            filter: grayscale(0%);
            transform: scaleX(1.05);
        }
    }
    .randomServices .row:nth-child(2) img {
        border-top-left-radius: 10px;
        border-bottom-left-radius: 10px;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px
    }

    @media (max-width: 576px) {
        .randomServices .row img {
            border-radius: 0px !important;
            height: 200px;
        }
    }
l`,$e=({componentEdit:a,formgetURL:l,formvalues:h,setFormValues:j})=>(V.useEffect(()=>{a||(async()=>{try{let v=await xe.get(l);j(v.data.intro)}catch{console.log("Unable to get the intro")}})()},[a]),e.jsxs(e.Fragment,{children:[e.jsx(pe,{title:h==null?void 0:h.intro_title,cssClass:"fs-4 fw-bold text-left"}),e.jsx("p",{className:"mt-2 mb-3",children:h==null?void 0:h.intro_desc}),e.jsx(fe,{to:h==null?void 0:h.intro_morelink,className:"moreLink",children:"more.."})]}));function Ke({editHandler:a,componentType:l,componentTitle:h="Form ",editObject:j,setEditState:m,setSaveState:v,dynamicFormFields:S=[],formPostURL:N,formUpdateURL:C}){const f=()=>{a(l,!1),document.body.style.overflow=""},[O,A]=V.useState(!1),[Z,$]=V.useState(""),{register:B,reset:M,handleSubmit:te,formState:{errors:D}}=ht({defaultValues:V.useMemo(()=>j,[j])}),[F,X]=V.useState(""),z=async u=>{JSON.stringify(u);let g=new FormData;Object.keys(u).forEach(b=>{g.append(b,u[b])});let w="";try{u!=null&&u.id?w=await Ce.put(`${C}${u.pageType}/`,g):w=await Ce.post(N,g),f()}catch(b){bt.error(b[0])}};return e.jsxs(e.Fragment,{children:[e.jsx(vt,{closeHandler:f,title:h}),e.jsx("hr",{}),e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 px-5",children:[O&&e.jsx("div",{className:"fw-bold",children:O&&e.jsx(hn,{children:O})}),e.jsxs("form",{onSubmit:te(z),children:[Object.keys(S).map((u,g)=>{var c;const{label:w,type:b,fieldName:s,value:i}=S[u];return b=="richText"?e.jsx(Pn,{label:w,editorSetState:X,initialText:""},g):e.jsx(Te,{label:w,type:b,value:i,error:(c=D==null?void 0:D[s])==null?void 0:c.message,fieldName:s,register:B,...S[u]},g)}),e.jsxs("div",{className:"d-flex justify-content-center flex-wrap flex-column flex-sm-row align-items-center gap-1 gap-md-3 mt-5",children:[e.jsx("button",{className:"btn btn-secondary mx-3",children:"save"}),e.jsx(gt,{type:"submit",cssClass:"btn btn-outline",label:"Close",handlerChange:f})]})]})]})})})]})}const Pi=({client:a})=>{const[l,h]=V.useState(!1),j=_n(),m=S=>{h(!0)},v=S=>{h(!1)};return e.jsx("div",{onMouseEnter:m,onMouseLeave:v,children:e.jsx("img",{src:`${j}${a.path}`,alt:a.client_title,style:{height:"100px"}},a.id)})},_i=()=>{const[a,l]=V.useState([]),h=async()=>{const j=await xe.get("/project/clientCategory/");(j==null?void 0:j.status)===200&&l(j.data)};return V.useEffect(()=>{h()},[]),e.jsx("div",{children:e.jsx("div",{className:"row homeProjectsBg",children:e.jsx("div",{className:"col-md-12 d-flex justify-content-center align-items-center",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:a==null?void 0:a.map((j,m)=>e.jsx("div",{className:"col-sm-12 col-md-12 col-lg-4 cardItem",children:e.jsx("div",{className:"card border-0 p-3 p-md-5 ",children:e.jsxs("div",{className:"card-body p-0",children:[e.jsx(pe,{title:j.category_Label,cssClass:"text-start"}),e.jsx("p",{className:"card-text my-4 lineClamp lc9",children:j.category_description}),e.jsxs(fe,{to:`${j.readMore_link}`,children:["Continue"," "]})]})})},m))})})})})})},Ei=({item:a,index:l})=>{const h=En();return e.jsx("div",{className:`carousel-item ${l===0?"active":""}`,children:e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row align-items-start",children:[e.jsx("div",{className:"col-sm-6 col-md-6 p-0 carouselImg",children:e.jsx("img",{src:dt(a.path),alt:a.altText,className:"d-block w-100"})}),e.jsx("div",{className:"col-sm-6 col-md-6 carouselDescription d-flex align-items-center",children:e.jsxs("div",{className:"d-flex flex-column justify-content-start align-items-start gap-2",children:[e.jsx("span",{children:"PROJECTS"}),a.projectTitle&&e.jsx("h1",{className:"",children:a.projectTitle}),(a==null?void 0:a.projectDescription)||(a==null?void 0:a.imageDescription)&&e.jsx(ut,{data:a.imageDescription?a.imageDescription:a.projectDescription,className:"introDecTitleCss",showMorelink:!1}),e.jsx("div",{children:e.jsx("button",{className:"btn btn-primary btn-sm",onClick:()=>h("/project-details",{state:{selectedPorject:a.projectType,projectid:a.id}}),children:"more details"})})]})})]})})},a.index)},Mi=({carouselState:a})=>{const{clientProjects:l}=ye(S=>S.clientProjects),h=yt(),{isLoading:j}=ye(S=>S.loader),[m,v]=V.useState([]);return V.useEffect(()=>{l.length===0&&h(Mn())},[h,l]),V.useEffect(()=>{var S;if(((S=l==null?void 0:l.projectList)==null?void 0:S.length)>0){const N=In(l),C=Ln(l),f=[];C.forEach(O=>{var A,Z,$,B;f.push({id:O.id,projectTitle:O.projectTitle,projectDescription:O.description,altText:(A=O==null?void 0:O.imgs[0])==null?void 0:A.alternitivetext,path:(Z=O==null?void 0:O.imgs[0])==null?void 0:Z.path,imageDescription:($=O==null?void 0:O.imgs[0])==null?void 0:$.imageDescription,imageTitle:(B=O==null?void 0:O.imgs[0])==null?void 0:B.imageTitle,projectType:N[O.projectCategoryValue]})}),v(f)}},[l]),e.jsxs("div",{id:"carouselExampleDark",className:"homeMultyPurposeCarousel carousel slide","data-bs-ride":"carousel",children:[e.jsx("div",{className:"carousel-indicators",children:m.length>0&&(m==null?void 0:m.map((S,N)=>e.jsx("button",{type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide-to":N,className:`${N===0?"active":""}`,"aria-current":"true","aria-label":`Slide ${N} `},N)))}),e.jsxs("div",{className:"carousel-inner",children:[j?e.jsx(vn,{}):"",m.length>0?m==null?void 0:m.map((S,N)=>e.jsx(Ei,{item:S,index:N},N)):e.jsx("div",{className:"d-flex justify-content-center align-items-center fs-5 text-muted text-center noImg",children:!j&&e.jsx("p",{children:"Please add images for Carousel..."})})]}),m.length>1&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{className:"carousel-control-prev",type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide":"prev",children:[e.jsx("span",{className:"carousel-control-prev-icon","aria-hidden":"true"}),e.jsx("span",{className:"visually-hidden",children:"Previous"})]}),e.jsxs("button",{className:"carousel-control-next",type:"button","data-bs-target":"#carouselExampleDark","data-bs-slide":"next",children:[e.jsx("span",{className:"carousel-control-next-icon","aria-hidden":"true"}),e.jsx("span",{className:"visually-hidden",children:"Next"})]})]})]})},Ii=({editHandler:a,objectstatus:l,pageType:h})=>{const j={service:!1},{isAdmin:m,hasPermission:v}=ft(),[S,N]=V.useState(j),[C,f]=V.useState(!1),[O,A]=V.useState([]);return e.jsx("div",{className:"homeService",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[m&&v&&e.jsx(ce,{editHandler:()=>a(h,!0),editlabel:"Dynamic Services"}),e.jsx(be,{introState:l,linkCss:"",linkLabel:"In detail...",moreLink:"",introTitleCss:"fs-5 mb-3 lineClamp lc2 ",introSubTitleCss:"fw-medium text-muted",introDecTitleCss:"lineClamp lc6",detailsContainerCss:"col-md-12 py-4",anchorContainer:"mt-4",anchersvgColor:" ",pageType:h,showLink:"true"}),l&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:a,componentType:h,popupTitle:"Home Service",pageType:h})})]})})})})};var Qe={},Ge={},Ee={},Xe={},qr;function Li(){return qr||(qr=1,function(a){Object.defineProperty(a,"__esModule",{value:!0}),a.default=void 0;var l={animating:!1,autoplaying:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,dragging:!1,edgeDragged:!1,initialized:!1,lazyLoadedList:[],listHeight:null,listWidth:null,scrolling:!1,slideCount:null,slideHeight:null,slideWidth:null,swipeLeft:null,swiped:!1,swiping:!1,touchObject:{startX:0,startY:0,curX:0,curY:0},trackStyle:{},trackWidth:0,targetSlide:0};a.default=l}(Xe)),Xe}var Ye,Wr;function Ri(){if(Wr)return Ye;Wr=1;var a="Expected a function",l=NaN,h="[object Symbol]",j=/^\s+|\s+$/g,m=/^[-+]0x[0-9a-f]+$/i,v=/^0b[01]+$/i,S=/^0o[0-7]+$/i,N=parseInt,C=typeof globalThis=="object"&&globalThis&&globalThis.Object===Object&&globalThis,f=typeof self=="object"&&self&&self.Object===Object&&self,O=C||f||Function("return this")(),A=Object.prototype,Z=A.toString,$=Math.max,B=Math.min,M=function(){return O.Date.now()};function te(u,g,w){var b,s,i,c,t,d,y=0,P=!1,k=!1,r=!0;if(typeof u!="function")throw new TypeError(a);g=z(g)||0,D(w)&&(P=!!w.leading,k="maxWait"in w,i=k?$(z(w.maxWait)||0,g):i,r="trailing"in w?!!w.trailing:r);function H(L){var U=b,q=s;return b=s=void 0,y=L,c=u.apply(q,U),c}function p(L){return y=L,t=setTimeout(x,g),P?H(L):c}function n(L){var U=L-d,q=L-y,Q=g-U;return k?B(Q,i-q):Q}function o(L){var U=L-d,q=L-y;return d===void 0||U>=g||U<0||k&&q>=i}function x(){var L=M();if(o(L))return _(L);t=setTimeout(x,n(L))}function _(L){return t=void 0,r&&b?H(L):(b=s=void 0,c)}function T(){t!==void 0&&clearTimeout(t),y=0,b=d=s=t=void 0}function I(){return t===void 0?c:_(M())}function E(){var L=M(),U=o(L);if(b=arguments,s=this,d=L,U){if(t===void 0)return p(d);if(k)return t=setTimeout(x,g),H(d)}return t===void 0&&(t=setTimeout(x,g)),c}return E.cancel=T,E.flush=I,E}function D(u){var g=typeof u;return!!u&&(g=="object"||g=="function")}function F(u){return!!u&&typeof u=="object"}function X(u){return typeof u=="symbol"||F(u)&&Z.call(u)==h}function z(u){if(typeof u=="number")return u;if(X(u))return l;if(D(u)){var g=typeof u.valueOf=="function"?u.valueOf():u;u=D(g)?g+"":g}if(typeof u!="string")return u===0?u:+u;u=u.replace(j,"");var w=v.test(u);return w||S.test(u)?N(u.slice(2),w?2:8):m.test(u)?l:+u}return Ye=te,Ye}var Je={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/var Zr;function Ue(){return Zr||(Zr=1,function(a){(function(){var l={}.hasOwnProperty;function h(){for(var v="",S=0;S<arguments.length;S++){var N=arguments[S];N&&(v=m(v,j(N)))}return v}function j(v){if(typeof v=="string"||typeof v=="number")return v;if(typeof v!="object")return"";if(Array.isArray(v))return h.apply(null,v);if(v.toString!==Object.prototype.toString&&!v.toString.toString().includes("[native code]"))return v.toString();var S="";for(var N in v)l.call(v,N)&&v[N]&&(S=m(S,N));return S}function m(v,S){return S?v?v+" "+S:v+S:v}a.exports?(h.default=h,a.exports=h):window.classNames=h})()}(Je)),Je.exports}var R={},et={},$r;function yn(){return $r||($r=1,function(a){Object.defineProperty(a,"__esModule",{value:!0}),a.default=void 0;var l=h(Oe());function h(m){return m&&m.__esModule?m:{default:m}}var j={accessibility:!0,adaptiveHeight:!1,afterChange:null,appendDots:function(v){return l.default.createElement("ul",{style:{display:"block"}},v)},arrows:!0,autoplay:!1,autoplaySpeed:3e3,beforeChange:null,centerMode:!1,centerPadding:"50px",className:"",cssEase:"ease",customPaging:function(v){return l.default.createElement("button",null,v+1)},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,infinite:!0,initialSlide:0,lazyLoad:null,nextArrow:null,onEdge:null,onInit:null,onLazyLoadError:null,onReInit:null,pauseOnDotsHover:!1,pauseOnFocus:!1,pauseOnHover:!0,prevArrow:null,responsive:null,rows:1,rtl:!1,slide:"div",slidesPerRow:1,slidesToScroll:1,slidesToShow:1,speed:500,swipe:!0,swipeEvent:null,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!0,variableWidth:!1,vertical:!1,waitForAnimate:!0,asNavFor:null,unslick:!1};a.default=j}(et)),et}var Kr;function Ae(){if(Kr)return R;Kr=1,Object.defineProperty(R,"__esModule",{value:!0}),R.checkSpecKeys=R.checkNavigable=R.changeSlide=R.canUseDOM=R.canGoNext=void 0,R.clamp=f,R.extractObject=void 0,R.filterSettings=H,R.validSettings=R.swipeStart=R.swipeMove=R.swipeEnd=R.slidesOnRight=R.slidesOnLeft=R.slideHandler=R.siblingDirection=R.safePreventDefault=R.lazyStartIndex=R.lazySlidesOnRight=R.lazySlidesOnLeft=R.lazyEndIndex=R.keyHandler=R.initializedState=R.getWidth=R.getTrackLeft=R.getTrackCSS=R.getTrackAnimateCSS=R.getTotalSlides=R.getSwipeDirection=R.getSlideCount=R.getRequiredLazySlides=R.getPreClones=R.getPostClones=R.getOnDemandLazySlides=R.getNavigableIndexes=R.getHeight=void 0;var a=h(Oe()),l=h(yn());function h(p){return p&&p.__esModule?p:{default:p}}function j(p){"@babel/helpers - typeof";return j=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(n){return typeof n}:function(n){return n&&typeof Symbol=="function"&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n},j(p)}function m(p,n){var o=Object.keys(p);if(Object.getOwnPropertySymbols){var x=Object.getOwnPropertySymbols(p);n&&(x=x.filter(function(_){return Object.getOwnPropertyDescriptor(p,_).enumerable})),o.push.apply(o,x)}return o}function v(p){for(var n=1;n<arguments.length;n++){var o=arguments[n]!=null?arguments[n]:{};n%2?m(Object(o),!0).forEach(function(x){S(p,x,o[x])}):Object.getOwnPropertyDescriptors?Object.defineProperties(p,Object.getOwnPropertyDescriptors(o)):m(Object(o)).forEach(function(x){Object.defineProperty(p,x,Object.getOwnPropertyDescriptor(o,x))})}return p}function S(p,n,o){return n=N(n),n in p?Object.defineProperty(p,n,{value:o,enumerable:!0,configurable:!0,writable:!0}):p[n]=o,p}function N(p){var n=C(p,"string");return j(n)=="symbol"?n:String(n)}function C(p,n){if(j(p)!="object"||!p)return p;var o=p[Symbol.toPrimitive];if(o!==void 0){var x=o.call(p,n);if(j(x)!="object")return x;throw new TypeError("@@toPrimitive must return a primitive value.")}return(n==="string"?String:Number)(p)}function f(p,n,o){return Math.max(n,Math.min(p,o))}var O=R.safePreventDefault=function(n){var o=["onTouchStart","onTouchMove","onWheel"];o.includes(n._reactName)||n.preventDefault()},A=R.getOnDemandLazySlides=function(n){for(var o=[],x=Z(n),_=$(n),T=x;T<_;T++)n.lazyLoadedList.indexOf(T)<0&&o.push(T);return o};R.getRequiredLazySlides=function(n){for(var o=[],x=Z(n),_=$(n),T=x;T<_;T++)o.push(T);return o};var Z=R.lazyStartIndex=function(n){return n.currentSlide-B(n)},$=R.lazyEndIndex=function(n){return n.currentSlide+M(n)},B=R.lazySlidesOnLeft=function(n){return n.centerMode?Math.floor(n.slidesToShow/2)+(parseInt(n.centerPadding)>0?1:0):0},M=R.lazySlidesOnRight=function(n){return n.centerMode?Math.floor((n.slidesToShow-1)/2)+1+(parseInt(n.centerPadding)>0?1:0):n.slidesToShow},te=R.getWidth=function(n){return n&&n.offsetWidth||0},D=R.getHeight=function(n){return n&&n.offsetHeight||0},F=R.getSwipeDirection=function(n){var o=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,x,_,T,I;return x=n.startX-n.curX,_=n.startY-n.curY,T=Math.atan2(_,x),I=Math.round(T*180/Math.PI),I<0&&(I=360-Math.abs(I)),I<=45&&I>=0||I<=360&&I>=315?"left":I>=135&&I<=225?"right":o===!0?I>=35&&I<=135?"up":"down":"vertical"},X=R.canGoNext=function(n){var o=!0;return n.infinite||(n.centerMode&&n.currentSlide>=n.slideCount-1||n.slideCount<=n.slidesToShow||n.currentSlide>=n.slideCount-n.slidesToShow)&&(o=!1),o};R.extractObject=function(n,o){var x={};return o.forEach(function(_){return x[_]=n[_]}),x},R.initializedState=function(n){var o=a.default.Children.count(n.children),x=n.listRef,_=Math.ceil(te(x)),T=n.trackRef&&n.trackRef.node,I=Math.ceil(te(T)),E;if(n.vertical)E=_;else{var L=n.centerMode&&parseInt(n.centerPadding)*2;typeof n.centerPadding=="string"&&n.centerPadding.slice(-1)==="%"&&(L*=_/100),E=Math.ceil((_-L)/n.slidesToShow)}var U=x&&D(x.querySelector('[data-index="0"]')),q=U*n.slidesToShow,Q=n.currentSlide===void 0?n.initialSlide:n.currentSlide;n.rtl&&n.currentSlide===void 0&&(Q=o-1-n.initialSlide);var J=n.lazyLoadedList||[],ee=A(v(v({},n),{},{currentSlide:Q,lazyLoadedList:J}));J=J.concat(ee);var W={slideCount:o,slideWidth:E,listWidth:_,trackWidth:I,currentSlide:Q,slideHeight:U,listHeight:q,lazyLoadedList:J};return n.autoplaying===null&&n.autoplay&&(W.autoplaying="playing"),W},R.slideHandler=function(n){var o=n.waitForAnimate,x=n.animating,_=n.fade,T=n.infinite,I=n.index,E=n.slideCount,L=n.lazyLoad,U=n.currentSlide,q=n.centerMode,Q=n.slidesToScroll,J=n.slidesToShow,ee=n.useCSS,W=n.lazyLoadedList;if(o&&x)return{};var K=I,Y,se,G,ae={},oe={},le=T?I:f(I,0,E-1);if(_){if(!T&&(I<0||I>=E))return{};I<0?K=I+E:I>=E&&(K=I-E),L&&W.indexOf(K)<0&&(W=W.concat(K)),ae={animating:!0,currentSlide:K,lazyLoadedList:W,targetSlide:K},oe={animating:!1,targetSlide:K}}else Y=K,K<0?(Y=K+E,T?E%Q!==0&&(Y=E-E%Q):Y=0):!X(n)&&K>U?K=Y=U:q&&K>=E?(K=T?E:E-1,Y=T?0:E-1):K>=E&&(Y=K-E,T?E%Q!==0&&(Y=0):Y=E-J),!T&&K+J>=E&&(Y=E-J),se=i(v(v({},n),{},{slideIndex:K})),G=i(v(v({},n),{},{slideIndex:Y})),T||(se===G&&(K=Y),se=G),L&&(W=W.concat(A(v(v({},n),{},{currentSlide:K})))),ee?(ae={animating:!0,currentSlide:Y,trackStyle:s(v(v({},n),{},{left:se})),lazyLoadedList:W,targetSlide:le},oe={animating:!1,currentSlide:Y,trackStyle:b(v(v({},n),{},{left:G})),swipeLeft:null,targetSlide:le}):ae={currentSlide:Y,trackStyle:b(v(v({},n),{},{left:G})),lazyLoadedList:W,targetSlide:le};return{state:ae,nextState:oe}},R.changeSlide=function(n,o){var x,_,T,I,E,L=n.slidesToScroll,U=n.slidesToShow,q=n.slideCount,Q=n.currentSlide,J=n.targetSlide,ee=n.lazyLoad,W=n.infinite;if(I=q%L!==0,x=I?0:(q-Q)%L,o.message==="previous")T=x===0?L:U-x,E=Q-T,ee&&!W&&(_=Q-T,E=_===-1?q-1:_),W||(E=J-L);else if(o.message==="next")T=x===0?L:x,E=Q+T,ee&&!W&&(E=(Q+L)%q+x),W||(E=J+L);else if(o.message==="dots")E=o.index*o.slidesToScroll;else if(o.message==="children"){if(E=o.index,W){var K=y(v(v({},n),{},{targetSlide:E}));E>o.currentSlide&&K==="left"?E=E-q:E<o.currentSlide&&K==="right"&&(E=E+q)}}else o.message==="index"&&(E=Number(o.index));return E},R.keyHandler=function(n,o,x){return n.target.tagName.match("TEXTAREA|INPUT|SELECT")||!o?"":n.keyCode===37?x?"next":"previous":n.keyCode===39?x?"previous":"next":""},R.swipeStart=function(n,o,x){return n.target.tagName==="IMG"&&O(n),!o||!x&&n.type.indexOf("mouse")!==-1?"":{dragging:!0,touchObject:{startX:n.touches?n.touches[0].pageX:n.clientX,startY:n.touches?n.touches[0].pageY:n.clientY,curX:n.touches?n.touches[0].pageX:n.clientX,curY:n.touches?n.touches[0].pageY:n.clientY}}},R.swipeMove=function(n,o){var x=o.scrolling,_=o.animating,T=o.vertical,I=o.swipeToSlide,E=o.verticalSwiping,L=o.rtl,U=o.currentSlide,q=o.edgeFriction,Q=o.edgeDragged,J=o.onEdge,ee=o.swiped,W=o.swiping,K=o.slideCount,Y=o.slidesToScroll,se=o.infinite,G=o.touchObject,ae=o.swipeEvent,oe=o.listHeight,le=o.listWidth;if(!x){if(_)return O(n);T&&I&&E&&O(n);var de,ve={},Ne=i(o);G.curX=n.touches?n.touches[0].pageX:n.clientX,G.curY=n.touches?n.touches[0].pageY:n.clientY,G.swipeLength=Math.round(Math.sqrt(Math.pow(G.curX-G.startX,2)));var _e=Math.round(Math.sqrt(Math.pow(G.curY-G.startY,2)));if(!E&&!W&&_e>10)return{scrolling:!0};E&&(G.swipeLength=_e);var je=(L?-1:1)*(G.curX>G.startX?1:-1);E&&(je=G.curY>G.startY?1:-1);var Ve=Math.ceil(K/Y),he=F(o.touchObject,E),Se=G.swipeLength;return se||(U===0&&(he==="right"||he==="down")||U+1>=Ve&&(he==="left"||he==="up")||!X(o)&&(he==="left"||he==="up"))&&(Se=G.swipeLength*q,Q===!1&&J&&(J(he),ve.edgeDragged=!0)),!ee&&ae&&(ae(he),ve.swiped=!0),T?de=Ne+Se*(oe/le)*je:L?de=Ne-Se*je:de=Ne+Se*je,E&&(de=Ne+Se*je),ve=v(v({},ve),{},{touchObject:G,swipeLeft:de,trackStyle:b(v(v({},o),{},{left:de}))}),Math.abs(G.curX-G.startX)<Math.abs(G.curY-G.startY)*.8||G.swipeLength>10&&(ve.swiping=!0,O(n)),ve}},R.swipeEnd=function(n,o){var x=o.dragging,_=o.swipe,T=o.touchObject,I=o.listWidth,E=o.touchThreshold,L=o.verticalSwiping,U=o.listHeight,q=o.swipeToSlide,Q=o.scrolling,J=o.onSwipe,ee=o.targetSlide,W=o.currentSlide,K=o.infinite;if(!x)return _&&O(n),{};var Y=L?U/E:I/E,se=F(T,L),G={dragging:!1,edgeDragged:!1,scrolling:!1,swiping:!1,swiped:!1,swipeLeft:null,touchObject:{}};if(Q||!T.swipeLength)return G;if(T.swipeLength>Y){O(n),J&&J(se);var ae,oe,le=K?W:ee;switch(se){case"left":case"up":oe=le+g(o),ae=q?u(o,oe):oe,G.currentDirection=0;break;case"right":case"down":oe=le-g(o),ae=q?u(o,oe):oe,G.currentDirection=1;break;default:ae=le}G.triggerSlideHandler=ae}else{var de=i(o);G.trackStyle=s(v(v({},o),{},{left:de}))}return G};var z=R.getNavigableIndexes=function(n){for(var o=n.infinite?n.slideCount*2:n.slideCount,x=n.infinite?n.slidesToShow*-1:0,_=n.infinite?n.slidesToShow*-1:0,T=[];x<o;)T.push(x),x=_+n.slidesToScroll,_+=Math.min(n.slidesToScroll,n.slidesToShow);return T},u=R.checkNavigable=function(n,o){var x=z(n),_=0;if(o>x[x.length-1])o=x[x.length-1];else for(var T in x){if(o<x[T]){o=_;break}_=x[T]}return o},g=R.getSlideCount=function(n){var o=n.centerMode?n.slideWidth*Math.floor(n.slidesToShow/2):0;if(n.swipeToSlide){var x,_=n.listRef,T=_.querySelectorAll&&_.querySelectorAll(".slick-slide")||[];if(Array.from(T).every(function(L){if(n.vertical){if(L.offsetTop+D(L)/2>n.swipeLeft*-1)return x=L,!1}else if(L.offsetLeft-o+te(L)/2>n.swipeLeft*-1)return x=L,!1;return!0}),!x)return 0;var I=n.rtl===!0?n.slideCount-n.currentSlide:n.currentSlide,E=Math.abs(x.dataset.index-I)||1;return E}else return n.slidesToScroll},w=R.checkSpecKeys=function(n,o){return o.reduce(function(x,_){return x&&n.hasOwnProperty(_)},!0)?null:console.error("Keys Missing:",n)},b=R.getTrackCSS=function(n){w(n,["left","variableWidth","slideCount","slidesToShow","slideWidth"]);var o,x,_=n.slideCount+2*n.slidesToShow;n.vertical?x=_*n.slideHeight:o=d(n)*n.slideWidth;var T={opacity:1,transition:"",WebkitTransition:""};if(n.useTransform){var I=n.vertical?"translate3d(0px, "+n.left+"px, 0px)":"translate3d("+n.left+"px, 0px, 0px)",E=n.vertical?"translate3d(0px, "+n.left+"px, 0px)":"translate3d("+n.left+"px, 0px, 0px)",L=n.vertical?"translateY("+n.left+"px)":"translateX("+n.left+"px)";T=v(v({},T),{},{WebkitTransform:I,transform:E,msTransform:L})}else n.vertical?T.top=n.left:T.left=n.left;return n.fade&&(T={opacity:1}),o&&(T.width=o),x&&(T.height=x),window&&!window.addEventListener&&window.attachEvent&&(n.vertical?T.marginTop=n.left+"px":T.marginLeft=n.left+"px"),T},s=R.getTrackAnimateCSS=function(n){w(n,["left","variableWidth","slideCount","slidesToShow","slideWidth","speed","cssEase"]);var o=b(n);return n.useTransform?(o.WebkitTransition="-webkit-transform "+n.speed+"ms "+n.cssEase,o.transition="transform "+n.speed+"ms "+n.cssEase):n.vertical?o.transition="top "+n.speed+"ms "+n.cssEase:o.transition="left "+n.speed+"ms "+n.cssEase,o},i=R.getTrackLeft=function(n){if(n.unslick)return 0;w(n,["slideIndex","trackRef","infinite","centerMode","slideCount","slidesToShow","slidesToScroll","slideWidth","listWidth","variableWidth","slideHeight"]);var o=n.slideIndex,x=n.trackRef,_=n.infinite,T=n.centerMode,I=n.slideCount,E=n.slidesToShow,L=n.slidesToScroll,U=n.slideWidth,q=n.listWidth,Q=n.variableWidth,J=n.slideHeight,ee=n.fade,W=n.vertical,K=0,Y,se,G=0;if(ee||n.slideCount===1)return 0;var ae=0;if(_?(ae=-c(n),I%L!==0&&o+L>I&&(ae=-(o>I?E-(o-I):I%L)),T&&(ae+=parseInt(E/2))):(I%L!==0&&o+L>I&&(ae=E-I%L),T&&(ae=parseInt(E/2))),K=ae*U,G=ae*J,W?Y=o*J*-1+G:Y=o*U*-1+K,Q===!0){var oe,le=x&&x.node;if(oe=o+c(n),se=le&&le.childNodes[oe],Y=se?se.offsetLeft*-1:0,T===!0){oe=_?o+c(n):o,se=le&&le.children[oe],Y=0;for(var de=0;de<oe;de++)Y-=le&&le.children[de]&&le.children[de].offsetWidth;Y-=parseInt(n.centerPadding),Y+=se&&(q-se.offsetWidth)/2}}return Y},c=R.getPreClones=function(n){return n.unslick||!n.infinite?0:n.variableWidth?n.slideCount:n.slidesToShow+(n.centerMode?1:0)},t=R.getPostClones=function(n){return n.unslick||!n.infinite?0:n.slideCount},d=R.getTotalSlides=function(n){return n.slideCount===1?1:c(n)+n.slideCount+t(n)},y=R.siblingDirection=function(n){return n.targetSlide>n.currentSlide?n.targetSlide>n.currentSlide+P(n)?"left":"right":n.targetSlide<n.currentSlide-k(n)?"right":"left"},P=R.slidesOnRight=function(n){var o=n.slidesToShow,x=n.centerMode,_=n.rtl,T=n.centerPadding;if(x){var I=(o-1)/2+1;return parseInt(T)>0&&(I+=1),_&&o%2===0&&(I+=1),I}return _?0:o-1},k=R.slidesOnLeft=function(n){var o=n.slidesToShow,x=n.centerMode,_=n.rtl,T=n.centerPadding;if(x){var I=(o-1)/2+1;return parseInt(T)>0&&(I+=1),!_&&o%2===0&&(I+=1),I}return _?o-1:0};R.canUseDOM=function(){return!!(typeof window<"u"&&window.document&&window.document.createElement)};var r=R.validSettings=Object.keys(l.default);function H(p){return r.reduce(function(n,o){return p.hasOwnProperty(o)&&(n[o]=p[o]),n},{})}return R}var Me={},Qr;function Di(){if(Qr)return Me;Qr=1,Object.defineProperty(Me,"__esModule",{value:!0}),Me.Track=void 0;var a=j(Oe()),l=j(Ue()),h=Ae();function j(s){return s&&s.__esModule?s:{default:s}}function m(s){"@babel/helpers - typeof";return m=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(i){return typeof i}:function(i){return i&&typeof Symbol=="function"&&i.constructor===Symbol&&i!==Symbol.prototype?"symbol":typeof i},m(s)}function v(){return v=Object.assign?Object.assign.bind():function(s){for(var i=1;i<arguments.length;i++){var c=arguments[i];for(var t in c)Object.prototype.hasOwnProperty.call(c,t)&&(s[t]=c[t])}return s},v.apply(this,arguments)}function S(s,i){if(!(s instanceof i))throw new TypeError("Cannot call a class as a function")}function N(s,i){for(var c=0;c<i.length;c++){var t=i[c];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(s,X(t.key),t)}}function C(s,i,c){return i&&N(s.prototype,i),Object.defineProperty(s,"prototype",{writable:!1}),s}function f(s,i){if(typeof i!="function"&&i!==null)throw new TypeError("Super expression must either be null or a function");s.prototype=Object.create(i&&i.prototype,{constructor:{value:s,writable:!0,configurable:!0}}),Object.defineProperty(s,"prototype",{writable:!1}),i&&O(s,i)}function O(s,i){return O=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,d){return t.__proto__=d,t},O(s,i)}function A(s){var i=B();return function(){var t=M(s),d;if(i){var y=M(this).constructor;d=Reflect.construct(t,arguments,y)}else d=t.apply(this,arguments);return Z(this,d)}}function Z(s,i){if(i&&(m(i)==="object"||typeof i=="function"))return i;if(i!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return $(s)}function $(s){if(s===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return s}function B(){try{var s=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(B=function(){return!!s})()}function M(s){return M=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(c){return c.__proto__||Object.getPrototypeOf(c)},M(s)}function te(s,i){var c=Object.keys(s);if(Object.getOwnPropertySymbols){var t=Object.getOwnPropertySymbols(s);i&&(t=t.filter(function(d){return Object.getOwnPropertyDescriptor(s,d).enumerable})),c.push.apply(c,t)}return c}function D(s){for(var i=1;i<arguments.length;i++){var c=arguments[i]!=null?arguments[i]:{};i%2?te(Object(c),!0).forEach(function(t){F(s,t,c[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(s,Object.getOwnPropertyDescriptors(c)):te(Object(c)).forEach(function(t){Object.defineProperty(s,t,Object.getOwnPropertyDescriptor(c,t))})}return s}function F(s,i,c){return i=X(i),i in s?Object.defineProperty(s,i,{value:c,enumerable:!0,configurable:!0,writable:!0}):s[i]=c,s}function X(s){var i=z(s,"string");return m(i)=="symbol"?i:String(i)}function z(s,i){if(m(s)!="object"||!s)return s;var c=s[Symbol.toPrimitive];if(c!==void 0){var t=c.call(s,i);if(m(t)!="object")return t;throw new TypeError("@@toPrimitive must return a primitive value.")}return(i==="string"?String:Number)(s)}var u=function(i){var c,t,d,y,P;i.rtl?P=i.slideCount-1-i.index:P=i.index,d=P<0||P>=i.slideCount,i.centerMode?(y=Math.floor(i.slidesToShow/2),t=(P-i.currentSlide)%i.slideCount===0,P>i.currentSlide-y-1&&P<=i.currentSlide+y&&(c=!0)):c=i.currentSlide<=P&&P<i.currentSlide+i.slidesToShow;var k;i.targetSlide<0?k=i.targetSlide+i.slideCount:i.targetSlide>=i.slideCount?k=i.targetSlide-i.slideCount:k=i.targetSlide;var r=P===k;return{"slick-slide":!0,"slick-active":c,"slick-center":t,"slick-cloned":d,"slick-current":r}},g=function(i){var c={};return(i.variableWidth===void 0||i.variableWidth===!1)&&(c.width=i.slideWidth),i.fade&&(c.position="relative",i.vertical?c.top=-i.index*parseInt(i.slideHeight):c.left=-i.index*parseInt(i.slideWidth),c.opacity=i.currentSlide===i.index?1:0,c.zIndex=i.currentSlide===i.index?999:998,i.useCSS&&(c.transition="opacity "+i.speed+"ms "+i.cssEase+", visibility "+i.speed+"ms "+i.cssEase)),c},w=function(i,c){return i.key||c},b=function(i){var c,t=[],d=[],y=[],P=a.default.Children.count(i.children),k=(0,h.lazyStartIndex)(i),r=(0,h.lazyEndIndex)(i);return a.default.Children.forEach(i.children,function(H,p){var n,o={message:"children",index:p,slidesToScroll:i.slidesToScroll,currentSlide:i.currentSlide};!i.lazyLoad||i.lazyLoad&&i.lazyLoadedList.indexOf(p)>=0?n=H:n=a.default.createElement("div",null);var x=g(D(D({},i),{},{index:p})),_=n.props.className||"",T=u(D(D({},i),{},{index:p}));if(t.push(a.default.cloneElement(n,{key:"original"+w(n,p),"data-index":p,className:(0,l.default)(T,_),tabIndex:"-1","aria-hidden":!T["slick-active"],style:D(D({outline:"none"},n.props.style||{}),x),onClick:function(L){n.props&&n.props.onClick&&n.props.onClick(L),i.focusOnSelect&&i.focusOnSelect(o)}})),i.infinite&&i.fade===!1){var I=P-p;I<=(0,h.getPreClones)(i)&&(c=-I,c>=k&&(n=H),T=u(D(D({},i),{},{index:c})),d.push(a.default.cloneElement(n,{key:"precloned"+w(n,c),"data-index":c,tabIndex:"-1",className:(0,l.default)(T,_),"aria-hidden":!T["slick-active"],style:D(D({},n.props.style||{}),x),onClick:function(L){n.props&&n.props.onClick&&n.props.onClick(L),i.focusOnSelect&&i.focusOnSelect(o)}}))),c=P+p,c<r&&(n=H),T=u(D(D({},i),{},{index:c})),y.push(a.default.cloneElement(n,{key:"postcloned"+w(n,c),"data-index":c,tabIndex:"-1",className:(0,l.default)(T,_),"aria-hidden":!T["slick-active"],style:D(D({},n.props.style||{}),x),onClick:function(L){n.props&&n.props.onClick&&n.props.onClick(L),i.focusOnSelect&&i.focusOnSelect(o)}}))}}),i.rtl?d.concat(t,y).reverse():d.concat(t,y)};return Me.Track=function(s){f(c,s);var i=A(c);function c(){var t;S(this,c);for(var d=arguments.length,y=new Array(d),P=0;P<d;P++)y[P]=arguments[P];return t=i.call.apply(i,[this].concat(y)),F($(t),"node",null),F($(t),"handleRef",function(k){t.node=k}),t}return C(c,[{key:"render",value:function(){var d=b(this.props),y=this.props,P=y.onMouseEnter,k=y.onMouseOver,r=y.onMouseLeave,H={onMouseEnter:P,onMouseOver:k,onMouseLeave:r};return a.default.createElement("div",v({ref:this.handleRef,className:"slick-track",style:this.props.trackStyle},H),d)}}]),c}(a.default.PureComponent),Me}var Ie={},Gr;function Ai(){if(Gr)return Ie;Gr=1;function a(u){"@babel/helpers - typeof";return a=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(g){return typeof g}:function(g){return g&&typeof Symbol=="function"&&g.constructor===Symbol&&g!==Symbol.prototype?"symbol":typeof g},a(u)}Object.defineProperty(Ie,"__esModule",{value:!0}),Ie.Dots=void 0;var l=m(Oe()),h=m(Ue()),j=Ae();function m(u){return u&&u.__esModule?u:{default:u}}function v(u,g){var w=Object.keys(u);if(Object.getOwnPropertySymbols){var b=Object.getOwnPropertySymbols(u);g&&(b=b.filter(function(s){return Object.getOwnPropertyDescriptor(u,s).enumerable})),w.push.apply(w,b)}return w}function S(u){for(var g=1;g<arguments.length;g++){var w=arguments[g]!=null?arguments[g]:{};g%2?v(Object(w),!0).forEach(function(b){N(u,b,w[b])}):Object.getOwnPropertyDescriptors?Object.defineProperties(u,Object.getOwnPropertyDescriptors(w)):v(Object(w)).forEach(function(b){Object.defineProperty(u,b,Object.getOwnPropertyDescriptor(w,b))})}return u}function N(u,g,w){return g=A(g),g in u?Object.defineProperty(u,g,{value:w,enumerable:!0,configurable:!0,writable:!0}):u[g]=w,u}function C(u,g){if(!(u instanceof g))throw new TypeError("Cannot call a class as a function")}function f(u,g){for(var w=0;w<g.length;w++){var b=g[w];b.enumerable=b.enumerable||!1,b.configurable=!0,"value"in b&&(b.writable=!0),Object.defineProperty(u,A(b.key),b)}}function O(u,g,w){return g&&f(u.prototype,g),Object.defineProperty(u,"prototype",{writable:!1}),u}function A(u){var g=Z(u,"string");return a(g)=="symbol"?g:String(g)}function Z(u,g){if(a(u)!="object"||!u)return u;var w=u[Symbol.toPrimitive];if(w!==void 0){var b=w.call(u,g);if(a(b)!="object")return b;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(u)}function $(u,g){if(typeof g!="function"&&g!==null)throw new TypeError("Super expression must either be null or a function");u.prototype=Object.create(g&&g.prototype,{constructor:{value:u,writable:!0,configurable:!0}}),Object.defineProperty(u,"prototype",{writable:!1}),g&&B(u,g)}function B(u,g){return B=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(b,s){return b.__proto__=s,b},B(u,g)}function M(u){var g=F();return function(){var b=X(u),s;if(g){var i=X(this).constructor;s=Reflect.construct(b,arguments,i)}else s=b.apply(this,arguments);return te(this,s)}}function te(u,g){if(g&&(a(g)==="object"||typeof g=="function"))return g;if(g!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return D(u)}function D(u){if(u===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return u}function F(){try{var u=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(F=function(){return!!u})()}function X(u){return X=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(w){return w.__proto__||Object.getPrototypeOf(w)},X(u)}var z=function(g){var w;return g.infinite?w=Math.ceil(g.slideCount/g.slidesToScroll):w=Math.ceil((g.slideCount-g.slidesToShow)/g.slidesToScroll)+1,w};return Ie.Dots=function(u){$(w,u);var g=M(w);function w(){return C(this,w),g.apply(this,arguments)}return O(w,[{key:"clickHandler",value:function(s,i){i.preventDefault(),this.props.clickHandler(s)}},{key:"render",value:function(){for(var s=this.props,i=s.onMouseEnter,c=s.onMouseOver,t=s.onMouseLeave,d=s.infinite,y=s.slidesToScroll,P=s.slidesToShow,k=s.slideCount,r=s.currentSlide,H=z({slideCount:k,slidesToScroll:y,slidesToShow:P,infinite:d}),p={onMouseEnter:i,onMouseOver:c,onMouseLeave:t},n=[],o=0;o<H;o++){var x=(o+1)*y-1,_=d?x:(0,j.clamp)(x,0,k-1),T=_-(y-1),I=d?T:(0,j.clamp)(T,0,k-1),E=(0,h.default)({"slick-active":d?r>=I&&r<=_:r===I}),L={message:"dots",index:o,slidesToScroll:y,currentSlide:r},U=this.clickHandler.bind(this,L);n=n.concat(l.default.createElement("li",{key:o,className:E},l.default.cloneElement(this.props.customPaging(o),{onClick:U})))}return l.default.cloneElement(this.props.appendDots(n),S({className:this.props.dotsClass},p))}}]),w}(l.default.PureComponent),Ie}var ke={},Xr;function Vi(){if(Xr)return ke;Xr=1;function a(u){"@babel/helpers - typeof";return a=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(g){return typeof g}:function(g){return g&&typeof Symbol=="function"&&g.constructor===Symbol&&g!==Symbol.prototype?"symbol":typeof g},a(u)}Object.defineProperty(ke,"__esModule",{value:!0}),ke.PrevArrow=ke.NextArrow=void 0;var l=m(Oe()),h=m(Ue()),j=Ae();function m(u){return u&&u.__esModule?u:{default:u}}function v(){return v=Object.assign?Object.assign.bind():function(u){for(var g=1;g<arguments.length;g++){var w=arguments[g];for(var b in w)Object.prototype.hasOwnProperty.call(w,b)&&(u[b]=w[b])}return u},v.apply(this,arguments)}function S(u,g){var w=Object.keys(u);if(Object.getOwnPropertySymbols){var b=Object.getOwnPropertySymbols(u);g&&(b=b.filter(function(s){return Object.getOwnPropertyDescriptor(u,s).enumerable})),w.push.apply(w,b)}return w}function N(u){for(var g=1;g<arguments.length;g++){var w=arguments[g]!=null?arguments[g]:{};g%2?S(Object(w),!0).forEach(function(b){C(u,b,w[b])}):Object.getOwnPropertyDescriptors?Object.defineProperties(u,Object.getOwnPropertyDescriptors(w)):S(Object(w)).forEach(function(b){Object.defineProperty(u,b,Object.getOwnPropertyDescriptor(w,b))})}return u}function C(u,g,w){return g=Z(g),g in u?Object.defineProperty(u,g,{value:w,enumerable:!0,configurable:!0,writable:!0}):u[g]=w,u}function f(u,g){if(!(u instanceof g))throw new TypeError("Cannot call a class as a function")}function O(u,g){for(var w=0;w<g.length;w++){var b=g[w];b.enumerable=b.enumerable||!1,b.configurable=!0,"value"in b&&(b.writable=!0),Object.defineProperty(u,Z(b.key),b)}}function A(u,g,w){return g&&O(u.prototype,g),Object.defineProperty(u,"prototype",{writable:!1}),u}function Z(u){var g=$(u,"string");return a(g)=="symbol"?g:String(g)}function $(u,g){if(a(u)!="object"||!u)return u;var w=u[Symbol.toPrimitive];if(w!==void 0){var b=w.call(u,g);if(a(b)!="object")return b;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(u)}function B(u,g){if(typeof g!="function"&&g!==null)throw new TypeError("Super expression must either be null or a function");u.prototype=Object.create(g&&g.prototype,{constructor:{value:u,writable:!0,configurable:!0}}),Object.defineProperty(u,"prototype",{writable:!1}),g&&M(u,g)}function M(u,g){return M=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(b,s){return b.__proto__=s,b},M(u,g)}function te(u){var g=X();return function(){var b=z(u),s;if(g){var i=z(this).constructor;s=Reflect.construct(b,arguments,i)}else s=b.apply(this,arguments);return D(this,s)}}function D(u,g){if(g&&(a(g)==="object"||typeof g=="function"))return g;if(g!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return F(u)}function F(u){if(u===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return u}function X(){try{var u=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(X=function(){return!!u})()}function z(u){return z=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(w){return w.__proto__||Object.getPrototypeOf(w)},z(u)}return ke.PrevArrow=function(u){B(w,u);var g=te(w);function w(){return f(this,w),g.apply(this,arguments)}return A(w,[{key:"clickHandler",value:function(s,i){i&&i.preventDefault(),this.props.clickHandler(s,i)}},{key:"render",value:function(){var s={"slick-arrow":!0,"slick-prev":!0},i=this.clickHandler.bind(this,{message:"previous"});!this.props.infinite&&(this.props.currentSlide===0||this.props.slideCount<=this.props.slidesToShow)&&(s["slick-disabled"]=!0,i=null);var c={key:"0","data-role":"none",className:(0,h.default)(s),style:{display:"block"},onClick:i},t={currentSlide:this.props.currentSlide,slideCount:this.props.slideCount},d;return this.props.prevArrow?d=l.default.cloneElement(this.props.prevArrow,N(N({},c),t)):d=l.default.createElement("button",v({key:"0",type:"button"},c)," ","Previous"),d}}]),w}(l.default.PureComponent),ke.NextArrow=function(u){B(w,u);var g=te(w);function w(){return f(this,w),g.apply(this,arguments)}return A(w,[{key:"clickHandler",value:function(s,i){i&&i.preventDefault(),this.props.clickHandler(s,i)}},{key:"render",value:function(){var s={"slick-arrow":!0,"slick-next":!0},i=this.clickHandler.bind(this,{message:"next"});(0,j.canGoNext)(this.props)||(s["slick-disabled"]=!0,i=null);var c={key:"1","data-role":"none",className:(0,h.default)(s),style:{display:"block"},onClick:i},t={currentSlide:this.props.currentSlide,slideCount:this.props.slideCount},d;return this.props.nextArrow?d=l.default.cloneElement(this.props.nextArrow,N(N({},c),t)):d=l.default.createElement("button",v({key:"1",type:"button"},c)," ","Next"),d}}]),w}(l.default.PureComponent),ke}var xn=function(){if(typeof Map<"u")return Map;function a(l,h){var j=-1;return l.some(function(m,v){return m[0]===h?(j=v,!0):!1}),j}return function(){function l(){this.__entries__=[]}return Object.defineProperty(l.prototype,"size",{get:function(){return this.__entries__.length},enumerable:!0,configurable:!0}),l.prototype.get=function(h){var j=a(this.__entries__,h),m=this.__entries__[j];return m&&m[1]},l.prototype.set=function(h,j){var m=a(this.__entries__,h);~m?this.__entries__[m][1]=j:this.__entries__.push([h,j])},l.prototype.delete=function(h){var j=this.__entries__,m=a(j,h);~m&&j.splice(m,1)},l.prototype.has=function(h){return!!~a(this.__entries__,h)},l.prototype.clear=function(){this.__entries__.splice(0)},l.prototype.forEach=function(h,j){j===void 0&&(j=null);for(var m=0,v=this.__entries__;m<v.length;m++){var S=v[m];h.call(j,S[1],S[0])}},l}()}(),ct=typeof window<"u"&&typeof document<"u"&&window.document===document,Be=function(){return typeof globalThis<"u"&&globalThis.Math===Math?globalThis:typeof self<"u"&&self.Math===Math?self:typeof window<"u"&&window.Math===Math?window:Function("return this")()}(),zi=function(){return typeof requestAnimationFrame=="function"?requestAnimationFrame.bind(Be):function(a){return setTimeout(function(){return a(Date.now())},1e3/60)}}(),Hi=2;function Bi(a,l){var h=!1,j=!1,m=0;function v(){h&&(h=!1,a()),j&&N()}function S(){zi(v)}function N(){var C=Date.now();if(h){if(C-m<Hi)return;j=!0}else h=!0,j=!1,setTimeout(S,l);m=C}return N}var Fi=20,Ui=["top","right","bottom","left","width","height","size","weight"],qi=typeof MutationObserver<"u",Wi=function(){function a(){this.connected_=!1,this.mutationEventsAdded_=!1,this.mutationsObserver_=null,this.observers_=[],this.onTransitionEnd_=this.onTransitionEnd_.bind(this),this.refresh=Bi(this.refresh.bind(this),Fi)}return a.prototype.addObserver=function(l){~this.observers_.indexOf(l)||this.observers_.push(l),this.connected_||this.connect_()},a.prototype.removeObserver=function(l){var h=this.observers_,j=h.indexOf(l);~j&&h.splice(j,1),!h.length&&this.connected_&&this.disconnect_()},a.prototype.refresh=function(){var l=this.updateObservers_();l&&this.refresh()},a.prototype.updateObservers_=function(){var l=this.observers_.filter(function(h){return h.gatherActive(),h.hasActive()});return l.forEach(function(h){return h.broadcastActive()}),l.length>0},a.prototype.connect_=function(){!ct||this.connected_||(document.addEventListener("transitionend",this.onTransitionEnd_),window.addEventListener("resize",this.refresh),qi?(this.mutationsObserver_=new MutationObserver(this.refresh),this.mutationsObserver_.observe(document,{attributes:!0,childList:!0,characterData:!0,subtree:!0})):(document.addEventListener("DOMSubtreeModified",this.refresh),this.mutationEventsAdded_=!0),this.connected_=!0)},a.prototype.disconnect_=function(){!ct||!this.connected_||(document.removeEventListener("transitionend",this.onTransitionEnd_),window.removeEventListener("resize",this.refresh),this.mutationsObserver_&&this.mutationsObserver_.disconnect(),this.mutationEventsAdded_&&document.removeEventListener("DOMSubtreeModified",this.refresh),this.mutationsObserver_=null,this.mutationEventsAdded_=!1,this.connected_=!1)},a.prototype.onTransitionEnd_=function(l){var h=l.propertyName,j=h===void 0?"":h,m=Ui.some(function(v){return!!~j.indexOf(v)});m&&this.refresh()},a.getInstance=function(){return this.instance_||(this.instance_=new a),this.instance_},a.instance_=null,a}(),jn=function(a,l){for(var h=0,j=Object.keys(l);h<j.length;h++){var m=j[h];Object.defineProperty(a,m,{value:l[m],enumerable:!1,writable:!1,configurable:!0})}return a},Pe=function(a){var l=a&&a.ownerDocument&&a.ownerDocument.defaultView;return l||Be},Sn=qe(0,0,0,0);function Fe(a){return parseFloat(a)||0}function Yr(a){for(var l=[],h=1;h<arguments.length;h++)l[h-1]=arguments[h];return l.reduce(function(j,m){var v=a["border-"+m+"-width"];return j+Fe(v)},0)}function Zi(a){for(var l=["top","right","bottom","left"],h={},j=0,m=l;j<m.length;j++){var v=m[j],S=a["padding-"+v];h[v]=Fe(S)}return h}function $i(a){var l=a.getBBox();return qe(0,0,l.width,l.height)}function Ki(a){var l=a.clientWidth,h=a.clientHeight;if(!l&&!h)return Sn;var j=Pe(a).getComputedStyle(a),m=Zi(j),v=m.left+m.right,S=m.top+m.bottom,N=Fe(j.width),C=Fe(j.height);if(j.boxSizing==="border-box"&&(Math.round(N+v)!==l&&(N-=Yr(j,"left","right")+v),Math.round(C+S)!==h&&(C-=Yr(j,"top","bottom")+S)),!Gi(a)){var f=Math.round(N+v)-l,O=Math.round(C+S)-h;Math.abs(f)!==1&&(N-=f),Math.abs(O)!==1&&(C-=O)}return qe(m.left,m.top,N,C)}var Qi=function(){return typeof SVGGraphicsElement<"u"?function(a){return a instanceof Pe(a).SVGGraphicsElement}:function(a){return a instanceof Pe(a).SVGElement&&typeof a.getBBox=="function"}}();function Gi(a){return a===Pe(a).document.documentElement}function Xi(a){return ct?Qi(a)?$i(a):Ki(a):Sn}function Yi(a){var l=a.x,h=a.y,j=a.width,m=a.height,v=typeof DOMRectReadOnly<"u"?DOMRectReadOnly:Object,S=Object.create(v.prototype);return jn(S,{x:l,y:h,width:j,height:m,top:h,right:l+j,bottom:m+h,left:l}),S}function qe(a,l,h,j){return{x:a,y:l,width:h,height:j}}var Ji=function(){function a(l){this.broadcastWidth=0,this.broadcastHeight=0,this.contentRect_=qe(0,0,0,0),this.target=l}return a.prototype.isActive=function(){var l=Xi(this.target);return this.contentRect_=l,l.width!==this.broadcastWidth||l.height!==this.broadcastHeight},a.prototype.broadcastRect=function(){var l=this.contentRect_;return this.broadcastWidth=l.width,this.broadcastHeight=l.height,l},a}(),ea=function(){function a(l,h){var j=Yi(h);jn(this,{target:l,contentRect:j})}return a}(),ta=function(){function a(l,h,j){if(this.activeObservations_=[],this.observations_=new xn,typeof l!="function")throw new TypeError("The callback provided as parameter 1 is not a function.");this.callback_=l,this.controller_=h,this.callbackCtx_=j}return a.prototype.observe=function(l){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");if(!(typeof Element>"u"||!(Element instanceof Object))){if(!(l instanceof Pe(l).Element))throw new TypeError('parameter 1 is not of type "Element".');var h=this.observations_;h.has(l)||(h.set(l,new Ji(l)),this.controller_.addObserver(this),this.controller_.refresh())}},a.prototype.unobserve=function(l){if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");if(!(typeof Element>"u"||!(Element instanceof Object))){if(!(l instanceof Pe(l).Element))throw new TypeError('parameter 1 is not of type "Element".');var h=this.observations_;h.has(l)&&(h.delete(l),h.size||this.controller_.removeObserver(this))}},a.prototype.disconnect=function(){this.clearActive(),this.observations_.clear(),this.controller_.removeObserver(this)},a.prototype.gatherActive=function(){var l=this;this.clearActive(),this.observations_.forEach(function(h){h.isActive()&&l.activeObservations_.push(h)})},a.prototype.broadcastActive=function(){if(this.hasActive()){var l=this.callbackCtx_,h=this.activeObservations_.map(function(j){return new ea(j.target,j.broadcastRect())});this.callback_.call(l,h,l),this.clearActive()}},a.prototype.clearActive=function(){this.activeObservations_.splice(0)},a.prototype.hasActive=function(){return this.activeObservations_.length>0},a}(),wn=typeof WeakMap<"u"?new WeakMap:new xn,Cn=function(){function a(l){if(!(this instanceof a))throw new TypeError("Cannot call a class as a function.");if(!arguments.length)throw new TypeError("1 argument required, but only 0 present.");var h=Wi.getInstance(),j=new ta(l,h,this);wn.set(this,j)}return a}();["observe","unobserve","disconnect"].forEach(function(a){Cn.prototype[a]=function(){var l;return(l=wn.get(this))[a].apply(l,arguments)}});var ra=function(){return typeof Be.ResizeObserver<"u"?Be.ResizeObserver:Cn}();const na=Object.freeze(Object.defineProperty({__proto__:null,default:ra},Symbol.toStringTag,{value:"Module"})),ia=Rn(na);var Jr;function aa(){if(Jr)return Ee;Jr=1,Object.defineProperty(Ee,"__esModule",{value:!0}),Ee.InnerSlider=void 0;var a=f(Oe()),l=f(Li()),h=f(Ri()),j=f(Ue()),m=Ae(),v=Di(),S=Ai(),N=Vi(),C=f(ia);function f(d){return d&&d.__esModule?d:{default:d}}function O(d){"@babel/helpers - typeof";return O=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(y){return typeof y}:function(y){return y&&typeof Symbol=="function"&&y.constructor===Symbol&&y!==Symbol.prototype?"symbol":typeof y},O(d)}function A(){return A=Object.assign?Object.assign.bind():function(d){for(var y=1;y<arguments.length;y++){var P=arguments[y];for(var k in P)Object.prototype.hasOwnProperty.call(P,k)&&(d[k]=P[k])}return d},A.apply(this,arguments)}function Z(d,y){if(d==null)return{};var P=$(d,y),k,r;if(Object.getOwnPropertySymbols){var H=Object.getOwnPropertySymbols(d);for(r=0;r<H.length;r++)k=H[r],!(y.indexOf(k)>=0)&&Object.prototype.propertyIsEnumerable.call(d,k)&&(P[k]=d[k])}return P}function $(d,y){if(d==null)return{};var P={},k=Object.keys(d),r,H;for(H=0;H<k.length;H++)r=k[H],!(y.indexOf(r)>=0)&&(P[r]=d[r]);return P}function B(d,y){var P=Object.keys(d);if(Object.getOwnPropertySymbols){var k=Object.getOwnPropertySymbols(d);y&&(k=k.filter(function(r){return Object.getOwnPropertyDescriptor(d,r).enumerable})),P.push.apply(P,k)}return P}function M(d){for(var y=1;y<arguments.length;y++){var P=arguments[y]!=null?arguments[y]:{};y%2?B(Object(P),!0).forEach(function(k){i(d,k,P[k])}):Object.getOwnPropertyDescriptors?Object.defineProperties(d,Object.getOwnPropertyDescriptors(P)):B(Object(P)).forEach(function(k){Object.defineProperty(d,k,Object.getOwnPropertyDescriptor(P,k))})}return d}function te(d,y){if(!(d instanceof y))throw new TypeError("Cannot call a class as a function")}function D(d,y){for(var P=0;P<y.length;P++){var k=y[P];k.enumerable=k.enumerable||!1,k.configurable=!0,"value"in k&&(k.writable=!0),Object.defineProperty(d,c(k.key),k)}}function F(d,y,P){return y&&D(d.prototype,y),Object.defineProperty(d,"prototype",{writable:!1}),d}function X(d,y){if(typeof y!="function"&&y!==null)throw new TypeError("Super expression must either be null or a function");d.prototype=Object.create(y&&y.prototype,{constructor:{value:d,writable:!0,configurable:!0}}),Object.defineProperty(d,"prototype",{writable:!1}),y&&z(d,y)}function z(d,y){return z=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(k,r){return k.__proto__=r,k},z(d,y)}function u(d){var y=b();return function(){var k=s(d),r;if(y){var H=s(this).constructor;r=Reflect.construct(k,arguments,H)}else r=k.apply(this,arguments);return g(this,r)}}function g(d,y){if(y&&(O(y)==="object"||typeof y=="function"))return y;if(y!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return w(d)}function w(d){if(d===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return d}function b(){try{var d=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(b=function(){return!!d})()}function s(d){return s=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(P){return P.__proto__||Object.getPrototypeOf(P)},s(d)}function i(d,y,P){return y=c(y),y in d?Object.defineProperty(d,y,{value:P,enumerable:!0,configurable:!0,writable:!0}):d[y]=P,d}function c(d){var y=t(d,"string");return O(y)=="symbol"?y:String(y)}function t(d,y){if(O(d)!="object"||!d)return d;var P=d[Symbol.toPrimitive];if(P!==void 0){var k=P.call(d,y);if(O(k)!="object")return k;throw new TypeError("@@toPrimitive must return a primitive value.")}return(y==="string"?String:Number)(d)}return Ee.InnerSlider=function(d){X(P,d);var y=u(P);function P(k){var r;te(this,P),r=y.call(this,k),i(w(r),"listRefHandler",function(p){return r.list=p}),i(w(r),"trackRefHandler",function(p){return r.track=p}),i(w(r),"adaptHeight",function(){if(r.props.adaptiveHeight&&r.list){var p=r.list.querySelector('[data-index="'.concat(r.state.currentSlide,'"]'));r.list.style.height=(0,m.getHeight)(p)+"px"}}),i(w(r),"componentDidMount",function(){if(r.props.onInit&&r.props.onInit(),r.props.lazyLoad){var p=(0,m.getOnDemandLazySlides)(M(M({},r.props),r.state));p.length>0&&(r.setState(function(o){return{lazyLoadedList:o.lazyLoadedList.concat(p)}}),r.props.onLazyLoad&&r.props.onLazyLoad(p))}var n=M({listRef:r.list,trackRef:r.track},r.props);r.updateState(n,!0,function(){r.adaptHeight(),r.props.autoplay&&r.autoPlay("update")}),r.props.lazyLoad==="progressive"&&(r.lazyLoadTimer=setInterval(r.progressiveLazyLoad,1e3)),r.ro=new C.default(function(){r.state.animating?(r.onWindowResized(!1),r.callbackTimers.push(setTimeout(function(){return r.onWindowResized()},r.props.speed))):r.onWindowResized()}),r.ro.observe(r.list),document.querySelectorAll&&Array.prototype.forEach.call(document.querySelectorAll(".slick-slide"),function(o){o.onfocus=r.props.pauseOnFocus?r.onSlideFocus:null,o.onblur=r.props.pauseOnFocus?r.onSlideBlur:null}),window.addEventListener?window.addEventListener("resize",r.onWindowResized):window.attachEvent("onresize",r.onWindowResized)}),i(w(r),"componentWillUnmount",function(){r.animationEndCallback&&clearTimeout(r.animationEndCallback),r.lazyLoadTimer&&clearInterval(r.lazyLoadTimer),r.callbackTimers.length&&(r.callbackTimers.forEach(function(p){return clearTimeout(p)}),r.callbackTimers=[]),window.addEventListener?window.removeEventListener("resize",r.onWindowResized):window.detachEvent("onresize",r.onWindowResized),r.autoplayTimer&&clearInterval(r.autoplayTimer),r.ro.disconnect()}),i(w(r),"componentDidUpdate",function(p){if(r.checkImagesLoad(),r.props.onReInit&&r.props.onReInit(),r.props.lazyLoad){var n=(0,m.getOnDemandLazySlides)(M(M({},r.props),r.state));n.length>0&&(r.setState(function(_){return{lazyLoadedList:_.lazyLoadedList.concat(n)}}),r.props.onLazyLoad&&r.props.onLazyLoad(n))}r.adaptHeight();var o=M(M({listRef:r.list,trackRef:r.track},r.props),r.state),x=r.didPropsChange(p);x&&r.updateState(o,x,function(){r.state.currentSlide>=a.default.Children.count(r.props.children)&&r.changeSlide({message:"index",index:a.default.Children.count(r.props.children)-r.props.slidesToShow,currentSlide:r.state.currentSlide}),r.props.autoplay?r.autoPlay("update"):r.pause("paused")})}),i(w(r),"onWindowResized",function(p){r.debouncedResize&&r.debouncedResize.cancel(),r.debouncedResize=(0,h.default)(function(){return r.resizeWindow(p)},50),r.debouncedResize()}),i(w(r),"resizeWindow",function(){var p=arguments.length>0&&arguments[0]!==void 0?arguments[0]:!0,n=!!(r.track&&r.track.node);if(n){var o=M(M({listRef:r.list,trackRef:r.track},r.props),r.state);r.updateState(o,p,function(){r.props.autoplay?r.autoPlay("update"):r.pause("paused")}),r.setState({animating:!1}),clearTimeout(r.animationEndCallback),delete r.animationEndCallback}}),i(w(r),"updateState",function(p,n,o){var x=(0,m.initializedState)(p);p=M(M(M({},p),x),{},{slideIndex:x.currentSlide});var _=(0,m.getTrackLeft)(p);p=M(M({},p),{},{left:_});var T=(0,m.getTrackCSS)(p);(n||a.default.Children.count(r.props.children)!==a.default.Children.count(p.children))&&(x.trackStyle=T),r.setState(x,o)}),i(w(r),"ssrInit",function(){if(r.props.variableWidth){var p=0,n=0,o=[],x=(0,m.getPreClones)(M(M(M({},r.props),r.state),{},{slideCount:r.props.children.length})),_=(0,m.getPostClones)(M(M(M({},r.props),r.state),{},{slideCount:r.props.children.length}));r.props.children.forEach(function(se){o.push(se.props.style.width),p+=se.props.style.width});for(var T=0;T<x;T++)n+=o[o.length-1-T],p+=o[o.length-1-T];for(var I=0;I<_;I++)p+=o[I];for(var E=0;E<r.state.currentSlide;E++)n+=o[E];var L={width:p+"px",left:-n+"px"};if(r.props.centerMode){var U="".concat(o[r.state.currentSlide],"px");L.left="calc(".concat(L.left," + (100% - ").concat(U,") / 2 ) ")}return{trackStyle:L}}var q=a.default.Children.count(r.props.children),Q=M(M(M({},r.props),r.state),{},{slideCount:q}),J=(0,m.getPreClones)(Q)+(0,m.getPostClones)(Q)+q,ee=100/r.props.slidesToShow*J,W=100/J,K=-W*((0,m.getPreClones)(Q)+r.state.currentSlide)*ee/100;r.props.centerMode&&(K+=(100-W*ee/100)/2);var Y={width:ee+"%",left:K+"%"};return{slideWidth:W+"%",trackStyle:Y}}),i(w(r),"checkImagesLoad",function(){var p=r.list&&r.list.querySelectorAll&&r.list.querySelectorAll(".slick-slide img")||[],n=p.length,o=0;Array.prototype.forEach.call(p,function(x){var _=function(){return++o&&o>=n&&r.onWindowResized()};if(!x.onclick)x.onclick=function(){return x.parentNode.focus()};else{var T=x.onclick;x.onclick=function(I){T(I),x.parentNode.focus()}}x.onload||(r.props.lazyLoad?x.onload=function(){r.adaptHeight(),r.callbackTimers.push(setTimeout(r.onWindowResized,r.props.speed))}:(x.onload=_,x.onerror=function(){_(),r.props.onLazyLoadError&&r.props.onLazyLoadError()}))})}),i(w(r),"progressiveLazyLoad",function(){for(var p=[],n=M(M({},r.props),r.state),o=r.state.currentSlide;o<r.state.slideCount+(0,m.getPostClones)(n);o++)if(r.state.lazyLoadedList.indexOf(o)<0){p.push(o);break}for(var x=r.state.currentSlide-1;x>=-(0,m.getPreClones)(n);x--)if(r.state.lazyLoadedList.indexOf(x)<0){p.push(x);break}p.length>0?(r.setState(function(_){return{lazyLoadedList:_.lazyLoadedList.concat(p)}}),r.props.onLazyLoad&&r.props.onLazyLoad(p)):r.lazyLoadTimer&&(clearInterval(r.lazyLoadTimer),delete r.lazyLoadTimer)}),i(w(r),"slideHandler",function(p){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,o=r.props,x=o.asNavFor,_=o.beforeChange,T=o.onLazyLoad,I=o.speed,E=o.afterChange,L=r.state.currentSlide,U=(0,m.slideHandler)(M(M(M({index:p},r.props),r.state),{},{trackRef:r.track,useCSS:r.props.useCSS&&!n})),q=U.state,Q=U.nextState;if(q){_&&_(L,q.currentSlide);var J=q.lazyLoadedList.filter(function(ee){return r.state.lazyLoadedList.indexOf(ee)<0});T&&J.length>0&&T(J),!r.props.waitForAnimate&&r.animationEndCallback&&(clearTimeout(r.animationEndCallback),E&&E(L),delete r.animationEndCallback),r.setState(q,function(){x&&r.asNavForIndex!==p&&(r.asNavForIndex=p,x.innerSlider.slideHandler(p)),Q&&(r.animationEndCallback=setTimeout(function(){var ee=Q.animating,W=Z(Q,["animating"]);r.setState(W,function(){r.callbackTimers.push(setTimeout(function(){return r.setState({animating:ee})},10)),E&&E(q.currentSlide),delete r.animationEndCallback})},I))})}}),i(w(r),"changeSlide",function(p){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1,o=M(M({},r.props),r.state),x=(0,m.changeSlide)(o,p);if(!(x!==0&&!x)&&(n===!0?r.slideHandler(x,n):r.slideHandler(x),r.props.autoplay&&r.autoPlay("update"),r.props.focusOnSelect)){var _=r.list.querySelectorAll(".slick-current");_[0]&&_[0].focus()}}),i(w(r),"clickHandler",function(p){r.clickable===!1&&(p.stopPropagation(),p.preventDefault()),r.clickable=!0}),i(w(r),"keyHandler",function(p){var n=(0,m.keyHandler)(p,r.props.accessibility,r.props.rtl);n!==""&&r.changeSlide({message:n})}),i(w(r),"selectHandler",function(p){r.changeSlide(p)}),i(w(r),"disableBodyScroll",function(){var p=function(o){o=o||window.event,o.preventDefault&&o.preventDefault(),o.returnValue=!1};window.ontouchmove=p}),i(w(r),"enableBodyScroll",function(){window.ontouchmove=null}),i(w(r),"swipeStart",function(p){r.props.verticalSwiping&&r.disableBodyScroll();var n=(0,m.swipeStart)(p,r.props.swipe,r.props.draggable);n!==""&&r.setState(n)}),i(w(r),"swipeMove",function(p){var n=(0,m.swipeMove)(p,M(M(M({},r.props),r.state),{},{trackRef:r.track,listRef:r.list,slideIndex:r.state.currentSlide}));n&&(n.swiping&&(r.clickable=!1),r.setState(n))}),i(w(r),"swipeEnd",function(p){var n=(0,m.swipeEnd)(p,M(M(M({},r.props),r.state),{},{trackRef:r.track,listRef:r.list,slideIndex:r.state.currentSlide}));if(n){var o=n.triggerSlideHandler;delete n.triggerSlideHandler,r.setState(n),o!==void 0&&(r.slideHandler(o),r.props.verticalSwiping&&r.enableBodyScroll())}}),i(w(r),"touchEnd",function(p){r.swipeEnd(p),r.clickable=!0}),i(w(r),"slickPrev",function(){r.callbackTimers.push(setTimeout(function(){return r.changeSlide({message:"previous"})},0))}),i(w(r),"slickNext",function(){r.callbackTimers.push(setTimeout(function(){return r.changeSlide({message:"next"})},0))}),i(w(r),"slickGoTo",function(p){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1;if(p=Number(p),isNaN(p))return"";r.callbackTimers.push(setTimeout(function(){return r.changeSlide({message:"index",index:p,currentSlide:r.state.currentSlide},n)},0))}),i(w(r),"play",function(){var p;if(r.props.rtl)p=r.state.currentSlide-r.props.slidesToScroll;else if((0,m.canGoNext)(M(M({},r.props),r.state)))p=r.state.currentSlide+r.props.slidesToScroll;else return!1;r.slideHandler(p)}),i(w(r),"autoPlay",function(p){r.autoplayTimer&&clearInterval(r.autoplayTimer);var n=r.state.autoplaying;if(p==="update"){if(n==="hovered"||n==="focused"||n==="paused")return}else if(p==="leave"){if(n==="paused"||n==="focused")return}else if(p==="blur"&&(n==="paused"||n==="hovered"))return;r.autoplayTimer=setInterval(r.play,r.props.autoplaySpeed+50),r.setState({autoplaying:"playing"})}),i(w(r),"pause",function(p){r.autoplayTimer&&(clearInterval(r.autoplayTimer),r.autoplayTimer=null);var n=r.state.autoplaying;p==="paused"?r.setState({autoplaying:"paused"}):p==="focused"?(n==="hovered"||n==="playing")&&r.setState({autoplaying:"focused"}):n==="playing"&&r.setState({autoplaying:"hovered"})}),i(w(r),"onDotsOver",function(){return r.props.autoplay&&r.pause("hovered")}),i(w(r),"onDotsLeave",function(){return r.props.autoplay&&r.state.autoplaying==="hovered"&&r.autoPlay("leave")}),i(w(r),"onTrackOver",function(){return r.props.autoplay&&r.pause("hovered")}),i(w(r),"onTrackLeave",function(){return r.props.autoplay&&r.state.autoplaying==="hovered"&&r.autoPlay("leave")}),i(w(r),"onSlideFocus",function(){return r.props.autoplay&&r.pause("focused")}),i(w(r),"onSlideBlur",function(){return r.props.autoplay&&r.state.autoplaying==="focused"&&r.autoPlay("blur")}),i(w(r),"render",function(){var p=(0,j.default)("slick-slider",r.props.className,{"slick-vertical":r.props.vertical,"slick-initialized":!0}),n=M(M({},r.props),r.state),o=(0,m.extractObject)(n,["fade","cssEase","speed","infinite","centerMode","focusOnSelect","currentSlide","lazyLoad","lazyLoadedList","rtl","slideWidth","slideHeight","listHeight","vertical","slidesToShow","slidesToScroll","slideCount","trackStyle","variableWidth","unslick","centerPadding","targetSlide","useCSS"]),x=r.props.pauseOnHover;o=M(M({},o),{},{onMouseEnter:x?r.onTrackOver:null,onMouseLeave:x?r.onTrackLeave:null,onMouseOver:x?r.onTrackOver:null,focusOnSelect:r.props.focusOnSelect&&r.clickable?r.selectHandler:null});var _;if(r.props.dots===!0&&r.state.slideCount>=r.props.slidesToShow){var T=(0,m.extractObject)(n,["dotsClass","slideCount","slidesToShow","currentSlide","slidesToScroll","clickHandler","children","customPaging","infinite","appendDots"]),I=r.props.pauseOnDotsHover;T=M(M({},T),{},{clickHandler:r.changeSlide,onMouseEnter:I?r.onDotsLeave:null,onMouseOver:I?r.onDotsOver:null,onMouseLeave:I?r.onDotsLeave:null}),_=a.default.createElement(S.Dots,T)}var E,L,U=(0,m.extractObject)(n,["infinite","centerMode","currentSlide","slideCount","slidesToShow","prevArrow","nextArrow"]);U.clickHandler=r.changeSlide,r.props.arrows&&(E=a.default.createElement(N.PrevArrow,U),L=a.default.createElement(N.NextArrow,U));var q=null;r.props.vertical&&(q={height:r.state.listHeight});var Q=null;r.props.vertical===!1?r.props.centerMode===!0&&(Q={padding:"0px "+r.props.centerPadding}):r.props.centerMode===!0&&(Q={padding:r.props.centerPadding+" 0px"});var J=M(M({},q),Q),ee=r.props.touchMove,W={className:"slick-list",style:J,onClick:r.clickHandler,onMouseDown:ee?r.swipeStart:null,onMouseMove:r.state.dragging&&ee?r.swipeMove:null,onMouseUp:ee?r.swipeEnd:null,onMouseLeave:r.state.dragging&&ee?r.swipeEnd:null,onTouchStart:ee?r.swipeStart:null,onTouchMove:r.state.dragging&&ee?r.swipeMove:null,onTouchEnd:ee?r.touchEnd:null,onTouchCancel:r.state.dragging&&ee?r.swipeEnd:null,onKeyDown:r.props.accessibility?r.keyHandler:null},K={className:p,dir:"ltr",style:r.props.style};return r.props.unslick&&(W={className:"slick-list"},K={className:p}),a.default.createElement("div",K,r.props.unslick?"":E,a.default.createElement("div",A({ref:r.listRefHandler},W),a.default.createElement(v.Track,A({ref:r.trackRefHandler},o),r.props.children)),r.props.unslick?"":L,r.props.unslick?"":_)}),r.list=null,r.track=null,r.state=M(M({},l.default),{},{currentSlide:r.props.initialSlide,targetSlide:r.props.initialSlide?r.props.initialSlide:0,slideCount:a.default.Children.count(r.props.children)}),r.callbackTimers=[],r.clickable=!0,r.debouncedResize=null;var H=r.ssrInit();return r.state=M(M({},r.state),H),r}return F(P,[{key:"didPropsChange",value:function(r){for(var H=!1,p=0,n=Object.keys(this.props);p<n.length;p++){var o=n[p];if(!r.hasOwnProperty(o)){H=!0;break}if(!(O(r[o])==="object"||typeof r[o]=="function"||isNaN(r[o]))&&r[o]!==this.props[o]){H=!0;break}}return H||a.default.Children.count(this.props.children)!==a.default.Children.count(r.children)}}]),P}(a.default.Component),Ee}var tt,en;function sa(){if(en)return tt;en=1;var a=function(l){return l.replace(/[A-Z]/g,function(h){return"-"+h.toLowerCase()}).toLowerCase()};return tt=a,tt}var rt,tn;function oa(){if(tn)return rt;tn=1;var a=sa(),l=function(m){var v=/[height|width]$/;return v.test(m)},h=function(m){var v="",S=Object.keys(m);return S.forEach(function(N,C){var f=m[N];N=a(N),l(N)&&typeof f=="number"&&(f=f+"px"),f===!0?v+=N:f===!1?v+="not "+N:v+="("+N+": "+f+")",C<S.length-1&&(v+=" and ")}),v},j=function(m){var v="";return typeof m=="string"?m:m instanceof Array?(m.forEach(function(S,N){v+=h(S),N<m.length-1&&(v+=", ")}),v):h(m)};return rt=j,rt}var nt,rn;function la(){if(rn)return nt;rn=1;function a(l){this.options=l,!l.deferSetup&&this.setup()}return a.prototype={constructor:a,setup:function(){this.options.setup&&this.options.setup(),this.initialised=!0},on:function(){!this.initialised&&this.setup(),this.options.match&&this.options.match()},off:function(){this.options.unmatch&&this.options.unmatch()},destroy:function(){this.options.destroy?this.options.destroy():this.off()},equals:function(l){return this.options===l||this.options.match===l}},nt=a,nt}var it,nn;function On(){if(nn)return it;nn=1;function a(j,m){var v=0,S=j.length,N;for(v;v<S&&(N=m(j[v],v),N!==!1);v++);}function l(j){return Object.prototype.toString.apply(j)==="[object Array]"}function h(j){return typeof j=="function"}return it={isFunction:h,isArray:l,each:a},it}var at,an;function ca(){if(an)return at;an=1;var a=la(),l=On().each;function h(j,m){this.query=j,this.isUnconditional=m,this.handlers=[],this.mql=window.matchMedia(j);var v=this;this.listener=function(S){v.mql=S.currentTarget||S,v.assess()},this.mql.addListener(this.listener)}return h.prototype={constuctor:h,addHandler:function(j){var m=new a(j);this.handlers.push(m),this.matches()&&m.on()},removeHandler:function(j){var m=this.handlers;l(m,function(v,S){if(v.equals(j))return v.destroy(),!m.splice(S,1)})},matches:function(){return this.mql.matches||this.isUnconditional},clear:function(){l(this.handlers,function(j){j.destroy()}),this.mql.removeListener(this.listener),this.handlers.length=0},assess:function(){var j=this.matches()?"on":"off";l(this.handlers,function(m){m[j]()})}},at=h,at}var st,sn;function da(){if(sn)return st;sn=1;var a=ca(),l=On(),h=l.each,j=l.isFunction,m=l.isArray;function v(){if(!window.matchMedia)throw new Error("matchMedia not present, legacy browsers require a polyfill");this.queries={},this.browserIsIncapable=!window.matchMedia("only all").matches}return v.prototype={constructor:v,register:function(S,N,C){var f=this.queries,O=C&&this.browserIsIncapable;return f[S]||(f[S]=new a(S,O)),j(N)&&(N={match:N}),m(N)||(N=[N]),h(N,function(A){j(A)&&(A={match:A}),f[S].addHandler(A)}),this},unregister:function(S,N){var C=this.queries[S];return C&&(N?C.removeHandler(N):(C.clear(),delete this.queries[S])),this}},st=v,st}var ot,on;function ua(){if(on)return ot;on=1;var a=da();return ot=new a,ot}var ln;function fa(){return ln||(ln=1,function(a){Object.defineProperty(a,"__esModule",{value:!0}),a.default=void 0;var l=S(Oe()),h=aa(),j=S(oa()),m=S(yn()),v=Ae();function S(s){return s&&s.__esModule?s:{default:s}}function N(s){"@babel/helpers - typeof";return N=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(i){return typeof i}:function(i){return i&&typeof Symbol=="function"&&i.constructor===Symbol&&i!==Symbol.prototype?"symbol":typeof i},N(s)}function C(){return C=Object.assign?Object.assign.bind():function(s){for(var i=1;i<arguments.length;i++){var c=arguments[i];for(var t in c)Object.prototype.hasOwnProperty.call(c,t)&&(s[t]=c[t])}return s},C.apply(this,arguments)}function f(s,i){var c=Object.keys(s);if(Object.getOwnPropertySymbols){var t=Object.getOwnPropertySymbols(s);i&&(t=t.filter(function(d){return Object.getOwnPropertyDescriptor(s,d).enumerable})),c.push.apply(c,t)}return c}function O(s){for(var i=1;i<arguments.length;i++){var c=arguments[i]!=null?arguments[i]:{};i%2?f(Object(c),!0).forEach(function(t){u(s,t,c[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(s,Object.getOwnPropertyDescriptors(c)):f(Object(c)).forEach(function(t){Object.defineProperty(s,t,Object.getOwnPropertyDescriptor(c,t))})}return s}function A(s,i){if(!(s instanceof i))throw new TypeError("Cannot call a class as a function")}function Z(s,i){for(var c=0;c<i.length;c++){var t=i[c];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(s,g(t.key),t)}}function $(s,i,c){return i&&Z(s.prototype,i),Object.defineProperty(s,"prototype",{writable:!1}),s}function B(s,i){if(typeof i!="function"&&i!==null)throw new TypeError("Super expression must either be null or a function");s.prototype=Object.create(i&&i.prototype,{constructor:{value:s,writable:!0,configurable:!0}}),Object.defineProperty(s,"prototype",{writable:!1}),i&&M(s,i)}function M(s,i){return M=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,d){return t.__proto__=d,t},M(s,i)}function te(s){var i=X();return function(){var t=z(s),d;if(i){var y=z(this).constructor;d=Reflect.construct(t,arguments,y)}else d=t.apply(this,arguments);return D(this,d)}}function D(s,i){if(i&&(N(i)==="object"||typeof i=="function"))return i;if(i!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return F(s)}function F(s){if(s===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return s}function X(){try{var s=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(X=function(){return!!s})()}function z(s){return z=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(c){return c.__proto__||Object.getPrototypeOf(c)},z(s)}function u(s,i,c){return i=g(i),i in s?Object.defineProperty(s,i,{value:c,enumerable:!0,configurable:!0,writable:!0}):s[i]=c,s}function g(s){var i=w(s,"string");return N(i)=="symbol"?i:String(i)}function w(s,i){if(N(s)!="object"||!s)return s;var c=s[Symbol.toPrimitive];if(c!==void 0){var t=c.call(s,i);if(N(t)!="object")return t;throw new TypeError("@@toPrimitive must return a primitive value.")}return(i==="string"?String:Number)(s)}var b=(0,v.canUseDOM)()&&ua();a.default=function(s){B(c,s);var i=te(c);function c(t){var d;return A(this,c),d=i.call(this,t),u(F(d),"innerSliderRefHandler",function(y){return d.innerSlider=y}),u(F(d),"slickPrev",function(){return d.innerSlider.slickPrev()}),u(F(d),"slickNext",function(){return d.innerSlider.slickNext()}),u(F(d),"slickGoTo",function(y){var P=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1;return d.innerSlider.slickGoTo(y,P)}),u(F(d),"slickPause",function(){return d.innerSlider.pause("paused")}),u(F(d),"slickPlay",function(){return d.innerSlider.autoPlay("play")}),d.state={breakpoint:null},d._responsiveMediaHandlers=[],d}return $(c,[{key:"media",value:function(d,y){b.register(d,y),this._responsiveMediaHandlers.push({query:d,handler:y})}},{key:"componentDidMount",value:function(){var d=this;if(this.props.responsive){var y=this.props.responsive.map(function(k){return k.breakpoint});y.sort(function(k,r){return k-r}),y.forEach(function(k,r){var H;r===0?H=(0,j.default)({minWidth:0,maxWidth:k}):H=(0,j.default)({minWidth:y[r-1]+1,maxWidth:k}),(0,v.canUseDOM)()&&d.media(H,function(){d.setState({breakpoint:k})})});var P=(0,j.default)({minWidth:y.slice(-1)[0]});(0,v.canUseDOM)()&&this.media(P,function(){d.setState({breakpoint:null})})}}},{key:"componentWillUnmount",value:function(){this._responsiveMediaHandlers.forEach(function(d){b.unregister(d.query,d.handler)})}},{key:"render",value:function(){var d=this,y,P;this.state.breakpoint?(P=this.props.responsive.filter(function(I){return I.breakpoint===d.state.breakpoint}),y=P[0].settings==="unslick"?"unslick":O(O(O({},m.default),this.props),P[0].settings)):y=O(O({},m.default),this.props),y.centerMode&&(y.slidesToScroll>1,y.slidesToScroll=1),y.fade&&(y.slidesToShow>1,y.slidesToScroll>1,y.slidesToShow=1,y.slidesToScroll=1);var k=l.default.Children.toArray(this.props.children);k=k.filter(function(I){return typeof I=="string"?!!I.trim():!!I}),y.variableWidth&&(y.rows>1||y.slidesPerRow>1)&&(console.warn("variableWidth is not supported in case of rows > 1 or slidesPerRow > 1"),y.variableWidth=!1);for(var r=[],H=null,p=0;p<k.length;p+=y.rows*y.slidesPerRow){for(var n=[],o=p;o<p+y.rows*y.slidesPerRow;o+=y.slidesPerRow){for(var x=[],_=o;_<o+y.slidesPerRow&&(y.variableWidth&&k[_].props.style&&(H=k[_].props.style.width),!(_>=k.length));_+=1)x.push(l.default.cloneElement(k[_],{key:100*p+10*o+_,tabIndex:-1,style:{width:"".concat(100/y.slidesPerRow,"%"),display:"inline-block"}}));n.push(l.default.createElement("div",{key:10*p+o},x))}y.variableWidth?r.push(l.default.createElement("div",{key:p,style:{width:H}},n)):r.push(l.default.createElement("div",{key:p},n))}if(y==="unslick"){var T="regular slider "+(this.props.className||"");return l.default.createElement("div",{className:T},k)}else r.length<=y.slidesToShow&&!y.infinite&&(y.unslick=!0);return l.default.createElement(h.InnerSlider,C({style:this.props.style,ref:this.innerSliderRefHandler},(0,v.filterSettings)(y)),r)}}]),c}(l.default.Component)}(Ge)),Ge}var cn;function pa(){return cn||(cn=1,function(a){Object.defineProperty(a,"__esModule",{value:!0}),a.default=void 0;var l=h(fa());function h(j){return j&&j.__esModule?j:{default:j}}a.default=l.default}(Qe)),Qe}var ma=pa();const Nn=gn(ma),ha=({clientsList:a})=>{const l={className:"slider variable-width",dots:!1,infinite:!0,slidesToShow:1,slidesToScroll:1,autoplay:!0,speed:2e3,autoplaySpeed:3e3,variableWidth:!0,draggable:!0,swipeToSlide:!0,cssEase:"ease"};return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"text-center",children:e.jsx("span",{className:"fs-1 pb-4 d-block",children:"Our Clients We Proudly Served"})}),e.jsx("div",{className:"slider-container",children:e.jsx(Nn,{...l,children:a.map(h=>e.jsx(Pi,{client:h},h.id))})})]})},va=V.forwardRef(({item:a,date:l,id:h,dragHandleProps:j,snapshot:m,handleCarouselEdit:v,thumbDelete:S,...N},C)=>e.jsx("li",{ref:C,...N,className:"card p-2 my-2 "+(m.isDragging?"hovering":""),children:e.jsx("div",{...j,children:e.jsxs("div",{className:"row position-reltive",children:[e.jsx("div",{className:"col-8",children:e.jsx("p",{className:"m-0 fw-bold",children:a==null?void 0:a.intro_title})}),e.jsxs("div",{className:"col-4 d-flex justify-content-around align-items-center flex-md-row gap-3",children:[e.jsx(fe,{onClick:f=>v(f,a),children:e.jsx("i",{className:"fa fa-pencil fs-4 text-warning","aria-hidden":"true"})}),e.jsx(fe,{onClick:f=>S(a==null?void 0:a.id,a==null?void 0:a.intro_title),children:e.jsx("i",{className:"fa fa-trash fs-4 text-danger","aria-hidden":"true"})})]})]})})})),ga=V.forwardRef(({children:a,...l},h)=>e.jsx("ul",{ref:h,className:"addresslist",style:{height:"100%"},children:a})),ba=({editHandler:a,componentType:l,homeintros:h,popupTitle:j,pageType:m})=>{var b;const{homeIntroList:v}=ye(s=>s.homeIntroList),[S,N]=V.useState(""),{control:C,register:f,reset:O,handleSubmit:A,setValue:Z,formState:{errors:$}}=ht({}),[B,M]=V.useState(h),te=yt(),D=()=>{a(l,!1),document.body.style.overflow=""};V.useEffect(()=>{N(Dn("userName"))},[]);const F=(s,i)=>{s.preventDefault(),Object.keys(i).forEach(t=>{Z(t,i[t])})},X=(s,i)=>{const c=async()=>{if((await Ce.delete(`carousel/updateHomelistIntro/${s}/`)).status===204){const d=B.filter(y=>y.id!==s);M(d)}};Fn.confirmAlert({customUI:({onClose:t})=>e.jsx(li,{onClose:t,callback:c,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:i})," image?"]})})})},z=async s=>{let i="";s.pageType=m;try{s.id?(s.updated_by=S,i=await Ce.put(`/carousel/updateHomelistIntro/${s.id}/`,s)):(s.created_by=S,s.intro_position=B.length,i=await Ce.post("/carousel/createHomeIntro/",s)),(i.status===200||i.status===201)&&(O(),bt.success("Intro Values are updated successfully "),u(i.data.intro),te(bn()))}catch{console.log("unable to save the Intro form")}},u=s=>{let i=JSON.parse(JSON.stringify(B)),c=i.findIndex(d=>d.id===s.id);c>-1?i[c]=s:i.push(s);const t=De(i,"intro_position");M(t)},g=async s=>{const{source:i,destination:c}=s;if(!c)return!0;let t=JSON.parse(JSON.stringify(B));const d=mt(t[0]),y=Hn(t,i.index,c.index),P=Bn(y,d),k=await w(P);(k==null?void 0:k.length)>0&&M(k)};V.useEffect(()=>{(v==null?void 0:v.length)>0&&M(v)},[v]);const w=async s=>{var i;try{let c=await Ce.put("/carousel/updateIntroindex/",s);if((i=c==null?void 0:c.data)!=null&&i.homeIntroList)return c.data.homeIntroList}catch{console.log("unable to save the Intro form")}};return e.jsxs("div",{className:"",children:[e.jsx(vt,{closeHandler:D,title:j}),e.jsx("hr",{className:"m-0 text-dark"}),e.jsx("form",{className:"",onSubmit:A(z),children:e.jsxs("div",{className:"container my-3",children:[e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-md-12 mb-md-0  ",children:[e.jsx(ci,{note:"Use drag option to shuffle the addresses"}),e.jsx("div",{className:B.length>0&&"heightCtrl",children:e.jsx(ai,{onDragEnd:g,children:e.jsx(si,{droppableId:"address-wrapper",children:(s,i)=>e.jsxs(ga,{ref:s.innerRef,...s.droppableProps,children:[B.map((c,t)=>e.jsx(oi,{draggableId:`${c.id}`,index:t,children:(d,y)=>e.jsx(va,{ref:d.innerRef,dragHandleProps:d.dragHandleProps,...d.draggableProps,snapshot:y,item:c,thumbDelete:X,handleCarouselEdit:F})},c.id)),s.placeholder]})})})})]}),e.jsxs("div",{className:"col-md-12",children:[e.jsx("p",{className:"text-dark fw-bold mt-3",children:"Corporate Training Form"}),e.jsx("hr",{className:"mb-3 text-dark"})]}),e.jsx("div",{className:"col-md-12 mb-md-0",children:e.jsxs("div",{className:"heightCtrl",children:[e.jsx(zr,{label:"Title",fieldName:"intro_title",register:f,validationObject:An.intro_title,error:(b=$==null?void 0:$.intro_title)==null?void 0:b.message,isRequired:!0}),e.jsx(Vn,{label:"Description",Controller:zn,name:"intro_desc",control:C}),e.jsx(zr,{label:"More links",fieldName:"intro_morelink",register:f}),e.jsx(Te,{type:"hidden",label:"intro_position",fieldName:"intro_position",register:f})]})})]}),e.jsx("div",{className:"row",children:e.jsxs("div",{className:"d-flex justify-content-center flex-wrap flex-column flex-sm-row align-items-center gap-1 gap-md-3 my-3",children:[e.jsx("button",{type:"reset",className:"btn btn-secondary",children:"Clear"}),e.jsx("button",{type:"submit",className:"btn btn-primary",children:"Save"}),e.jsx(gt,{type:"submit",cssClass:"btn btn-more",label:"Close",handlerChange:D})]})})]})})]})},ya=({list:a})=>{const l={fade:!1,infinite:!0,slidesToShow:1,slidesToScroll:1,autoplay:!0,autoplaySpeed:5e3,draggable:!0,swipe:!0};return e.jsx("div",{className:"slider-container",children:e.jsx(Nn,{...l,children:a.map((h,j)=>e.jsx(xa,{item:h,index:j}))})})},xa=a=>{const{item:l,...h}=a;return e.jsxs("div",{...h,children:[e.jsx(pe,{title:l==null?void 0:l.intro_title,cssClass:"text-start"}),e.jsx("div",{className:"quill ",children:e.jsx("div",{className:"ql-container ql-snow",children:e.jsx("div",{className:"ql-editor",children:e.jsx(ut,{data:l.intro_desc,showMorelink:!1})})})})]})},ja=me.div`
.homeServices .row.service:nth-child(odd) {
  flex-direction: row-reverse;
}


.homeServices {
    position: relative;


    img {
        object-fit: cover;
    }

    h3 {
        font-size: 2rem;
        font-weight: bold;
    }
    .briefIntro h5 {
        font-size: 2.5rem;
        padding-left: 15px;
        border: 0px;
        border-left-width: 15px;
        border-style: solid;
        text-align: left;
    }

    .serviceTitle {
        color: #141414;
        font-size: 40px;

        @media (max-width: 576px) {
            font-size: 2rem;
        }
    }

    .homeServiceImg {
        height: 270px;
        -o-object-fit: contain;
        -o-object-position: center;
    }

    .breiftopMargin .container > div {
        padding: 10px 0 !important;
    }

    
    .row.service {
        background-color: #fff;
        /* box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075); */
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        border-radius: 8px;
        overflow: hidden;

        h5 {
            font-size: 1.3rem !important;
            color: ${({theme:a})=>a.gray444};
            text-transform: uppercase;
            font-weight: 500 !important;
            margin-bottom: 1rem;
        }

        .ql-editor {
            padding: 0 !important;
        }

        .homeServiceImg {
            padding: 0 !important;
        }

        .homeServiceDetails {
            display: flex;
            flex-direction: column;
            align-items: start;
            justify-content: center;

            .ql-editor .description > *:not(p:first-of-type) {
                display: none;
            }

        }
    }
    .row.service:last-child {
        margin-bottom: 0px !important;
    }

    homeServiceDetails {
        .description {
            p:first-child {
                display: block;
                display: -webkit-box;
                -webkit-line-clamp: 4;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
        }
    }
}
`,Sa=me.div`

.homeDynamciServicesIntro {
  padding: 30px 0 0px;
  background-color:${({theme:a})=>a.lightWhiteF8}; 
  color: ${({theme:a})=>a.textColor};

  .briefIntro {
    .btn {
      border: 0 !important;
      text-decoration: underline;

      &:hover {
        background-color: transparent !important;
      }
    }
  }

  .homeDynamciServices {
    padding: 24px 0;

    .briefIntro {
        height: 320px;
        max-height: 100%;
        padding: 32px;
        /* border-bottom: 20px solid rgba(1, 32, 96, .2); */
        background-color: #f8f8f8;
        cursor: pointer;

        h5 {
            font-weight: 500;
        }

        h5,
        .quill,
        a {
          position: relative;
        }
        h5 {
          z-index: 2;
          font-weight: 500;
          font-size: 1.6rem;
          color: ${({theme:a})=>a.clientSecondaryColor};
          hyphens: manual;
          overflow-wrap: break-word; /* optional, for better word breaking */
          word-break: break-word; /* optional, for better word breaking */
        }

        .quill {
          z-index: 3;

          p,
          p span,
          h1 {
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 6;
          }

          p,
          p span,
          h1,
          h1 strong,
          span {
            background: transparent;
            color: ${({theme:a})=>a.gray333};
            font-family: Roboto;
            font-size: 1rem;
            font-family: roboto;
            font-weight: normal;
            line-height: 1.5;
            text-align: left;
          }

          .description {
            p:not(:first-child),ul, ol {
              display: none;
            }
          }

          .ql-editor {
            padding: 0.3rem 0 0px;
          }
        }
    }

    .row {
        .col-md-4 .briefIntro {
        background-repeat: no-repeat;
        background-position: right 15px bottom;
        border-radius: 4px;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);

        *, p, p span {
            color: ${({theme:a})=>a.gray444} !important;
            }

        &:hover {
            background-color: #0d75ba;

            *, p, p span {
            color: ${({theme:a})=>a.white} !important;
            }
        }

        @media (max-width: 768px) {
            background-position: right 32px bottom;
        }
        }

        /* .col-md-4:nth-child(1) .briefIntro {
        background-image: url('../../../Images/studies.png');
        }

        .col-md-4:nth-child(2) .briefIntro {
        background-image: url('../../../Images/engineering.png');
        }

        .col-md-4:nth-child(3) .briefIntro {
        background-image: url('../../../Images/calculator.png');
        }
        .col-md-4:nth-child(3) .briefIntro {
        background-image: url('../../../Images/calculator.png');
        }
        .col-md-4:nth-child(4) .briefIntro {
        background-image: url('../../../Images/management.png');
        }

        .col-md-4:nth-child(5) .briefIntro {
        background-image: url('../../../Images/engineer.png');
        }

        .col-md-4:nth-child(6) .briefIntro{
        background-image: url('../../../Images/engineering-services.png');
        } */
    }
    }
}


`,wa=me.div`
  .homeBrochure {
    .floatingButton {
      position: fixed;
      top: 600px;
      right: 0;
      z-index: 99999;
      transition: top 0.4s ease;

      @media (max-width: 1023px) {
        top: 600px;
      }

      @media (max-width: 480px) {
        top: 400px;
      }

      img {
        width: 68px;
      }

      button:not(.modal button) {
        border-top-right-radius: 0px !important;
        border-bottom-right-radius: 0px !important;
      }

      button.btn.btn-primary {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
      }

      button {
        padding: 12px 16px !important;
        i {
          font-size: 24px;
          margin-right: 4px;
        }

        @media (max-width: 768px) {
          padding: 10px !important;

          i {
            margin-right: 0;
          }
          span {
            display: none;
          }
        }
      }

      ul.dropdown-menu {
        max-width: 300px;
        width: 300px;
        border-top-right-radius: 0;
        top: -8px !important;

        li {
          padding: 12px 24px;
          border-bottom: 1px solid #ddd;

          &:last-child {
            border: 0;
          }
        }
      }

      .modal {
        z-index: 99999;
      }
    }

    .floatingButton.scrolled {
      top: 100px; /* On scroll position */

      span {
        display: none;
      }

      button:not(.modal button) {
        margin-top: 10px !important;
        
      }
    }
  }
`;me.div`
    .weServe {
        position: relative;
        display: flex;

        img {
            max-height: 100vh;
            max-width: 100%;
        }

        .carousel-info {
            position: absolute;
            z-index: 999;
            width: 30%;
            background: rgba(255, 255, 255, 0.85);
            padding: 24px;
            margin: 24px;
            max-height: 100vh;
            overflow-y: auto;

            h1 {
                margin: 0px;
            }
        }
    }

    // .slider-container {
    //     width: 100%;
    //     min-height: 0;
    //     min-width: 0;
    //     padding: 20px;
    //     overflow: hidden;
    //     }

    //     .slider-container .slick-slide {
    //     // width: 1024px !important; /* Or any fixed width */
    //     }
    //     .slick-list,
    //     .slick-slider,
    //     .slick-track {
    //     display: block;
    //     position: relative;
    //     }
    //     *,
    //     .slick-slider {
    //     box-sizing: border-box;
    //     }
    //     .slick-slider {
    //     -webkit-touch-callout: none;
    //     touch-action: pan-y;
    //     -webkit-user-select: none;
    //     user-select: none;
    //     -khtml-user-select: none;
    //     margin: 30px auto 50px;
    //     }
`;me.div`
    
.homeMultyPurposeCarousel {
  position: relative;

  .container-fluid {
    background-color: rgba(34, 34, 34, 0.1);
  }

  .carousel-indicators {
    display: none;
    button {
      width: 16px;
    }
  }

  .carousel-control-prev,
  .carousel-control-next {
    top: 24px !important;
    right: 24px;
    align-items: start;
    opacity: 0.7 !important;
    width: auto !important;

    @media (max-width: 480px) {
      top: -16px !important;
    }
  }

  .carousel-control-prev {

    @media (min-width: 992px) {
      left: 85% !important;
    }

    @media (max-width: 991px) {
      left: 80% !important;
    }

    @media (max-width: 480px) {
      left: 60% !important;
    }

    
  }

  .carousel-control-prev-icon,
  .carousel-control-next-icon {
    padding: 12px;
    background-color: #222;
    // display: none;
    border-radius: 4px;
    // display: inline-block;
    background-size: 60%;
  }

  .carouselImg,
  .carouselDescription {
    // height: 600px;
    height: 100vh;

    @media (max-width: 480px) {
      height: auto;
    }
  }
  .carouselImg {
    // padding: 8px !important;
    img {
        height: 100%;
        object-fit: cover;
        box-shadow: 10px 0 20px 15px rgba(0, 0, 0, 0.2);
    }
  }

  .carouselDescription {
    padding: 0 80px;

    @media (max-width: 820px) {
      padding: 32px;
    }

    h1 {
      font-size: 32px;
      color: #222;
    }
    span {
      color: #6d2f9b;
    }
  }
}
`;function Ca({editHandler:a,componentType:l,componentTitle:h="Form ",componentState:j=!1,formPostURL:m,formUpdateURL:v,getDataAPIURL:S}){var i;const N=()=>{a(l,!1),document.body.style.overflow=""},[C,f]=V.useState(!1),[O,A]=V.useState(""),[Z,$]=V.useState([]),{register:B,control:M,handleSubmit:te,setValue:D,reset:F,watch:X,formState:{errors:z}}=ht({defaultValues:{title:"",counters:[]}}),{fields:u,append:g,remove:w}=Un({control:M,name:"counters"}),b=X("counters"),s=async c=>{const d={title:c.title,counters:b};let y="";try{c!=null&&c.id?y=await Ce.put(`${v}${c.id}/`,d):y=await Ce.post(m,d),N()}catch(P){bt.error(P[0])}};return V.useEffect(()=>{j&&(async()=>{var t;try{const d=await xe.get(S);if((d==null?void 0:d.status)===200){let y=(t=d==null?void 0:d.data)==null?void 0:t.counterSetList[0];F(y)}}catch{console.log("unable to access ulr because of server is down")}})()},[j,S]),e.jsxs(e.Fragment,{children:[e.jsx(vt,{closeHandler:N,title:h}),e.jsx("hr",{}),e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 px-5",children:[C&&e.jsx("div",{className:"fw-bold",children:C&&e.jsx(hn,{children:C})}),e.jsxs("form",{onSubmit:te(s),children:[e.jsxs("div",{children:[b.length<5&&e.jsx("div",{className:"text-end d-flex justify-content-between",children:e.jsx("div",{className:"text-end",children:e.jsxs(fe,{className:"btn btn-primary",onClick:()=>g({label:"",counter:0,specialChar:""}),children:["Add"," ",e.jsx("i",{className:"fa fa-plus mx-2","aria-hidden":"true"})]})})}),e.jsx(Te,{label:"Title",type:"text",error:(i=z==null?void 0:z.title)==null?void 0:i.message,fieldName:"title",register:B,validationObject:{required:"Please enter Title"}}),u.map((c,t)=>{var d,y,P,k;return e.jsxs("div",{className:"d-flex flex-wrap items-center",children:[e.jsxs("div",{className:"col-md-12",children:[e.jsx(Te,{label:"counters Title",type:"text",error:(d=z==null?void 0:z[`counters.${t}.label`])==null?void 0:d.message,fieldName:`counters.${t}.label`,register:B,validationObject:{required:"Please enter counters Title"}},t),((y=z==null?void 0:z[`counters.${t}.label`])==null?void 0:y.message)&&e.jsx("p",{className:"text-red-600",children:(P=z[`counters.${t}.label`])==null?void 0:P.message})]}),e.jsx("div",{className:"col-md-5",children:e.jsx(Te,{label:"counters Title",type:"number",error:(k=z==null?void 0:z[`counters.${t}.label`])==null?void 0:k.counter,fieldName:`counters.${t}.counter`,register:B,validationObject:{required:"Please enter counters Title"}},t)}),e.jsx("div",{className:"col-md-5",children:e.jsx(Te,{label:"Symbol",type:"text",fieldName:`counters.${t}.symbol`,register:B},t)}),e.jsx("div",{className:"col-md-1",children:e.jsx(fe,{to:"",className:" ms-4",onClick:()=>w(t),children:e.jsx("i",{className:"fa fa-trash-o fs-5 text-danger","aria-hidden":"true",title:"Delete"})})})]},t)})]}),e.jsxs("div",{className:"d-flex justify-content-center flex-wrap flex-column flex-sm-row align-items-center gap-1 gap-md-3 mt-5",children:[e.jsx("button",{className:"btn btn-primary mx-3",children:"save"}),e.jsx(gt,{type:"button",cssClass:"btn btn-sm btn-secondary",label:"Close",handlerChange:N})]})]})]})})})]})}var Le={},Re={exports:{}},Oa=Re.exports,dn;function Na(){return dn||(dn=1,function(a,l){(function(h,j){j(l)})(Oa,function(h){var j=function(){return j=Object.assign||function(v){for(var S,N=1,C=arguments.length;N<C;N++)for(var f in S=arguments[N])Object.prototype.hasOwnProperty.call(S,f)&&(v[f]=S[f]);return v},j.apply(this,arguments)},m=function(){function v(S,N,C){var f=this;this.endVal=N,this.options=C,this.version="2.9.0",this.defaults={startVal:0,decimalPlaces:0,duration:2,useEasing:!0,useGrouping:!0,useIndianSeparators:!1,smartEasingThreshold:999,smartEasingAmount:333,separator:",",decimal:".",prefix:"",suffix:"",enableScrollSpy:!1,scrollSpyDelay:200,scrollSpyOnce:!1},this.finalEndVal=null,this.useEasing=!0,this.countDown=!1,this.error="",this.startVal=0,this.paused=!0,this.once=!1,this.count=function(O){f.startTime||(f.startTime=O);var A=O-f.startTime;f.remaining=f.duration-A,f.useEasing?f.countDown?f.frameVal=f.startVal-f.easingFn(A,0,f.startVal-f.endVal,f.duration):f.frameVal=f.easingFn(A,f.startVal,f.endVal-f.startVal,f.duration):f.frameVal=f.startVal+(f.endVal-f.startVal)*(A/f.duration);var Z=f.countDown?f.frameVal<f.endVal:f.frameVal>f.endVal;f.frameVal=Z?f.endVal:f.frameVal,f.frameVal=Number(f.frameVal.toFixed(f.options.decimalPlaces)),f.printValue(f.frameVal),A<f.duration?f.rAF=requestAnimationFrame(f.count):f.finalEndVal!==null?f.update(f.finalEndVal):f.options.onCompleteCallback&&f.options.onCompleteCallback()},this.formatNumber=function(O){var A,Z,$,B,M=O<0?"-":"";A=Math.abs(O).toFixed(f.options.decimalPlaces);var te=(A+="").split(".");if(Z=te[0],$=te.length>1?f.options.decimal+te[1]:"",f.options.useGrouping){B="";for(var D=3,F=0,X=0,z=Z.length;X<z;++X)f.options.useIndianSeparators&&X===4&&(D=2,F=1),X!==0&&F%D==0&&(B=f.options.separator+B),F++,B=Z[z-X-1]+B;Z=B}return f.options.numerals&&f.options.numerals.length&&(Z=Z.replace(/[0-9]/g,function(u){return f.options.numerals[+u]}),$=$.replace(/[0-9]/g,function(u){return f.options.numerals[+u]})),M+f.options.prefix+Z+$+f.options.suffix},this.easeOutExpo=function(O,A,Z,$){return Z*(1-Math.pow(2,-10*O/$))*1024/1023+A},this.options=j(j({},this.defaults),C),this.formattingFn=this.options.formattingFn?this.options.formattingFn:this.formatNumber,this.easingFn=this.options.easingFn?this.options.easingFn:this.easeOutExpo,this.el=typeof S=="string"?document.getElementById(S):S,N=N??this.parse(this.el.innerHTML),this.startVal=this.validateValue(this.options.startVal),this.frameVal=this.startVal,this.endVal=this.validateValue(N),this.options.decimalPlaces=Math.max(this.options.decimalPlaces),this.resetDuration(),this.options.separator=String(this.options.separator),this.useEasing=this.options.useEasing,this.options.separator===""&&(this.options.useGrouping=!1),this.el?this.printValue(this.startVal):this.error="[CountUp] target is null or undefined",typeof window<"u"&&this.options.enableScrollSpy&&(this.error?console.error(this.error,S):(window.onScrollFns=window.onScrollFns||[],window.onScrollFns.push(function(){return f.handleScroll(f)}),window.onscroll=function(){window.onScrollFns.forEach(function(O){return O()})},this.handleScroll(this)))}return v.prototype.handleScroll=function(S){if(S&&window&&!S.once){var N=window.innerHeight+window.scrollY,C=S.el.getBoundingClientRect(),f=C.top+window.pageYOffset,O=C.top+C.height+window.pageYOffset;O<N&&O>window.scrollY&&S.paused?(S.paused=!1,setTimeout(function(){return S.start()},S.options.scrollSpyDelay),S.options.scrollSpyOnce&&(S.once=!0)):(window.scrollY>O||f>N)&&!S.paused&&S.reset()}},v.prototype.determineDirectionAndSmartEasing=function(){var S=this.finalEndVal?this.finalEndVal:this.endVal;this.countDown=this.startVal>S;var N=S-this.startVal;if(Math.abs(N)>this.options.smartEasingThreshold&&this.options.useEasing){this.finalEndVal=S;var C=this.countDown?1:-1;this.endVal=S+C*this.options.smartEasingAmount,this.duration=this.duration/2}else this.endVal=S,this.finalEndVal=null;this.finalEndVal!==null?this.useEasing=!1:this.useEasing=this.options.useEasing},v.prototype.start=function(S){this.error||(this.options.onStartCallback&&this.options.onStartCallback(),S&&(this.options.onCompleteCallback=S),this.duration>0?(this.determineDirectionAndSmartEasing(),this.paused=!1,this.rAF=requestAnimationFrame(this.count)):this.printValue(this.endVal))},v.prototype.pauseResume=function(){this.paused?(this.startTime=null,this.duration=this.remaining,this.startVal=this.frameVal,this.determineDirectionAndSmartEasing(),this.rAF=requestAnimationFrame(this.count)):cancelAnimationFrame(this.rAF),this.paused=!this.paused},v.prototype.reset=function(){cancelAnimationFrame(this.rAF),this.paused=!0,this.resetDuration(),this.startVal=this.validateValue(this.options.startVal),this.frameVal=this.startVal,this.printValue(this.startVal)},v.prototype.update=function(S){cancelAnimationFrame(this.rAF),this.startTime=null,this.endVal=this.validateValue(S),this.endVal!==this.frameVal&&(this.startVal=this.frameVal,this.finalEndVal==null&&this.resetDuration(),this.finalEndVal=null,this.determineDirectionAndSmartEasing(),this.rAF=requestAnimationFrame(this.count))},v.prototype.printValue=function(S){var N;if(this.el){var C=this.formattingFn(S);!((N=this.options.plugin)===null||N===void 0)&&N.render?this.options.plugin.render(this.el,C):this.el.tagName==="INPUT"?this.el.value=C:this.el.tagName==="text"||this.el.tagName==="tspan"?this.el.textContent=C:this.el.innerHTML=C}},v.prototype.ensureNumber=function(S){return typeof S=="number"&&!isNaN(S)},v.prototype.validateValue=function(S){var N=Number(S);return this.ensureNumber(N)?N:(this.error="[CountUp] invalid start or end value: ".concat(S),null)},v.prototype.resetDuration=function(){this.startTime=null,this.duration=1e3*Number(this.options.duration),this.remaining=this.duration},v.prototype.parse=function(S){var N=function(A){return A.replace(/([.,'  ])/g,"\\$1")},C=N(this.options.separator),f=N(this.options.decimal),O=S.replace(new RegExp(C,"g"),"").replace(new RegExp(f,"g"),".");return parseFloat(O)},v}();h.CountUp=m})}(Re,Re.exports)),Re.exports}var un;function ka(){if(un)return Le;un=1,Object.defineProperty(Le,"__esModule",{value:!0});var a=Oe(),l=Na();function h(b,s){var i=b==null?null:typeof Symbol<"u"&&b[Symbol.iterator]||b["@@iterator"];if(i!=null){var c,t,d,y,P=[],k=!0,r=!1;try{if(d=(i=i.call(b)).next,s!==0)for(;!(k=(c=d.call(i)).done)&&(P.push(c.value),P.length!==s);k=!0);}catch(H){r=!0,t=H}finally{try{if(!k&&i.return!=null&&(y=i.return(),Object(y)!==y))return}finally{if(r)throw t}}return P}}function j(b,s){var i=Object.keys(b);if(Object.getOwnPropertySymbols){var c=Object.getOwnPropertySymbols(b);s&&(c=c.filter(function(t){return Object.getOwnPropertyDescriptor(b,t).enumerable})),i.push.apply(i,c)}return i}function m(b){for(var s=1;s<arguments.length;s++){var i=arguments[s]!=null?arguments[s]:{};s%2?j(Object(i),!0).forEach(function(c){N(b,c,i[c])}):Object.getOwnPropertyDescriptors?Object.defineProperties(b,Object.getOwnPropertyDescriptors(i)):j(Object(i)).forEach(function(c){Object.defineProperty(b,c,Object.getOwnPropertyDescriptor(i,c))})}return b}function v(b,s){if(typeof b!="object"||!b)return b;var i=b[Symbol.toPrimitive];if(i!==void 0){var c=i.call(b,s);if(typeof c!="object")return c;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(b)}function S(b){var s=v(b,"string");return typeof s=="symbol"?s:String(s)}function N(b,s,i){return s=S(s),s in b?Object.defineProperty(b,s,{value:i,enumerable:!0,configurable:!0,writable:!0}):b[s]=i,b}function C(){return C=Object.assign?Object.assign.bind():function(b){for(var s=1;s<arguments.length;s++){var i=arguments[s];for(var c in i)Object.prototype.hasOwnProperty.call(i,c)&&(b[c]=i[c])}return b},C.apply(this,arguments)}function f(b,s){if(b==null)return{};var i={},c=Object.keys(b),t,d;for(d=0;d<c.length;d++)t=c[d],!(s.indexOf(t)>=0)&&(i[t]=b[t]);return i}function O(b,s){if(b==null)return{};var i=f(b,s),c,t;if(Object.getOwnPropertySymbols){var d=Object.getOwnPropertySymbols(b);for(t=0;t<d.length;t++)c=d[t],!(s.indexOf(c)>=0)&&Object.prototype.propertyIsEnumerable.call(b,c)&&(i[c]=b[c])}return i}function A(b,s){return Z(b)||h(b,s)||$(b,s)||M()}function Z(b){if(Array.isArray(b))return b}function $(b,s){if(b){if(typeof b=="string")return B(b,s);var i=Object.prototype.toString.call(b).slice(8,-1);if(i==="Object"&&b.constructor&&(i=b.constructor.name),i==="Map"||i==="Set")return Array.from(b);if(i==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i))return B(b,s)}}function B(b,s){(s==null||s>b.length)&&(s=b.length);for(var i=0,c=new Array(s);i<s;i++)c[i]=b[i];return c}function M(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var te=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u"?a.useLayoutEffect:a.useEffect;function D(b){var s=a.useRef(b);return te(function(){s.current=b}),a.useCallback(function(){for(var i=arguments.length,c=new Array(i),t=0;t<i;t++)c[t]=arguments[t];return s.current.apply(void 0,c)},[])}var F=function(s,i){var c=i.decimal,t=i.decimals,d=i.duration,y=i.easingFn,P=i.end,k=i.formattingFn,r=i.numerals,H=i.prefix,p=i.separator,n=i.start,o=i.suffix,x=i.useEasing,_=i.useGrouping,T=i.useIndianSeparators,I=i.enableScrollSpy,E=i.scrollSpyDelay,L=i.scrollSpyOnce,U=i.plugin;return new l.CountUp(s,P,{startVal:n,duration:d,decimal:c,decimalPlaces:t,easingFn:y,formattingFn:k,numerals:r,separator:p,prefix:H,suffix:o,plugin:U,useEasing:x,useIndianSeparators:T,useGrouping:_,enableScrollSpy:I,scrollSpyDelay:E,scrollSpyOnce:L})},X=["ref","startOnMount","enableReinitialize","delay","onEnd","onStart","onPauseResume","onReset","onUpdate"],z={decimal:".",separator:",",delay:null,prefix:"",suffix:"",duration:2,start:0,decimals:0,startOnMount:!0,enableReinitialize:!0,useEasing:!0,useGrouping:!0,useIndianSeparators:!1},u=function(s){var i=Object.fromEntries(Object.entries(s).filter(function(W){var K=A(W,2),Y=K[1];return Y!==void 0})),c=a.useMemo(function(){return m(m({},z),i)},[s]),t=c.ref,d=c.startOnMount,y=c.enableReinitialize,P=c.delay,k=c.onEnd,r=c.onStart,H=c.onPauseResume,p=c.onReset,n=c.onUpdate,o=O(c,X),x=a.useRef(),_=a.useRef(),T=a.useRef(!1),I=D(function(){return F(typeof t=="string"?t:t.current,o)}),E=D(function(W){var K=x.current;if(K&&!W)return K;var Y=I();return x.current=Y,Y}),L=D(function(){var W=function(){return E(!0).start(function(){k==null||k({pauseResume:U,reset:q,start:J,update:Q})})};P&&P>0?_.current=setTimeout(W,P*1e3):W(),r==null||r({pauseResume:U,reset:q,update:Q})}),U=D(function(){E().pauseResume(),H==null||H({reset:q,start:J,update:Q})}),q=D(function(){E().el&&(_.current&&clearTimeout(_.current),E().reset(),p==null||p({pauseResume:U,start:J,update:Q}))}),Q=D(function(W){E().update(W),n==null||n({pauseResume:U,reset:q,start:J})}),J=D(function(){q(),L()}),ee=D(function(W){d&&(W&&q(),L())});return a.useEffect(function(){T.current?y&&ee(!0):(T.current=!0,ee())},[y,T,ee,P,s.start,s.suffix,s.prefix,s.duration,s.separator,s.decimals,s.decimal,s.formattingFn]),a.useEffect(function(){return function(){q()}},[q]),{start:J,pauseResume:U,reset:q,update:Q,getCountUp:E}},g=["className","redraw","containerProps","children","style"],w=function(s){var i=s.className,c=s.redraw,t=s.containerProps,d=s.children,y=s.style,P=O(s,g),k=a.useRef(null),r=a.useRef(!1),H=u(m(m({},P),{},{ref:k,startOnMount:typeof d!="function"||s.delay===0,enableReinitialize:!1})),p=H.start,n=H.reset,o=H.update,x=H.pauseResume,_=H.getCountUp,T=D(function(){p()}),I=D(function(U){s.preserveValue||n(),o(U)}),E=D(function(){if(typeof s.children=="function"&&!(k.current instanceof Element)){console.error(`Couldn't find attached element to hook the CountUp instance into! Try to attach "containerRef" from the render prop to a an Element, eg. <span ref={containerRef} />.`);return}_()});a.useEffect(function(){E()},[E]),a.useEffect(function(){r.current&&I(s.end)},[s.end,I]);var L=c&&s;return a.useEffect(function(){c&&r.current&&T()},[T,c,L]),a.useEffect(function(){!c&&r.current&&T()},[T,c,s.start,s.suffix,s.prefix,s.duration,s.separator,s.decimals,s.decimal,s.className,s.formattingFn]),a.useEffect(function(){r.current=!0},[]),typeof d=="function"?d({countUpRef:k,start:p,reset:n,update:o,pauseResume:x,getCountUp:_}):a.createElement("span",C({className:i,ref:k,style:y},t),typeof s.start<"u"?_().formattingFn(s.start):"")};return Le.default=w,Le.useCountUp=u,Le}var Ta=ka();const Pa=gn(Ta),_a=({getDataAPIURL:a,componentState:l})=>{const[h,j]=V.useState([]);return V.useEffect(()=>{l||(async()=>{var v;try{const S=await xe.get(a);(S==null?void 0:S.status)===200?j((v=S==null?void 0:S.data)!=null&&v.counterSetList?S.data.counterSetList[0]:[]):j([])}catch{j([]),console.log("unable to access ulr because of server is down")}})()},[l,a]),e.jsxs("div",{className:"counterComponentView d-flex flex-column align-items-center justify-content-between",children:[!h&&e.jsx(vn,{}),(h==null?void 0:h.title)!==""&&e.jsx(pe,{title:h==null?void 0:h.title,cssClass:"counterTitle"}),e.jsx("div",{className:"counterComponentViewContainer d-flex flex-wrap justify-content-center",children:(h==null?void 0:h.counters)&&h.counters.map((m,v)=>e.jsxs("div",{className:"counterItem text-center d-flex align-items-center justify-content-center m-md-2",children:[e.jsx("h3",{className:"counterLabel",children:m.label}),e.jsx("p",{className:"counterValue",children:e.jsx(Pa,{end:m.counter,delay:2})}),e.jsx("span",{className:"counterSymbol",children:m.symbol})]},v))})]})},fn="/static/assets/industriesWeServe-DicFZbff.jpg",Ea=me.div`
    background-image: url(${fn});
    background-position: top;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    color: ${({theme:a})=>a.white};;
    position: relative;

    @media(min-width: 992px) {
        padding: 180px 0;
    }

    @media(max-width: 991px) {
        padding: 120px 0;
    }

    @media(max-width: 480px) {
        padding: 90px 0;
    }

    &::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(
            to bottom,
            // rgba(1, 33, 96, 0.92),  
            rgba(0, 0, 0, 0.9),
             #ef3f366d
        );
        z-index: 0;
        pointer-events: none; /* let clicks pass through */
    }

     > * {
        position: relative;
        z-index: 1;
    }

    .counterComponentView {
        .counterTitle{
            text-align: center;
            margin: auto;
            color: ${({theme:a})=>a.white} !important;

            @media(max-width: 480px) {
                font-size: 1.5rem !important;
                margin-bottom: 20px;
            }
        }
    }
    
    .counterComponentViewContainer  {
        border: 2px solid rgba(255, 255, 255, .1);
        box-shadow: 0 0.2rem 1rem rgba(0, 0, 0, 0.4);
        padding: 24px;
        margin-top: 1rem;
        gap: 30px;

        @media(max-width: 991px) {
            gap: 24px;
        }

        @media(max-width: 480px) {
            gap: 10px;
        }

        .counterItem {
            gap: 28px;

            @media(max-width: 991px) { 
                gap: 24px;
            }

            @media(max-width: 480px) {
                gap: 12px;
            }
        }

        .counterLabel {
            width: 120px;
            text-align: right;

            @media(min-width: 481px) {
                font-size: 1.2rem;
            }

            @media(max-width: 480px) {
                font-size: 1.2rem;
            }
        }

        .counterValue {
            
            // text-decoration: underline;
            // text-underline-offset: 12px;
            // text-decoration-thickness: 4px;
            // text-decoration-color: ${({theme:a})=>a.black};
            color: ${({theme:a})=>a.white};
            // box-shadow: 0 0.2rem 1rem rgba(0, 0, 0, 0.4);

            font-weight: bold;
            background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.8)), url(${fn});
             background-size: cover;
            background-position: center;
            color: transparent;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent; 
        }

        

        .counterValue, .counterLabel  {
            margin: 0
        }
    }

    .counterValue {
        span {
            font-size: 8rem;

            @media(max-width: 991px) {
                font-size: 5rem;
            }

            @media(max-width: 480px) {
                font-size: 4rem;
            }
        }
    }

    .counterSymbol {
        font-size: 3rem;

         @media(max-width: 480px) {
            font-size: 2rem;
        }
    }
`,Ma=me.div`

  .carousel-item::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(180deg, rgba(0, 0, 0, .15) 0%, rgba(0, 0, 0, .75) 80%);
    z-index: 1;
    pointer-events: none;
  }

  .carousel-item {
    overflow: hidden;
    height: 60vh;
    position: relative;

    @media (max-width: 480px) {
      height: 50vh;
    }

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .carousel-caption {
      position: absolute;
      z-index: 999;
      position: absolute;
      z-index: 999;
      text-align: left !important;
      bottom: 10%;
      right: 10%;
      width: 50%;

      @media(max-width: 1280px) {
        width: 60%;
        bottom: 10%;
      }

      @media(max-width: 1024px) {
        width: 70%;
        bottom: 15%;
      }

      @media(max-width: 480px) {
        padding: 0px !important;
        bottom: 5%;
      }

      h1 {
        letter-spacing: 0.1rem;
        font-weight: 600 !important;
        font-size: 3rem !important;
        margin: 0px;
        text-shadow: 0px 4px 0 rgba(0,0,0, .3);
        color:${({theme:a})=>a.carouselSlideTitleColor};
        word-wrap: break-word;
        hyphens: auto;
        line-height: 1.4;

        @media(max-width: 480px) {
          font-size: 2rem !important;
          font-weight: normal  !important;
        }
        }
      }

      p.description {
        color: ${({theme:a})=>a.white};
        color:${({theme:a})=>a.carouselSlideCaptionColor};

        @media(max-width: 768px) {
          font-size: 0.9rem !important;
          letter-spacing: 0.1rem;
          font-weight: normal;
          overflow: hidden;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 3;
        }
      }

      .subtitle {
        color: ${({theme:a})=>a.white};
        letter-spacing: .1rem;
        text-transform: uppercase;
        font-weight: normal !important;
        font-family: "Barlow",sans-serif;
        font-size: 1.2rem;

        @media(min-width: 768px) {
          font-size: .9rem;
        }

        @media(max-width: 768px) {
          display: none;
        }
      }

      .ql-editor {
        padding: 0;
        p, p span {
          color: #fff;
          font-size: 1.2rem !important;
          line-height: 1.4;
          font-weight: normal !important;
          text-align: left;
        }
      }
    }
  
// .noImg {
//   min-height: 300px;
// }


@media (max-width: 768px) {

  
// .banner {
//     height: 200px !important;
//   }

//   .homeCarousel::after {
//     content: "";
//     display: block;
//     position: absolute;
//     height: 60vh; 
//     width: 100%;
//     top: 0;
//   }

// HOME MULTI PURPOSE CAROUSEL

// .homeMultyPurposeCarousel {
//   background-color: rgba(34, 34, 34, .1);
//   position: relative;

//   .container {
//     background-color: rgba(34, 34, 34, 0.1);
//   }

//   .carousel-indicators {
//     display: none;
//     button {
//       width: 16px;
//     }
//   }

//   .carousel-control-prev,
//   .carousel-control-next {
//     top: 24px !important;
//     align-items: start;
//     opacity: 0.7 !important;

//     @media (max-width: 480px) {
//       top: -16px !important;
//     }
//   }

//   .carousel-control-prev {
//     left: 88% !important;

//     @media (min-width: 421px) and (max-width: 991px) {
//       left: 78% !important;
//     }

//     @media (max-width: 480px) {
//       left: 65% !important;
//     }
//   }

//   .carousel-control-prev-icon,
//   .carousel-control-next-icon {
//     padding: 12px;
//     background-color: #222;
//     border-radius: 4px;
//     display: inline-block;
//     background-size: 60%;
//   }

//   .carouselImg,
//   .carouselDescription {
//     height: 500px;

//     @media (max-width: 480px) {
//       height: auto;
//     }
//   }
//   .carouselImg img {
//     height: 100%;
//     object-fit: cover;
//   }

//   .carouselDescription {
//     padding: 0 80px;

//     @media (max-width: 820px) {
//       padding: 32px;
//     }

//     h1 {
//       font-size: 32px;
//       color: #222;
//     }
//     span {
//       color: #6d2f9b;
//     }
//   }
// }
}

`,Ga=()=>{var T,I,E,L,U,q,Q,J,ee,W,K,Y,se,G,ae,oe,le,de,ve,Ne,_e,je,Ve,he,Se,xt,jt,St,wt,Ct,Ot,Nt,kt,Tt,Pt,_t,Et,Mt,It,Lt,Rt,Dt,At,Vt,zt,Ht,Bt,Ft,Ut,qt,Wt,Zt,$t,Kt,Qt,Gt,Xt,Yt,Jt,er,tr,rr,nr,ir,ar,sr,or,lr,cr,dr,ur,fr,pr,mr,hr,vr,gr,br,yr,xr,jr,Sr,wr,Cr,Or,Nr,kr,Tr,Pr,_r,Er,Mr,Ir,Lr,Rr,Dr,Ar;const a={carousel:!1,briefIntro:!1,homeServicebriefIntro:!1,projects:!1,projectsBrief:!1,testmonial:!1,serviceOffered:!1,product_development:!1,product_distribution:!1,iconsHelightsBrief:!1,projectbriefIntro:!1,homeService0:!1,homeService1:!1,homeService2:!1,homeService3:!1,homeService4:!1,homeService5:!1,homeDynamciServices:!1,homeDynamciServicesBrief:!1,counterlist:!1,trainings:!1},l={product_development:"product_development",product_distribution:"product_distribution",product_registration:"product_registration"},[h,j]=V.useState(0),m="home",v="serviceOffered",[S,N]=V.useState([]),{isAdmin:C,hasPermission:f}=ft(),[O,A]=V.useState(a),[Z,$]=V.useState(!1),[B,M]=V.useState([]),[te,D]=V.useState([]),[F,X]=V.useState([]),{categories:z}=ye(re=>re.categoryList),{isLoading:u}=ye(re=>re.loader);V.useRef(!0);const[g,w]=V.useState(""),[b,s]=V.useState(""),[i,c]=V.useState(""),[t,d]=V.useState([]),{serviceMenu:y}=ye(re=>re.serviceMenu),{homeIntroList:P}=ye(re=>re.homeIntroList),k=yt(),r=(re,ne)=>{A(ue=>({...ue,[re]:ne})),$(ne),document.body.style.overflow="hidden"},H=re=>{if((re==null?void 0:re.results.length)>0){const ne=mt(re.results[0]),ue=De(re.results,ne);M(ue.slice(0,4))}else M([])};V.useEffect(()=>{P.length==0&&k(bn())},[P==null?void 0:P.length]),V.useEffect(()=>{const re=async()=>{z.map(ue=>ue.id);const ne=[];z.forEach((ue,Vr)=>{ne.push(xe.get(`/products/getClinetProduct/${ue.id}/`))}),await Promise.all(ne).then(function(ue){const Vr=Gn(ue,z);X(Vr)})};(z==null?void 0:z.length)>0&&(F==null?void 0:F.length)===0&&re()},[z]),V.useEffect(()=>{qn(),k(Wn())},[]),V.useEffect(()=>{const re=async()=>{try{const ne=await xe.get("/testimonials/clientTestimonials/");if((ne==null?void 0:ne.status)===200){const ue=De(ne.data.results,"testimonial_position");N(ue)}}catch{console.log("unable to access ulr because of server is down")}};O.testmonial||re()},[O.testmonial]),V.useEffect(()=>{(async()=>{try{const ne=await xe.get("/client/getAllClientLogos/");if((ne==null?void 0:ne.status)===200){const ue=De(ne.data.clientLogo,"client_position");D(ue)}}catch{console.log("unable to access ulr because of server is down")}})()},[]),V.useEffect(()=>{window.scrollTo(0,0)},[]);const{error:p,success:n,showHideList:o}=ye(re=>re.showHide);V.useEffect(()=>{o.length>0&&d(Zn(o))},[o]);const x=async(re,ne)=>{if(re)k(Xn(re));else{const ue={componentName:ne.toLowerCase(),pageType:m};k(Yn(ue))}},_=[1,2,3,4,5,6];return e.jsx(e.Fragment,{children:e.jsxs("div",{className:"container-fluid p-0",children:[e.jsx(wa,{children:e.jsx("div",{className:"homeBrochure",children:e.jsx($n,{})})}),e.jsxs("div",{className:(T=t==null?void 0:t.banner)!=null&&T.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(I=t==null?void 0:t.banner)==null?void 0:I.visibility,title:"HERO Banner",componentName:"banner",showHideHandler:x,id:(E=t==null?void 0:t.banner)==null?void 0:E.id}),((L=t==null?void 0:t.banner)==null?void 0:L.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 position-relative homePage",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("banner",!0),editlabel:"Banner"}),e.jsx(ti,{getBannerAPIURL:`banner/clientBannerIntro/${m}-banner/`,bannerState:O.banner})]})}),O.banner&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(pn,{editHandler:r,componentType:"banner",pageType:`${m}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:mn(`${m}-banner`),dimensions:ge("banner")})})]})]}),e.jsxs("div",{className:(U=t==null?void 0:t.carousel)!=null&&U.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(q=t==null?void 0:t.carousel)==null?void 0:q.visibility,title:"HERO Carousel",componentName:"carousel",showHideHandler:x,id:(Q=t==null?void 0:t.carousel)==null?void 0:Q.id}),((J=t==null?void 0:t.carousel)==null?void 0:J.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"container-fluid",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 carousel",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("carousel",!0),editlabel:"Carousel"}),e.jsx(Ma,{children:e.jsx(Ze,{carouselState:O.carousel,category:"carousel",containerId:"carouselHomeGallery"})})]})})}),O.carousel&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:r,componentType:"carousel",popupTitle:"Hero Carousel",getImageListURL:"carousel/createCarousel/carousel/",deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/carousel/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"Add Image",showDescription:!1,showExtraFormFields:Hr("carousel"),dimensions:ge("carousel")})})]})]}),e.jsxs("div",{className:(ee=t==null?void 0:t.briefintro)!=null&&ee.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(W=t==null?void 0:t.briefintro)==null?void 0:W.visibility,title:"A Brief Introduction Component",componentName:"briefintro",showHideHandler:x,id:(K=t==null?void 0:t.briefintro)==null?void 0:K.id}),((Y=t==null?void 0:t.briefintro)==null?void 0:Y.visibility)&&e.jsxs("div",{className:"homeBriefIntroduction",children:[e.jsx("div",{className:"container",children:e.jsxs("div",{className:"row",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("briefIntro",!0),editlabel:"Brief"}),e.jsx(be,{introState:O.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"text-center",introSubTitleCss:"mt-2 text-center",introDecTitleCss:"fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-10 offset-md-1",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:m})]})}),O.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"briefIntro",popupTitle:"Brief Intro Banner",pageType:"Home"})})]})]}),e.jsx("div",{className:(se=t==null?void 0:t.hprinfra)!=null&&se.visibility&&C&&f?"border border-info mb-2":"",children:e.jsxs("div",{className:"commonBg homeProjectsContainer",children:[C&&f&&e.jsx(ie,{showhideStatus:(G=t==null?void 0:t.hprinfra)==null?void 0:G.visibility,title:"Projects coming form project dashboard - olny 3",componentName:"hprinfra",showHideHandler:x,id:(ae=t==null?void 0:t.hprinfra)==null?void 0:ae.id}),((oe=t==null?void 0:t.hprinfra)==null?void 0:oe.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{children:[e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("projectbriefIntro",!0),editlabel:"Projects"}),e.jsx(be,{introState:O.projectbriefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"text-center",introSubTitleCss:"text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 pt-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:`${m}projectbriefIntro`})]})})}),O.projectbriefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"projectbriefIntro",popupTitle:"Brief Intro Banner",pageType:`${m}projectbriefIntro`})})]}),e.jsx(_i,{})]})]})}),e.jsxs("div",{className:(le=t==null?void 0:t.homedynamciservicesbrief)!=null&&le.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(de=t==null?void 0:t.homedynamciservicesbrief)==null?void 0:de.visibility,title:"Services coming from service page - max 6 ",componentName:"homedynamciservicesbrief",showHideHandler:x,id:(ve=t==null?void 0:t.homedynamciservicesbrief)==null?void 0:ve.id}),((Ne=t==null?void 0:t.homedynamciservicesbrief)==null?void 0:Ne.visibility)&&e.jsx(Sa,{children:e.jsxs("div",{className:"homeDynamciServicesIntro",children:[e.jsx("div",{className:"container",children:e.jsxs("div",{className:"breiftopMargin col-md-10 offset-md-1",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("homeDynamciServicesBrief",!0)}),e.jsx(be,{introState:O.homeDynamciServicesBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"text-center",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center",detailsContainerCss:"col-md-12",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"homeDynamciServicesBrief",maxHeight:"300"}),O.homeDynamciServicesBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"homeDynamciServicesBrief",popupTitle:"Brief Intro Banner",pageType:"homeDynamciServicesBrief"})})]})}),e.jsx("div",{className:"container-fluid homeDynamciServices py-5",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsx(ri,{})})})})]})})]}),e.jsxs("div",{className:(_e=t==null?void 0:t.homeservices)!=null&&_e.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(je=t==null?void 0:t.homeservices)==null?void 0:je.visibility,title:"Turbin Trainings",componentName:"homeservices",showHideHandler:x,id:(Ve=t==null?void 0:t.homeservices)==null?void 0:Ve.id}),((he=t==null?void 0:t.homeservices)==null?void 0:he.visibility)&&e.jsxs(ja,{children:[e.jsx("div",{className:"container-fluid homeServicesBrief",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("homeServicebriefIntro",!0),editlabel:"Services"}),e.jsx(be,{introState:O.homeServicebriefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"text-center",introSubTitleCss:"text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"HomeserviceBrief"})]})})})}),e.jsx("div",{className:"homeServicesContainer",children:e.jsx("div",{className:"container py-5 homeServices",children:_.map((re,ne)=>e.jsx("div",{className:"col-sm-6 col-md-4",children:e.jsx(Ii,{editHandler:r,objectstatus:O[`homeService${ne}`],pageType:`homeService${ne}`},ne)},ne))})}),O.homeServicebriefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"homeServicebriefIntro",popupTitle:"Brief Intro Banner",pageType:"HomeserviceBrief"})})]})]}),e.jsxs("div",{className:(Se=t==null?void 0:t.iconshelightsbrief)!=null&&Se.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(xt=t==null?void 0:t.iconshelightsbrief)==null?void 0:xt.visibility,title:"Icons Brief",componentName:"iconshelightsbrief",showHideHandler:x,id:(jt=t==null?void 0:t.iconshelightsbrief)==null?void 0:jt.id}),((St=t==null?void 0:t.iconshelightsbrief)==null?void 0:St.visibility)&&e.jsx("div",{className:"homeBriefheilights",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("iconsHelightsBrief",!0),editlabel:""}),e.jsx(be,{introState:O.iconsHelightsBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-bold text-center mb-4",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"iconsHelightsBrief"}),O.iconsHelightsBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"iconsHelightsBrief",popupTitle:"Brief Intro Banner",pageType:"iconsHelightsBrief"})})]})})})})]}),e.jsxs("div",{className:(wt=t==null?void 0:t.homeprojectcarousel)!=null&&wt.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Ct=t==null?void 0:t.homeprojectcarousel)==null?void 0:Ct.visibility,title:"Home Project Carousel",componentName:"homeprojectcarousel",showHideHandler:x,id:(Ot=t==null?void 0:t.homeprojectcarousel)==null?void 0:Ot.id}),((Nt=t==null?void 0:t.homeprojectcarousel)==null?void 0:Nt.visibility)&&e.jsx(Mi,{})]}),e.jsxs("div",{className:(kt=t==null?void 0:t.trainings)!=null&&kt.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Tt=t==null?void 0:t.trainings)==null?void 0:Tt.visibility,title:"Corporate Training",componentName:"trainings",showHideHandler:x,id:(Pt=t==null?void 0:t.trainings)==null?void 0:Pt.id}),((_t=t==null?void 0:t.trainings)==null?void 0:_t.visibility)&&e.jsx(Ur,{children:e.jsx("div",{className:"container-fluid testimonialsContainer",children:e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-md-12 col-lg-8 offset-lg-2 testimonials text-center",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("trainings",!0),editlabel:""}),P.length>0&&e.jsx(ya,{list:P})]}),O.testmonial&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ba,{editHandler:r,componentType:"trainings",popupTitle:"Corporate Training",homeintros:P,pageType:"trainings"})})]})})})]}),e.jsxs("div",{className:(Et=t==null?void 0:t.testimonis)!=null&&Et.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Mt=t==null?void 0:t.testimonis)==null?void 0:Mt.visibility,title:"Testimonials",componentName:"testimonis",showHideHandler:x,id:(It=t==null?void 0:t.testimonis)==null?void 0:It.id}),((Lt=t==null?void 0:t.testimonis)==null?void 0:Lt.visibility)&&e.jsx(Ur,{children:e.jsxs("div",{className:"container-fluid",children:[e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12",children:e.jsx(pe,{title:"Testimonials",cssClass:"fs-1 fw-bold text-center my-5 text-uppercase"})})}),e.jsxs("div",{className:"row",children:[e.jsxs("div",{className:"col-md-12 testimonials text-center",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("testmonial",!0)}),S.length<1?(S.length,"No Testimonials Found"):S.length===1?e.jsx("h4",{children:"Please add 2 or more testimonials."}):S.length>1?e.jsx(di,{testimonis:S}):""]}),O.testmonial&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:r,componentType:"testmonial",popupTitle:"Testmonial Banner",getImageListURL:"testimonials/clientTestimonials/",deleteImageURL:"testimonials/updateTestimonials/",imagePostURL:"testimonials/createTestimonials/",imageUpdateURL:"testimonials/updateTestimonials/",imageIndexURL:"testimonials/updateTestimonialsindex/",imageLabel:"Add your Image",titleTitle:"Testmonial Name",descriptionTitle:"Testimonial Writeup ",showDescription:!1,showExtraFormFields:Kn("testmonial"),dimensions:ge("testimonial")})})]})]})})]}),e.jsxs("div",{className:(Rt=t==null?void 0:t.homeclient)!=null&&Rt.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Dt=t==null?void 0:t.homeclient)==null?void 0:Dt.visibility,title:"Home Client",componentName:"homeclient",showHideHandler:x,id:(At=t==null?void 0:t.homeclient)==null?void 0:At.id}),((Vt=t==null?void 0:t.homeclient)==null?void 0:Vt.visibility)&&e.jsx(Si,{children:e.jsx(ha,{clientsList:te})})]}),e.jsxs("div",{className:(zt=t==null?void 0:t.counterlist)!=null&&zt.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Ht=t==null?void 0:t.counterlist)==null?void 0:Ht.visibility,title:"Counter Component",componentName:"counterlist",showHideHandler:x,id:(Bt=t==null?void 0:t.counterlist)==null?void 0:Bt.id}),((Ft=t==null?void 0:t.counterlist)==null?void 0:Ft.visibility)&&e.jsxs("div",{className:"container-fluid",children:[e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 ",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("counterlist",!0)}),e.jsx(Ea,{children:e.jsx(_a,{getDataAPIURL:"counter/getClientCounterSet/",componentState:O.counterlist})})]})}),O.counterlist&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(Ca,{editHandler:r,componentType:"counterlist",componentTitle:"Counter component",formPostURL:"/counter/create/",formUpdateURL:"/counter/updateCounterlist/",getDataAPIURL:"/counter/getClientCounterSet/",componentState:O.counterlist})})]})]}),e.jsxs("div",{className:(Ut=t==null?void 0:t.industriesweserve)!=null&&Ut.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(qt=t==null?void 0:t.industriesweserve)==null?void 0:qt.visibility,title:"Industries We Serve",componentName:"industriesweserve",showHideHandler:x,id:(Wt=t==null?void 0:t.industriesweserve)==null?void 0:Wt.id}),((Zt=t==null?void 0:t.industriesweserve)==null?void 0:Zt.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"container pt-5",children:e.jsxs("div",{className:"breiftopMargin",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("industriesweserveBrief",!0)}),e.jsx(be,{introState:O.industriesweserveBrief,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"mb-0 text-center fw-medium",introSubTitleCss:"fw-medium text-muted text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center",detailsContainerCss:"col-md-12",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:"industriesweserveBrief",maxHeight:"300"}),O.industriesweserveBrief&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"industriesweserveBrief",popupTitle:"Brief Intro Banner",pageType:"industriesweserveBrief"})})]})}),e.jsx("div",{className:"container-fluid",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 p-0 carousel",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("industriesweserve",!0)}),e.jsx(Br,{children:e.jsx("div",{className:"container-fluid",children:e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-md-10 offset-md-1 homeGalleryCarousel",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12",children:e.jsx(Ze,{carouselState:O.industriesweserve,category:"industriesweserve",containerId:"industriesweserve-carousel"})})})})})})})})]})})}),O.industriesweserve&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ze,{editHandler:r,componentType:"industriesweserve",popupTitle:"Industries We Serve",getImageListURL:"carousel/createCarousel/industriesweserve/",deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/industriesweserve/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"industries we serve",showDescription:!1,showExtraFormFields:Hr("industriesweserve"),dimensions:ge("carousel")})})]})]}),e.jsxs("div",{className:($t=t==null?void 0:t.producthilight)!=null&&$t.visibility&&C&&f?"border border-info mb-2":"",style:(Kt=t==null?void 0:t.producthilight)!=null&&Kt.visibility?{height:"160px"}:{},children:[C&&f&&e.jsx(ie,{showhideStatus:(Qt=t==null?void 0:t.producthilight)==null?void 0:Qt.visibility,title:"Product highlight",componentName:"producthilight",showHideHandler:x,id:(Gt=t==null?void 0:t.producthilight)==null?void 0:Gt.id}),((Xt=t==null?void 0:t.producthilight)==null?void 0:Xt.visibility)&&e.jsx(Ni,{children:e.jsx("div",{className:"container position-relative d-none d-md-block",children:e.jsxs("div",{className:"row rounded-3 overflow-hidden position-absolute hiligntsContainer",children:[e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[C&&f&&e.jsx(ce,{editHandler:()=>r(l.product_development,!0),editlabel:"Hilights"}),e.jsx($e,{formgetURL:`/carousel/clientHomeIntro/${l.product_development}/`,componentEdit:O.product_development,setFormValues:w,formvalues:g}),O.product_development&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Ke,{editHandler:r,componentType:l.product_development,componentTitle:"Product Development component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:g,dynamicFormFields:We(l.product_development)})})]})}),e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[C&&f&&e.jsx(ce,{editHandler:()=>r(l.product_distribution,!0),editlabel:"Hilights"}),e.jsx($e,{formgetURL:`/carousel/clientHomeIntro/${l.product_distribution}/`,componentEdit:O.product_distribution,setFormValues:s,formvalues:b}),O.product_distribution&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Ke,{editHandler:r,componentType:l.product_distribution,componentTitle:"Product Distribution component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:b,dynamicFormFields:We(l.product_distribution)})})]})}),e.jsx("div",{className:"col-sm-4 p-4 p-lg-5 py-lg-4 ",children:e.jsxs("div",{className:"position-relative",children:[C&&f&&e.jsx(ce,{editHandler:()=>r(l.product_registration,!0),editlabel:"Hilights"}),e.jsx($e,{formgetURL:`/carousel/clientHomeIntro/${l.product_registration}/`,componentEdit:O.product_registration,setFormValues:c,formvalues:i}),O.product_registration&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Ke,{editHandler:r,componentType:l.product_registration,componentTitle:"Product Distribution component",formPostURL:"/carousel/createHomeIntro/",formUpdateURL:"/carousel/updateHomeIntro/",editObject:i,dynamicFormFields:We(l.product_registration)})})]})})]})})})]}),e.jsxs("div",{className:(Yt=t==null?void 0:t.services)!=null&&Yt.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Jt=t==null?void 0:t.services)==null?void 0:Jt.visibility,title:"Image with Text description",componentName:"services",showHideHandler:x,id:(er=t==null?void 0:t.services)==null?void 0:er.id}),((tr=t==null?void 0:t.services)==null?void 0:tr.visibility)&&e.jsxs(Jn,{children:[e.jsx("h1",{className:"fs-1 fw-bold text-center text-uppercase",children:"Image with Text description"}),e.jsxs("div",{className:"container-lg mx-0 mx-md-0 px-md-0 mx-lg-auto randomServices",children:[e.jsx("div",{className:"row",children:e.jsx(He,{col1:"col-md-6 ps-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingLeft shadow",dimensions:ge("whoweare"),pageType:"productPortfolio",componentFlip:!1})}),e.jsx("div",{className:"row d-flex flex-row-reverse my-3 my-md-5",children:e.jsx(He,{col1:"col-md-6 pe-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingRight shadow imgStyling",dimensions:ge("whoweare"),pageType:"promoting",componentFlip:!1})}),e.jsx("div",{className:"row",children:e.jsx(He,{col1:"col-md-6 ps-sm-0",col2:"col-md-6 p-4 p-md-5 d-flex justify-content-center align-items-start flex-column",cssClass:"fs-3 mb-3 fw-bolder title",imageClass:"w-100 object-fit-cover imgStylingLeft shadow",dimensions:ge("whoweare"),pageType:"whatwedo",componentFlip:!1})})]})]})]}),e.jsxs("div",{className:(rr=t==null?void 0:t.homeproducts)!=null&&rr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(nr=t==null?void 0:t.homeproducts)==null?void 0:nr.visibility,title:"Home Products",componentName:"homeproducts",showHideHandler:x,id:(ir=t==null?void 0:t.homeproducts)==null?void 0:ir.id}),((ar=t==null?void 0:t.homeproducts)==null?void 0:ar.visibility)&&e.jsxs("div",{className:"container",children:[e.jsx(pe,{title:"Products",cssClass:"fs-1 fw-bold text-center my-5 pt-0 pt-md-5 text-uppercase"}),e.jsx("div",{className:"row",children:F.map(re=>{var ne;return((ne=re==null?void 0:re.products)==null?void 0:ne.length)>0&&e.jsx("div",{children:e.jsx(ii,{item:re.products[0],categoryId:re.id})},re.id)})})]})]}),e.jsxs("div",{className:(sr=t==null?void 0:t.productslist)!=null&&sr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(or=t==null?void 0:t.productslist)==null?void 0:or.visibility,title:"Product Details - static ",componentName:"productslist",showHideHandler:x,id:(lr=t==null?void 0:t.productslist)==null?void 0:lr.id}),((cr=t==null?void 0:t.productslist)==null?void 0:cr.visibility)&&e.jsx(Ti,{children:e.jsxs("div",{className:"container py-5 randomServices",children:[e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:wi,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(pe,{title:"Product portfolio",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(fe,{to:"",className:"moreLink",children:"More..."})]})]}),e.jsxs("div",{className:"row my-2 my-md-5 d-flex flex-row flex-md-row-reverse",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:Ci,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(pe,{title:"Promoting healt and well being",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(fe,{to:"",className:"moreLink",children:"More..."})]})]}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6",children:e.jsx("img",{src:Oi,alt:"",className:"w-100 shadow"})}),e.jsxs("div",{className:"col-md-6 p-3 p-md-5 d-flex flex-column justify-content-center",children:[e.jsx(pe,{title:"What we do",cssClass:"text-black fs-3 fw-medium"}),e.jsx("p",{children:"Through our relentless pursuit of quality and innovation, we have achieved several milestones that highlight our success in the healthcare industry."}),e.jsx(fe,{to:"",className:"moreLink",children:"More..."})]})]})]})})]}),e.jsxs("div",{className:(dr=t==null?void 0:t.news)!=null&&dr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(ur=t==null?void 0:t.news)==null?void 0:ur.visibility,title:"News",componentName:"news",showHideHandler:x,id:(fr=t==null?void 0:t.news)==null?void 0:fr.id}),((pr=t==null?void 0:t.news)==null?void 0:pr.visibility)&&e.jsx("div",{className:"row py-5 homeNews",children:e.jsx("div",{className:"col-md-12 d-flex justify-content-center align-items-center",children:e.jsxs("div",{className:"container",children:[e.jsx(pe,{title:"News",cssClass:"fs-1 fw-bold text-center my-5 pt-0 pt-md-5 text-uppercase"}),e.jsx(ei,{news:B,setNews:H,pagetype:m}),e.jsx("div",{className:"d-flex justify-content-center align-items-center mt-4",children:e.jsx(lt,{AncherLabel:"More Articles",Ancherpath:"/news",AncherClass:"btn btn-outline d-flex justify-content-center align-items-center ",AnchersvgColor:"#17427C"})})]})})})]}),e.jsxs("div",{className:(mr=t==null?void 0:t.features)!=null&&mr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(hr=t==null?void 0:t.features)==null?void 0:hr.visibility,title:"Features -  static",componentName:"features",showHideHandler:x,id:(vr=t==null?void 0:t.features)==null?void 0:vr.id}),((gr=t==null?void 0:t.features)==null?void 0:gr.visibility)&&e.jsx(ji,{})]}),e.jsxs("div",{className:(br=t==null?void 0:t.news)!=null&&br.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(yr=t==null?void 0:t.whoweare)==null?void 0:yr.visibility,title:"Who we are",componentName:"whoweare",showHideHandler:x,id:(xr=t==null?void 0:t.whoweare)==null?void 0:xr.id}),((jr=t==null?void 0:t.whoweare)==null?void 0:jr.visibility)&&e.jsx("div",{className:"row ABriefAbout mb-5",children:e.jsx(He,{cssClass:"mb-2 fw-bold title text-black",dimensions:ge("whoweare")})})]}),e.jsxs("div",{className:(Sr=t==null?void 0:t.homeservicedetails)!=null&&Sr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(wr=t==null?void 0:t.homeservicedetails)==null?void 0:wr.visibility,title:"Services Details - custom design",componentName:"homeservicedetails",showHideHandler:x,id:(Cr=t==null?void 0:t.homeservicedetails)==null?void 0:Cr.id}),((Or=t==null?void 0:t.homeservicedetails)==null?void 0:Or.visibility)&&e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12 ABrief",children:e.jsx(ui,{cssClass:"fw-bold title",dimensions:ge("homeCareers")})})})]}),e.jsxs("div",{className:(Nr=t==null?void 0:t.homecareers)!=null&&Nr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(kr=t==null?void 0:t.homecareers)==null?void 0:kr.visibility,title:"Careers",componentName:"homecareers",showHideHandler:x,id:(Tr=t==null?void 0:t.homecareers)==null?void 0:Tr.id}),((Pr=t==null?void 0:t.homecareers)==null?void 0:Pr.visibility)&&e.jsxs("div",{className:"row homeCareers py-5",children:[e.jsx("div",{className:"col-lg-6"}),e.jsxs("div",{className:"col-md-12 col-lg-6 pe-lg-5",children:[e.jsx(be,{introState:O.briefIntro,pageType:"careers",introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center"}),e.jsx("div",{className:"bg-white px-5 pb-4 d-flex justify-content-center align-items-center",children:e.jsx(lt,{AncherLabel:"Careers",Ancherpath:"/careers",AncherClass:"btn btn-primary d-flex justify-content-center align-items-center gap-3 w-50",AnchersvgColor:"#ffffff"})})]})]})]}),e.jsxs("div",{className:(_r=t==null?void 0:t.gallery)!=null&&_r.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Er=t==null?void 0:t.gallery)==null?void 0:Er.visibility,title:"Gallery",componentName:"gallery",showHideHandler:x,id:(Mr=t==null?void 0:t.gallery)==null?void 0:Mr.id}),((Ir=t==null?void 0:t.gallery)==null?void 0:Ir.visibility)&&e.jsxs(Br,{children:[e.jsx("div",{className:"text-center mb-5",style:{marginTop:"100px"},children:e.jsx("span",{className:"fs-1 px-4 py-2",style:{borderBottom:"1px solid #444444"},children:"View Gallery"})})," ",e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"breiftopMargin",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("weserve",!0)}),e.jsx(be,{introState:O.weserve,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"text-center mb-3",introSubTitleCss:"fw-medium fs-5 text-center",introDecTitleCss:"fs-6 fw-normal mx-4 text-center lh-6",detailsContainerCss:"col-md-12 py-2 text-center",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:m})]})})}),O.weserve&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(we,{editHandler:r,componentType:"weserve",popupTitle:"Brief Intro Banner",pageType:"Home"})})]}),e.jsx("div",{className:"container",children:e.jsx("div",{className:"row ",children:e.jsx("div",{className:"col-md-10 offset-md-1 homeGalleryCarousel",children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-10 offset-md-1",children:e.jsx(Ze,{carouselState:O.carousel,category:"industriesweserve",containerId:"imageGallerycarousel"})})})})})})}),e.jsx("div",{className:"text-center py-4 position-relative ",style:{marginTop:"200px"},children:e.jsx(fe,{to:"/imageGallery",className:"btn btn-outline",children:"View All"})})]})]}),e.jsxs("div",{className:(Lr=t==null?void 0:t.servicesoffered)!=null&&Lr.visibility&&C&&f?"border border-info mb-2":"",children:[C&&f&&e.jsx(ie,{showhideStatus:(Rr=t==null?void 0:t.servicesoffered)==null?void 0:Rr.visibility,title:"Services Offered",componentName:"servicesoffered",showHideHandler:x,id:(Dr=t==null?void 0:t.servicesoffered)==null?void 0:Dr.id}),((Ar=t==null?void 0:t.servicesoffered)==null?void 0:Ar.visibility)&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"text-center mb-5",style:{marginTop:"100px"},children:e.jsx("span",{className:"fs-1 px-4 py-2",style:{borderBottom:"1px solid #444444"},children:"Services Offered"})}),e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12 carousel",children:[C&&f&&e.jsx(ce,{editHandler:()=>r("serviceOffered",!0),editlabel:""}),e.jsx(pi,{getBannerAPIURL:`carousel/clientCarouselbyCategory/${v}/`,componentEdit:O})]})}),O.serviceOffered&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(ze,{editHandler:r,componentType:"serviceOffered",getImageListURL:`carousel/getCarousel/${v}/`,deleteImageURL:"carousel/updateCarousel/",imagePostURL:"carousel/createCarousel/",imageUpdateURL:"carousel/updateCarousel/",imageIndexURL:"carousel/updateCarouselindex/",imageLabel:"Add Images",showDescription:!1,showExtraFormFields:Qn(v),dimensions:ge("carousel")})})]})]}),Z&&e.jsx(pt,{})]})})};export{Ga as default};
