import{e as i}from"./index-KkEaZk_x.js";const a=i.div`
  .caseStudie {
    .row {
      border-bottom: 1px solid ${({theme:t})=>t.lightgray};
    }

    .caseStudieImg {
      max-width: 150px;
      max-height: 150px;
      width: 100%;
    }
  }

  .caseStudieDetails img {
    max-width: 150px;
    max-height: 150px;
    width: 100%;
  }

  .caseStudieDetails ul {
    margin: 25px;
    padding: 0;
  }
`;export{a as C};
