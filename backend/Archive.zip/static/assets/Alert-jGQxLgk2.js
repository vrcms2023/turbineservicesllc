import{j as s}from"./index-KkEaZk_x.js";const o=({mesg:r,cssClass:e})=>s.jsx("div",{className:e,role:"alert",children:r});export{o as A};
