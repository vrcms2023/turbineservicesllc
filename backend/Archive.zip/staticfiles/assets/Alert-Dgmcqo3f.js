import{j as s}from"./index-BT6f_GGI.js";const o=({mesg:r,cssClass:e})=>s.jsx("div",{className:e,role:"alert",children:r});export{o as A};
