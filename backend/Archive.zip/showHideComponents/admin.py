from django.contrib import admin
from  .models import *

# Register your models here.

@admin.register(ShowHideComponents)
class ShowHideComponentAdmin(admin.ModelAdmin):
    list_display = ("pageType","componentName", "visibility")