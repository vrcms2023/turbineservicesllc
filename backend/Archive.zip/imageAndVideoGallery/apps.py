from django.apps import AppConfig


class ImageandvideogalleryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'imageAndVideoGallery'
