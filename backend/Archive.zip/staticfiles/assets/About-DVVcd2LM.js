import{k as P,A as R,e as _,r as a,f as H,O as M,a as O,b as q,V,j as e,E as x,L as z,T,R as G,d as J,M as K,Q,S as W,w as X,y as Y}from"./index-dvRA20TS.js";import{l as Z}from"./DeleteDialog-B3rnC39V.js";import{g as ee,B as te,a as se}from"./index-BJabk3QN.js";import{B as oe,I as ae}from"./index-bJlCmucT.js";import{D as ie}from"./DeleteDialog-NVLa3HvG.js";import{N as ne}from"./index-B43DMKSO.js";import{i as E,g as re,e as de}from"./dynamicFormFields-p6VsA-z_.js";import{S as le}from"./ShowHideToggle-C5E19BrT.js";import"./Ancher-BEz7zO_d.js";import"./FileUpload-BNCF8m7-.js";import"./Error-CiqJ0Z1P.js";import"./SkeletonImage-yh71_0Rf.js";const ce=P.div`
  .title {
    color: ${({theme:s})=>s.textColor};
    font-weight: 600 !important;
  }

  .subTitle {

  }
  .aboutPage {

    padding-bottom: 24px;

    .row {
      border-bottom: 2px solid ${({theme:s})=>s.white};

      &:last-child {
        border-bottom: 0 !important;
      }
    }
    
    .quill {
      background: none;
    }
    .ql-editor {
      padding-left: 0;
      padding-right: 0;
    }

    p {
      line-height: 1.6;
      margin-bottom: 12px
    }
      
    }
    
    .leftColumn {
      background-color: ${({theme:s})=>s.transparent};
    }
    .rightColumn {
      background-color: ${({theme:s})=>s.transparent};

      img {
        position: relative;
        transition: opacity 0.5s ease, transform 0.5s ease, border-radius 0.5s ease;
        border-radius: 8px;
        
      
        &:hover {
          &::before {
            content: 'Leon Phrama';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            box-shadow: inset 0 0 30px 10px rgba(255, 255, 255, 0.5); /* Adjust the shadow color and size as needed */
            border-radius: inherit;
          }
      
          // transform: scale(1.1) rotate(-0deg);
          // border-radius: 5%; /* Change the border-radius to 50% for a circle */
        }
      }
    }

    ul, ol {
      padding: 0;
      margin: 0px 0 24px;
      list-style: none;

      li {
        // background-color: ${({theme:s})=>s.verylightgray};
        border-bottom: 1px solid ${({theme:s})=>s.lightgray};
        padding: 10px;

        @media(max-width: 768px) {
          padding: 10px 0;
        }
        
      }

      li:first-child {
        // border-top-left-radius: 5px;
        // border-top-right-radius: 5px;
      }

      li:last-child {
        border: 0;
        // border-bottom-left-radius: 5px;
        // border-bottom-right-radius: 5px;
      }
    }

    hr:last-child {
      display: none;
    }

    .normalCSS,
      .flipCSS {
      }
      
      .flipCSS {
        flex-direction: row-reverse;
        background: #fbfbfb;
        padding: 24px 10px;
        margin-top: 32px;
        margin-bottom: 32px;

        @media (max-width: 768px) {
          padding: 0;
          margin: 0px;

        }
      }
`,Ae=()=>{var w,C,v,A;const s={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},p=R(),c="aboutus",{isAdmin:d,hasPermission:u}=_(),[i,I]=a.useState(s),[f,h]=a.useState([]),[S,B]=a.useState(!1),[$,b]=a.useState({}),[o,k]=a.useState([]),j=a.useRef(!0),{error:ue,success:me,showHideList:m}=H(t=>t.showHide);a.useEffect(()=>{m.length>0&&k(ee(m))},[m]),a.useEffect(()=>{m.length===0&&j.current&&(p(M()),j.current=!1)},[m]);const L=async(t,n)=>{if(t)p(Q(t));else{const r={componentName:n.toLowerCase(),pageType:c};p(W(r))}};a.useEffect(()=>{window.scrollTo(0,0)},[]),a.useEffect(()=>{O()},[]),a.useEffect(()=>{y()},[]);const l=(t,n,r)=>{I(g=>({...g,[t]:n})),B(!S),r!=null&&r.id?b(r):b({}),document.body.style.overflow="hidden"},y=async t=>{try{let n=await q.get("aboutus/clientAboutus/"),r=V(n.data.aboutus);h(r)}catch{console.log("Unable to get the intro")}};a.useEffect(()=>{!i.editSection&&!i.addSection&&(y(),b({}))},[i.editSection,i.addSection]);const D=t=>{const n=t.id,r=t.aboutus_title,g=async()=>{if((await X.delete(`/aboutus/updateAboutus/${n}/`)).status===204){const F=f.filter(U=>U.id!==n);h(F),Y.success(`${r} is deleted`)}};Z.confirmAlert({customUI:({onClose:N})=>e.jsx(ie,{onClose:N,callback:g,message:`deleting the ${r} Service?`})})};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[d&&u&&e.jsx(x,{editHandler:()=>l("banner",!0)}),e.jsx(oe,{getBannerAPIURL:`banner/clientBannerIntro/${c}-banner/`,bannerState:i.banner})]}),i.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ae,{editHandler:l,componentType:"banner",popupTitle:"About Banner",pageType:`${c}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:re(`${c}-banner`),dimensions:E("banner")})}),e.jsxs("div",{className:(w=o==null?void 0:o.aboutbriefintro)!=null&&w.visibility&&d&&u?"border border-info mb-2":"",children:[d&&u&&e.jsx(le,{showhideStatus:(C=o==null?void 0:o.aboutbriefintro)==null?void 0:C.visibility,title:"A Brief Introduction Component",componentName:"aboutbriefintro",showHideHandler:L,id:(v=o==null?void 0:o.aboutbriefintro)==null?void 0:v.id}),((A=o==null?void 0:o.aboutbriefintro)==null?void 0:A.visibility)&&e.jsxs("div",{className:"breiftopMargin",children:[d&&u&&e.jsx(x,{editHandler:()=>l("briefIntro",!0)}),e.jsx(te,{introState:i.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center",detailsContainerCss:"col-md-10 offset-md-1 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:c}),i.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(se,{editHandler:l,componentType:"briefIntro",popupTitle:"About Brief Intro",pageType:c})})]})]}),e.jsx(ce,{children:e.jsxs("div",{className:"container-fluid container-lg ",children:[e.jsx("div",{className:"row my-3 d-flex align-items-center",children:d&&u&&e.jsxs("div",{className:"col-12 text-end",children:[e.jsx("span",{className:"d-inline-block me-2",children:"Add content"}),e.jsx("button",{type:"submit",className:"btn btn-primary ",onClick:()=>l("addSection",!0),children:e.jsx("i",{className:"fa fa-plus","aria-hidden":"true"})})]})}),i.editSection||i.addSection?e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ne,{editHandler:l,category:"about",popupTitle:"About",editCarousel:$,setEditCarousel:b,componentType:`${i.editSection?"editSection":"addSection"}`,imageGetURL:"aboutus/clientAboutus/",imagePostURL:"aboutus/createAboutus/",imageUpdateURL:"aboutus/updateAboutus/",imageDeleteURL:"aboutus/updateAboutus/",imageLabel:"Add About us Banner",showDescription:!1,showExtraFormFields:de(),dimensions:E("aboutus")})}):"",e.jsx("div",{className:"aboutPage",children:f.length>0?f.map((t,n)=>e.jsxs("div",{className:`row ${d?"border border-warning mb-4 position-relative":""} ${n%2===0?"normalCSS":"flipCSS"}`,children:[d&&u&&e.jsxs(e.Fragment,{children:[e.jsx(x,{editHandler:()=>l("editSection",!0,t)}),e.jsx(z,{className:"deleteSection",onClick:()=>D(t),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"col-12 col-lg-7 p-4 py-0 p-md-4 d-flex justify-content-center align-items-start flex-column leftColumn",children:[t.aboutus_title?e.jsx(T,{title:t.aboutus_title,cssClass:"",mainTitleClassess:"fs-3 mb-2 title",subTitleClassess:""}):"",t.aboutus_sub_title?e.jsx(T,{title:t.aboutus_sub_title,cssClass:"",mainTitleClassess:"fs-6 text-secondary mb-2 subTitle",subTitleClassess:""}):"",e.jsx(G,{data:t==null?void 0:t.aboutus_description,className:""})]}),e.jsx("div",{className:"col-lg-5 p-4 p-md-0 d-flex justify-content-center align-items-start flex-column rightColumn",children:e.jsx("img",{src:J(t.path),alt:"",className:"w-75 object-fit-cover shadow m-auto"})})]},t.id)):e.jsx("p",{className:"text-center text-muted py-5",children:"Please add page contents..."})})]})}),S&&e.jsx(K,{})]})};export{Ae as default};
