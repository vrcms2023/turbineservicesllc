import{r,u as w,j as e,T as m,L as F,p as B,b as k,aE as P,e as T,B as _,ak as A,a as O,v as R,c as $,_ as D,E as L,I as H,d as M,R as U,M as z,a6 as G,a7 as J}from"./index-KkEaZk_x.js";import{B as K}from"./index-D-Sl_dAm.js";import{C as V}from"./Styled-CareerFilter-BUyX90xr.js";import{S as q}from"./ShowHideToggle-DRXWoIR0.js";import"./Styled-PageBanner-BV1wktGo.js";const Q=()=>{const[s,o]=r.useState([]),{isAdmin:i}=w();return r.useEffect(()=>{(async()=>{try{let t="";i?t=await B.get("/careers/createCareer/"):t=await k.get("/careers/clientCareersList/"),Object.keys(t.data).length>1?o(t.data.results):o(t.data.careers)}catch{console.log("Unable to get the Career data")}})()},[i]),e.jsxs("div",{className:"py-4 px-3 currentOpenings",children:[e.jsx(m,{title:"CURRENT OPENINGS",cssClass:"mb-3 fs-5 title"}),e.jsx("ul",{children:s.map(l=>e.jsx("li",{className:"",children:e.jsx(F,{to:`/career-details/${l.id}/`,children:l.job_title})},l.id))})]})},W=({jobDetails:s})=>e.jsxs("div",{className:"jobBriefDetails",children:[e.jsxs("div",{className:"d-flex justify-content-start align-items-center gap-3",children:[e.jsx(m,{title:s.job_title?s.job_title:"Default Career",cssClass:""}),e.jsxs("small",{className:"d-block mb-1 text-muted",children:["[ ",s.job_location?s.job_location:"Default Career"," ]"]})]}),e.jsxs("span",{className:"d-block mb-1",children:[e.jsx(e.Fragment,{children:"Experience"})," : Minimum"," ",s.experience_from?s.experience_from:0," to"," ",s.experience_to?s.experience_to:0," years+"]}),e.jsxs("span",{className:"d-block",children:[e.jsx(e.Fragment,{children:"Education"})," :"," ",s.education?s.education:"Default Career"]}),e.jsx("div",{className:"d-flex justify-content-between align-items-start align-items-lg-center flex-column flex-lg-row py-2",children:e.jsxs("div",{className:"d-flex flex-column flex-md-row justify-content-between align-items-start gap-3",children:[e.jsxs("div",{className:"d-flex gap-2 justify-content-center align-items-start",children:[e.jsx("strong",{children:"Posted "}),e.jsxs("span",{children:[P(s.posted_date)," days ago"]})]}),e.jsxs("div",{className:"d-flex gap-2 justify-content-center align-items-start",children:[e.jsx("strong",{children:"Openings"}),s.openings?s.openings:0]})]})})]}),X=T.div`
    border: 1px solid ${({theme:s})=>s.verylightgray};
    padding: 1rem .3rem;

    .careers-or-text {
        padding: 20px 0 15px;
        position: relative;
        text-align: center;
    } 
    .careers-or-text:before, .careers-or-text:after {
        content: '';
        position: absolute;
        background-color: #6d6e7224;
        height: 1px;
        width: 40%;
        top: 32px;
    }

    .careers-or-text:before {
        right: 0;
    }

    .careers-or-text:after {
        left: 0;
    }   

    .careers-or-text label {
        margin-bottom: 0;
        padding: 0 5px;
        display: inline-block;
    }

    input, select, textarea {
        border: 1px solid  ${({theme:s})=>s.verylightgray} !important;
        border-radius: 4px !important;
        font-size: .8rem !important;
    }

    input[type="checkbox"] {
        border: 1px solid  ${({theme:s})=>s.grayddd} !important;
        border-radius: 0px !important;
    }

    label {
        font-size: .9rem  !important;
    }
    
`,Y=()=>e.jsx(X,{children:e.jsx("div",{className:"container",children:e.jsx("div",{className:"row",children:e.jsxs("div",{className:"col-md-12",children:[e.jsx(m,{title:"Apply Now",cssClass:"fs-5 fw-medium text-center"}),e.jsx("hr",{}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"First Name *"}),e.jsx("input",{type:"text",className:"form-control",id:"exampleFormControlInput1",placeholder:"First Name"})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"Last Name *"}),e.jsx("input",{type:"text",className:"form-control",id:"exampleFormControlInput1",placeholder:"Last Name"})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"Email *"}),e.jsx("input",{type:"email",className:"form-control",id:"exampleFormControlInput1",placeholder:"Email"})]}),e.jsxs("div",{className:"mb-3 border border-1 p-2",children:[e.jsx("label",{for:"formFile",className:"form-label",children:"Upload Resume / Share LinkedIn Profile *"}),e.jsx("input",{className:"form-control",type:"file",id:"formFile"}),e.jsx("small",{className:"my-2 d-block",children:"Only .docx, .rtf, .pdf formats allowed to a max size of 5 MB."}),e.jsx("div",{className:"text-muted text-center careers-or-text",children:e.jsx("label",{children:" OR "})}),e.jsxs("div",{className:"linkedInProfile mt-4",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"Linked In Profile"}),e.jsx("input",{type:"text",className:"form-control",id:"exampleFormControlInput1"})]})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"Phone"}),e.jsx("input",{type:"number",className:"form-control",id:"exampleFormControlInput1",placeholder:"Phone Number"})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"Country *"}),e.jsxs("select",{className:"form-select","aria-label":"Default select example",children:[e.jsx("option",{value:"",children:"Select Country"}),e.jsx("option",{value:"kakinada",children:"   Kakinada"}),e.jsx("option",{value:"visakhapatnam",children:"   Visakhapatnam"}),e.jsx("option",{value:"hyderabad",children:"   Hyderabad"}),e.jsx("option",{value:"bangalore",children:"   Bangalore"}),e.jsx("option",{value:"chennai",children:"   Chennai"}),e.jsx("option",{value:"gurgaon",children:"   Gurgaon"}),e.jsx("option",{value:"nagpur",children:"   Nagpur"}),e.jsx("option",{value:"new-delhi",children:"   New Delhi"}),e.jsx("option",{value:"noida",children:"   Noida"}),e.jsx("option",{value:"pune",children:"   Pune"})]})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlInput1",className:"form-label",children:"City"}),e.jsx("input",{type:"text",className:"form-control",id:"exampleFormControlInput1",placeholder:"name@example.com"})]}),e.jsxs("div",{className:"mb-3",children:[e.jsx("label",{for:"exampleFormControlTextarea1",className:"form-label",children:"How did you hear about this job?"}),e.jsx("textarea",{className:"form-control",id:"exampleFormControlTextarea1",rows:"3"})]}),e.jsx("div",{className:" d-flex justify-content-center align-items-center",children:e.jsx(_,{label:"Apply",cssClass:"btn btn-primary"})})]})})})}),ne=()=>{var g,y,v,C;const s={banner:!1,briefIntro:!1,about:!1,vision:!1,mission:!1},o="career-details",{isAdmin:i,hasPermission:l}=w(),[t,h]=r.useState(s),[f,I]=r.useState(!1),[x,u]=r.useState({});let{id:j}=A();r.useEffect(()=>{window.scrollTo(0,0)},[]),r.useEffect(()=>{O()},[]),r.useEffect(()=>{(async()=>{try{let n=await k.get(`/careers/clientSelectedCareers/${j}/`);Object.keys(n.data).length>1?u(n.data.results):u(n.data.careers)}catch{console.log("Unable to get the Career data")}})()},[j,i]);const b=(c,n)=>{h(d=>({...d,[c]:n})),I(!f),document.body.style.overflow="hidden"},[a,S]=r.useState([]),N=R(),{error:Z,success:ee,showHideList:p}=$(c=>c.showHide);r.useEffect(()=>{p.length>0&&S(D(p))},[p]);const E=async(c,n)=>{if(c)N(G(c));else{const d={componentName:n.toLowerCase(),pageType:o};N(J(d))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(g=a==null?void 0:a.careerdetailsbanner)!=null&&g.visibility&&i&&l?"border border-info mb-2":"",children:[i&&l&&e.jsx(q,{showhideStatus:(y=a==null?void 0:a.careerdetailsbanner)==null?void 0:y.visibility,title:"Banner",componentName:"careerdetailsbanner",showHideHandler:E,id:(v=a==null?void 0:a.careerdetailsbanner)==null?void 0:v.id}),((C=a==null?void 0:a.careerdetailsbanner)==null?void 0:C.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[i&&l&&e.jsx(L,{editHandler:()=>b("banner",!0)}),e.jsx(K,{getBannerAPIURL:`banner/clientBannerIntro/${o}-banner/`,bannerState:t.banner})]}),t.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(H,{editHandler:b,componentType:"banner",popupTitle:"Career Details Banner",pageType:`${o}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:M(`${o}-banner`)})})]})]}),e.jsx("div",{className:"container mb-3",children:e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-8 col-md-10",children:e.jsx(m,{title:"Details",cssClass:"fw-medium fs-4 pageTitle "})}),e.jsx("div",{className:"col-4 col-md-2 text-end",children:e.jsxs(F,{to:"/careers",className:"btn btn-primary",children:[e.jsx("i",{className:"fa fa-chevron-left me-2","aria-hidden":"true"}),e.jsx("span",{className:"",children:"Back"})]})})]})}),e.jsx(V,{children:e.jsx("div",{className:"container py-4 mb-md-5 py-md-4",children:e.jsxs("div",{className:"row d-flex flex-rowreverse",children:[e.jsxs("div",{className:"col-md-9 p-0",children:[e.jsx(W,{jobDetails:x}),e.jsx("div",{className:"jobDescription mb-4",children:x.description&&e.jsx(U,{data:x.description,className:"",showMorelink:!1})}),e.jsx(Q,{})]}),e.jsx("div",{className:"col-md-3 pe-0",children:e.jsx(Y,{})})]})})}),f&&e.jsx(z,{})]})};export{ne as default};
