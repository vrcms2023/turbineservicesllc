import{e as q,v as O,u as z,r,c as G,_ as J,a as K,b as V,a9 as W,j as e,E as f,I as Q,a0 as k,d as X,C as Y,D as Z,aa as H,L as ee,T as $,R as te,g as se,M as ae,a6 as ne,a7 as ie,W as oe,p as re,y as le}from"./index-KkEaZk_x.js";import{B as de}from"./index-D-Sl_dAm.js";import{D as ce}from"./DeleteDialog-Bx6G4tYg.js";import{N as ue}from"./index-DivwJYVl.js";import{S as D}from"./ShowHideToggle-DRXWoIR0.js";import"./Styled-PageBanner-BV1wktGo.js";const be=q.div`
  .title {
    color: ${({theme:a})=>a.textColor};
    font-weight: 600 !important;
  }

  .subTitle { }

  .aboutPage {
      padding-bottom: 80px;

      .row {
        border-bottom: 1px solid ${({theme:a})=>a.grayddd};
        // box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15);
        // box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075);
        // &:last-child {
        //   border-bottom: 0 !important;
        // }
      }
      
      .quill {
        background: none;
      }
      .ql-editor {
        padding-left: 0;
        padding-right: 0;
      }

      p {
        line-height: 1.6;
        margin-bottom: 12px
      }
      
    }
    
    .leftColumn {
      background-color: ${({theme:a})=>a.transparent};
    }
    .rightColumn {
      background-color: ${({theme:a})=>a.transparent};

      img {
        position: relative;
        transition: opacity 0.5s ease, transform 0.5s ease, border-radius 0.5s ease;
        // border-radius: 8px;
        max-width: auto;
        width: 100%;
        max-height: 280px;
        
      
        &:hover {
          &::before {
            content: 'Leon Phrama';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            box-shadow: inset 0 0 30px 10px rgba(255, 255, 255, 0.5); /* Adjust the shadow color and size as needed */
            border-radius: inherit;
          }
      
          // transform: scale(1.1) rotate(-0deg);
          // border-radius: 5%; /* Change the border-radius to 50% for a circle */
        }
      }
    }

    ul, ol {
      padding: 0;
      margin: 0px 0 24px;
      list-style: none;

      li {
        // background-color: ${({theme:a})=>a.verylightgray};
        border-bottom: 1px solid ${({theme:a})=>a.lightgray};
        padding: 10px;

        @media(max-width: 768px) {
          padding: 10px 0;
        }
        
      }

      li:first-child {
        // border-top-left-radius: 5px;
        // border-top-right-radius: 5px;
      }

      li:last-child {
        // border: 0;
        // border-bottom-left-radius: 5px;
        // border-bottom-right-radius: 5px;
      }
    }

    hr:last-child {
      display: none;
    }

    .normalCSS, .flipCSS {
      // padding: 24px 10px;
      margin-top: 80px;
    }
      
    .flipCSS {
      flex-direction: row-reverse;
      background: #fbfbfb;
      // margin-bottom: 48px;

      @media (max-width: 768px) {
        padding: 0;
        margin: 0px;
      }
    }
`,ye=()=>{var v,w,A,N,C,T,E,I;const a={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},g=O(),u="aboutus",{isAdmin:l,hasPermission:d}=z(),[n,F]=r.useState(a),[m,h]=r.useState([]),[j,U]=r.useState(!1),[P,b]=r.useState({}),[t,R]=r.useState([]),{error:me,success:pe,showHideList:p}=G(s=>s.showHide);r.useEffect(()=>{p.length>0&&R(J(p))},[p]);const S=async(s,i)=>{if(s)g(ne(s));else{const o={componentName:i.toLowerCase(),pageType:u};g(ie(o))}};r.useEffect(()=>{window.scrollTo(0,0)},[]),r.useEffect(()=>{K()},[]),r.useEffect(()=>{y()},[]);const c=(s,i,o)=>{F(x=>({...x,[s]:i})),U(!j),o!=null&&o.id?b(o):b({}),document.body.style.overflow="hidden"},y=async s=>{try{let i=await V.get("aboutus/clientAboutus/"),o=W(i.data.aboutus);h(o)}catch{console.log("Unable to get the intro")}};r.useEffect(()=>{!n.editSection&&!n.addSection&&(y(),b({}))},[n.editSection,n.addSection]);const _=s=>{const i=s.id,o=s.aboutus_title,x=async()=>{if((await re.delete(`/aboutus/updateAboutus/${i}/`)).status===204){const M=m.filter(L=>L.id!==i);h(M),le.success(`${o} is deleted`)}};oe.confirmAlert({customUI:({onClose:B})=>e.jsx(ce,{onClose:B,callback:x,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:o})," service?"]})})})};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(v=t==null?void 0:t.aboutbanner)!=null&&v.visibility&&l&&d?"border border-info mb-2":"",children:[l&&d&&e.jsx(D,{showhideStatus:(w=t==null?void 0:t.aboutbanner)==null?void 0:w.visibility,title:"Banner",componentName:"aboutbanner",showHideHandler:S,id:(A=t==null?void 0:t.aboutbanner)==null?void 0:A.id}),((N=t==null?void 0:t.aboutbanner)==null?void 0:N.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[l&&d&&e.jsx(f,{editHandler:()=>c("banner",!0),editlabel:"Brief"}),e.jsx(de,{getBannerAPIURL:`banner/clientBannerIntro/${u}-banner/`,bannerState:n.banner})]}),n.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Q,{editHandler:c,componentType:"banner",popupTitle:"About Banner",pageType:`${u}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:X(`${u}-banner`),dimensions:k("banner")})})]})]}),e.jsxs("div",{className:(C=t==null?void 0:t.aboutbriefintro)!=null&&C.visibility&&l&&d?"border border-info mb-2":"",children:[l&&d&&e.jsx(D,{showhideStatus:(T=t==null?void 0:t.aboutbriefintro)==null?void 0:T.visibility,title:"A Brief Introduction Component",componentName:"aboutbriefintro",showHideHandler:S,id:(E=t==null?void 0:t.aboutbriefintro)==null?void 0:E.id}),((I=t==null?void 0:t.aboutbriefintro)==null?void 0:I.visibility)&&e.jsxs("div",{className:"breiftopMargin",children:[l&&d&&e.jsx(f,{editHandler:()=>c("briefIntro",!0)}),e.jsx(Y,{introState:n.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center gap-3",linkLabel:"Read More",moreLink:"",introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center",detailsContainerCss:"col-md-10 offset-md-1 py-3",anchorContainer:"d-flex justify-content-center align-items-center mt-4",anchersvgColor:"#17427C",pageType:u}),n.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(Z,{editHandler:c,componentType:"briefIntro",popupTitle:"About Brief Intro",pageType:u})})]})]}),e.jsx(be,{children:e.jsxs("div",{className:"container-fluid container-lg ",children:[e.jsx("div",{className:"row my-3 d-flex align-items-center",children:l&&d&&e.jsxs("div",{className:"col-12 text-end",children:[e.jsx("span",{className:"d-inline-block me-2",children:"Add content"}),e.jsx("button",{type:"submit",className:"btn btn-primary ",onClick:()=>c("addSection",!0),children:e.jsx("i",{className:"fa fa-plus","aria-hidden":"true"})})]})}),n.editSection||n.addSection?e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ue,{editHandler:c,category:"about",popupTitle:"About",editCarousel:P,setEditCarousel:b,componentType:`${n.editSection?"editSection":"addSection"}`,imageGetURL:"aboutus/clientAboutus/",imagePostURL:"aboutus/createAboutus/",imageUpdateURL:"aboutus/updateAboutus/",imageDeleteURL:"aboutus/updateAboutus/",imageLabel:"Add About us Banner",showDescription:!1,showExtraFormFields:H(),dimensions:k("aboutus")})}):"",e.jsx("div",{className:"aboutPage",children:m.length>0?m.map((s,i)=>e.jsxs("div",{className:`row ${l?"border border-warning mb-4 position-relative":""} ${i%2===0?"normalCSS":"flipCSS"}`,children:[l&&d&&e.jsxs(e.Fragment,{children:[e.jsx(f,{editHandler:()=>c("editSection",!0,s)}),e.jsx(ee,{className:"deleteSection",onClick:()=>_(s),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:"col-12 col-lg-7 p-5 d-flex justify-content-center align-items-start flex-column leftColumn",children:[s.aboutus_title?e.jsx($,{title:s.aboutus_title,cssClass:"",mainTitleClassess:"fs-3 mb-2 title",subTitleClassess:""}):"",s.aboutus_sub_title?e.jsx($,{title:s.aboutus_sub_title,cssClass:"",mainTitleClassess:"fs-6 text-secondary mb-2 subTitle",subTitleClassess:""}):"",e.jsx(te,{data:s==null?void 0:s.aboutus_description,className:"",showMorelink:!1})]}),e.jsx("div",{className:"col-lg-5 p-4 p-md-0 d-flex justify-content-center align-items-start flex-column rightColumn",children:e.jsx("img",{src:se(s.path),alt:"",className:"object-fit-cover shadow m-auto"})})]},s.id)):e.jsx("p",{className:"text-center text-muted py-5",children:"Please add page contents..."})})]})}),j&&e.jsx(ae,{})]})};export{ye as default};
