import{j as e}from"./index-DBsTX-kM.js";const s=({children:r,...t})=>e.jsx("div",{style:{color:"#f23838",textAlign:"center",margin:"0.5rem 0"},...t,children:r});export{s as E};
