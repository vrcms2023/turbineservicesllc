import{r as i,W as Y,j as e,t as Z,a8 as q,a9 as S,l as v,n as w,Y as J,Z as Q,e as T,d as V,x as X,aa as k,ab as ee,L as I,w as se,k as ae}from"./index-dvRA20TS.js";import{l as te}from"./DeleteDialog-B3rnC39V.js";import{F as re}from"./FileUpload-BNCF8m7-.js";import{D as le}from"./DeleteDialog-NVLa3HvG.js";import{D as oe,C as ie,P as ne}from"./dnd.esm-Dpsc6iV4.js";import{N as ce}from"./NoteComponent-tKHG7Bvb.js";const je=({editHandler:a,componentType:c,popupTitle:d,getImageListURL:m,deleteImageURL:x,imagePostURL:f,imageUpdateURL:g,imageIndexURL:u,imageLabel:C="Add Images",extraFormParamas:A,titleTitle:E="Title",descriptionTitle:_="Description",showDescription:O,showExtraFormFields:P,dimensions:$,validTypes:F="image/png,image/jpeg"})=>{const G="a62d7759-a e6b-4e49-a129-1ee208c6789d",[L,B]=i.useState(""),[h,D]=i.useState([]),[ge,K]=i.useState(!1),[r,b]=i.useState([]),[H,me]=i.useState({id:G}),[U,j]=i.useState({}),N=()=>{a(c,!1),document.body.style.overflow=""};i.useEffect(()=>{B(Y("userName"))},[]),i.useEffect(()=>{(async()=>{try{const s=await S.get(m);if((s==null?void 0:s.status)===200){let t=Object.keys(s.data);if(t.length>1){const o=v(s.data.results[0]),n=w(s.data.results,o);b(n)}else{const o=v(s.data[t][0]),n=w(s.data[t],o);b(n)}}}catch{console.log("unable to access ulr because of server is down")}})()},[h,m]);const R=(l,s)=>{l.preventDefault(),window.scrollTo(0,0),j(s)},z=(l,s)=>{const t=async()=>{if((await S.delete(`${x}${l}/`)).status===204){const n=h.filter(y=>y.id!==l);D(n),j({})}};te.confirmAlert({customUI:({onClose:o})=>e.jsx(le,{onClose:o,callback:t,message:`deleting the ${s} image?`})})},M=async l=>{const{source:s,destination:t}=l;if(!t)return!0;const o=v(r[0]),n=J(r,s.index,t.index),y=Q(n,o),p=await W(y);(p==null?void 0:p.length)>0&&b(p)},W=async l=>{try{let s=await se.put(u,l),t=Object.keys(s==null?void 0:s.data);if(t.length>0)return s.data[t]}catch{console.log("unable to save clinet position")}};return e.jsxs("div",{children:[e.jsx(Z,{closeHandler:N,title:d}),e.jsx("hr",{className:"m-0"}),e.jsxs("div",{className:"container mt-2",children:[e.jsx(ce,{note:"Drag to shuffle banners"}),e.jsxs("div",{className:"row mt-2 d-flex flex-row-reverse",children:[(r==null?void 0:r.length)>0?e.jsx("div",{className:"heightCtrl imglist",children:e.jsx("div",{className:"container",children:e.jsx(oe,{onDragEnd:M,children:r==null?void 0:r.map((l,s)=>e.jsx(ie,{droppableId:l.id,children:(t,o)=>e.jsxs("div",{ref:t.innerRef,style:q(o.isDraggingOver),...t.droppableProps,children:[e.jsx(de,{item:l,index:s,componentType:c,handleCarouselEdit:R,thumbDelete:z},s),t.placeholder]})},s))})})}):"",e.jsx("hr",{className:""}),e.jsx("div",{className:`mb-5 mb-md-0 px-0 ${(r==null?void 0:r.length)>0,"col-md-12"}`,children:e.jsx(re,{title:C,project:H,updated_by:L,category:c,gallerysetState:D,maxFiles:1,galleryState:h,validTypes:F,descriptionTitle:_,titleTitle:E,alternitivetextTitle:"Seo title",saveState:K,showDescription:O,buttonLable:"Save",editImage:U,setEditCarousel:j,imagePostURL:f,imageUpdateURL:g,extraFormParamas:A,showExtraFormFields:P,dimensions:$,closeHandler:N,scrollEnable:r.lengh>0})})]})]})]})},de=({item:a,index:c,componentType:d,handleCarouselEdit:m,thumbDelete:x})=>{const{isAdmin:f}=T();return e.jsx(ne,{isDragDisabled:!f,draggableId:a.id,index:c,id:a.id,children:g=>e.jsx("div",{ref:g.innerRef,...g.draggableProps,...g.dragHandleProps,children:e.jsxs("div",{className:"row mb-2 p-2 slideItem",children:[e.jsxs("div",{className:"col-2 col-md-2",children:[e.jsx("i",{className:"fa fa-picture-o fs-2 d-lg-none","aria-hidden":"true"}),e.jsx("img",{src:a.path?V(a.path):X(),alt:a.alternitivetext,className:"w-100 d-none d-lg-block"})]}),e.jsxs("div",{className:"col col-md-8 ",children:[e.jsx("h6",{className:"fw-bold m-0 fs-6",children:k(d,a)}),e.jsxs("small",{className:"description text-muted d-none d-md-block",children:[ee(d,a),a.carouseDescription&&a.carouseDescription,a.image_description&&a.image_description]})]}),e.jsxs("div",{className:"col-4 col-md-2 d-flex justify-content-around align-items-center flex-md-row gap-3",children:[e.jsx(I,{onClick:u=>m(u,a),children:e.jsx("i",{className:"fa fa-pencil fs-5 text-warning","aria-hidden":"true"})}),e.jsx(I,{onClick:u=>x(a.id,k(d,a)),children:e.jsx("i",{className:"fa fa-trash fs-5 text-danger","aria-hidden":"true"})})]})]},c)})},a.id)},ye=ae.div`

  .gallery img {
    cursor: pointer;
    border: 3px solid ${({theme:a})=>a.gray};
    border-radius: 15px;
    height: 200px;
    filter: gray; /* IE6-9 */
  -webkit-filter: grayscale(1); /* Google Chrome, Safari 6+ & Opera 15+ */
  filter: grayscale(1); /* Microsoft Edge and Firefox 35+ */
  transition: filter 0.3s ease-in-out;
  object-fit: cover;

    &:hover {
        -webkit-filter: grayscale(0);
        filter: none;
        border: 3px solid ${({theme:a})=>a.black};
    }
  }

  .homeGalleryCarousel {
    background: ${({theme:a})=>a.black};
    border-radius: 30px;
    height: 350px;

    .container {
        margin-top: 130px;
    }

    .carousel-item, carousel-inner {
        border-radius: 30px;
    }
    .carousel-item img {
        height: 400px !important;
        border-radius: 30px;
    }

    .carousel-control-prev, .carousel-control-next {
        right: -14%;
        top: -40%;
    }

    .carousel-control-prev {
        left: -14%;
    }

    .carousel-control-prev span, .carousel-control-next span {
        border: 2px solid #fff;
        border-radius: 50px;
        background-size: 20px;
    }
  }

  .viewAllBtn {
    margin-top: 170px
  }

    
`;export{je as A,ye as I};
