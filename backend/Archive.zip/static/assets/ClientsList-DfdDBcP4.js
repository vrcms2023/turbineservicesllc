import{e as Z,c as G,r,j as e,S as ee,M as te,U as ne,V as ie,u as J,E as A,L as se,g as ae,p as Q,b as oe,v as le,_ as re,I as ce,a0 as K,d as de,C as me,D as pe,T as ge,ax as xe,h as ue,au as be,a6 as fe,a7 as he,W as je,y as Se}from"./index-KkEaZk_x.js";import{D as ye}from"./DeleteDialog-Bx6G4tYg.js";import{N as ve}from"./index-DivwJYVl.js";import{S as Ce}from"./index-BtgIDYlZ.js";import{C as we}from"./CustomPagination-Nqk-cazM.js";import{D as Ne,C as De,P as Ie}from"./dnd.esm-MbzDj5Vw.js";import{D as Le}from"./DynamicCarousel-DlRR4Dcm.js";import{N as Ae}from"./NoteComponent-CepPlIts.js";import{B as ke}from"./index-D-Sl_dAm.js";import{S as q}from"./ShowHideToggle-DRXWoIR0.js";import"./Styled-PageBanner-BV1wktGo.js";const V=Z.div`
  // .clients hr:last-child {
  //   display: none;
  // }
  .clientAvatar img {
    width: 100px;
    height: 100px;
    object-fit: contain;
  }
 
  .clientFrontend  {
    // border-radius: 10px;
    
    .details p {
      margin: 0px
    }

    &.overlayContainer {
      //background: ${({theme:i})=>i.primaryColor};
      border: 1px solid ${({theme:i})=>i.gray999};
      border-radius: 2px;
      position: relative;
      // width: 50%;
      // max-width: 300px;
      min-height: 200px;
    }
    
    /* Make the image to responsive */
    .image {
      display: block;
      // width: 100%;
      // height: auto;
    }
  
    .overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      background: rgb(0, 0, 0);
      background: rgba(0, 0, 0, .8); /* Black see-through */
      color: #f1f1f1;
      width: 100%;
      transition: .5s ease;
      opacity:0;
      color: white;
      font-size: 20px;
      padding: 20px;
      // border-radius: 10px;
      height: 100%;
      max-height: 250px;
      overflow-y: auto;
      visibility: visible !important;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;


      &::before {
        font-size: 3rem;
        position: sticky;
        right: 15px !important;
        top: -10px;
        color: rgba(255, 165, 0, .8);  
        display: block;
        width: 100%;  
      }

      &::-webkit-scrollbar {
        width: 8px;
      }
      
      &::-webkit-scrollbar-track {
          -webkit-box-shadow: inset 0 0 6px rgba(225,242,253,0.3); 
          border-radius: 3px;
      }
      
      &::-webkit-scrollbar-thumb {
          border-radius: 10px;
          -webkit-box-shadow: inset 0 0 6px rgba(232,252,187,0.5); 
      }
      
    }

    p {
      font-size: .9rem;
      margin: 5px 0 !important;
      font-family: poppins
    }
  
    &.overlayContainer:hover .overlay {
      opacity: 1;
    }
  }

  .clientAdmin .details {
    display: flex;
    flex-direction: row;
    gap: 15px;
    flex-wrap: wrap;
  }
  
`,Te=({clientsList:i,setClientsList:m,deleteAboutSection:a,editHandler:p})=>{const{isLoading:s}=G(o=>o.loader),[c,f]=r.useState(!1),[x,v]=r.useState(null),C=async o=>{const{source:d,destination:l}=o;if(!l)return!0;const u=ne(i,d.index,l.index),N=ie(u,"client_position"),y=await w(N);y.length>0&&m(y)},w=async o=>{var d;try{let l=await Q.put("/client/updateindex/",o);if((d=l==null?void 0:l.data)!=null&&d.clientLogo)return l.data.clientLogo}catch{console.log("unable to save clinet position")}},S=o=>{const d=i.find(l=>l.id===o.id);console.log(d,"Client item"),f(!c),v(d)},h=()=>{f(!c)};return e.jsxs("div",{children:[e.jsx(V,{children:e.jsxs("div",{className:"clients my-5",children:[s&&e.jsx("div",{className:"",children:[1,2,3,4].map((o,d)=>e.jsx("div",{className:"col-12",children:e.jsx(ee,{})},d))}),e.jsx(Ne,{onDragEnd:C,children:e.jsx(De,{droppableId:"clientList",id:"clientList",children:(o,d)=>e.jsxs("div",{className:"row",ref:o.innerRef,...o.droppableProps,children:[(i==null?void 0:i.length)>0?i.map((l,u)=>e.jsx(Ee,{item:l,index:u,editHandler:p,deleteAboutSection:a,clientThumbHandler:S},u)):e.jsx("div",{className:"text-center text-muted py-5",children:!s&&e.jsx("p",{children:"Please add page contents..."})}),o.placeholder]})})})]})}),c&&e.jsx(Le,{obj:x,all:i,closeCarousel:h}),c&&e.jsx(te,{closeModel:h})]})},Ee=({item:i,index:m,editHandler:a,deleteAboutSection:p,clientThumbHandler:s})=>{const{isAdmin:c,hasPermission:f}=J();return e.jsx(Ie,{isDragDisabled:!c,draggableId:i.id,index:m,id:i.id,children:x=>e.jsx("div",{className:`${c?"col-12 clientAdmin":"col-md-3 clientFrontend "} image`,ref:x.innerRef,...x.draggableProps,...x.dragHandleProps,children:e.jsxs("div",{className:`mb-3 ${c?"border border-warning mb-3 position-relative":"clientFrontend overlayContainer p-3 d-flex justify-content-center aling-items-center flex-column"} ${m%2===0?"normalCSS":"flipCSS"}`,children:[c&&f&&e.jsxs(e.Fragment,{children:[e.jsx(A,{editHandler:()=>a("editSection",!0,i),editlabel:"Clients"}),e.jsx(se,{className:"deleteSection",onClick:()=>p(i),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsx("div",{className:`${c?"d-md-flex p-3":"d-flex justify-content-center align-items-center flex-column"}`,children:e.jsx("div",{className:"text-center clientAvatar",children:e.jsx("img",{src:ae(i.path),alt:"",className:"img-fluid  mb-3",onClick:()=>s(i)})})})]},i.id)})},i.id)},Je=()=>{var P,R,B,U,$,_,M,O;const i={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},m="clients",{isAdmin:a,hasPermission:p}=J(),[s,c]=r.useState(i),[f,x]=r.useState([]),[v,C]=r.useState(!1),[w,S]=r.useState({}),[h,o]=r.useState({}),[d,l]=r.useState(!1),[u,N]=r.useState(""),[y,k]=r.useState(1),D=t=>{var b;if(((b=t==null?void 0:t.results)==null?void 0:b.length)>0){const g=ue(t.results,"client_position");x(g),o(be(t)),k(1)}else x(t.clientLogo)};r.useEffect(()=>{(!s.addSection||!s.editSection)&&!u&&T()},[s.addSection,s.editSection]);const T=async()=>{try{const t=await oe.get("/client/getAllClientLogos/");(t==null?void 0:t.status)===200&&D(t.data)}catch{console.log("unable to access ulr because of server is down")}};r.useEffect(()=>{const t=document.getElementById("KnowledgeHubnavbarDropdown");t&&t.classList.add("active")});const j=(t,b,g)=>{c(L=>({...L,[t]:b})),C(!v),g!=null&&g.id?S(g):S({}),document.body.style.overflow="hidden"},W=t=>{const b=t.id,g=t.client_title,L=async()=>{if((await Q.delete(`/client/updateClientLogo/${b}/`)).status===204){const X=f.filter(Y=>Y.id!==b);x(X),Se.success(`${g} is deleted`)}};je.confirmAlert({customUI:({onClose:z})=>e.jsx(ye,{onClose:z,callback:L,message:e.jsxs(e.Fragment,{children:["Confirm deletion of ",e.jsx("span",{children:g})," service?"]})})})},[n,H]=r.useState([]),E=le(),{error:Fe,success:Pe,showHideList:I}=G(t=>t.showHide);r.useEffect(()=>{I.length>0&&H(re(I))},[I]);const F=async(t,b)=>{if(t)E(fe(t));else{const g={componentName:b.toLowerCase(),pageType:m};E(he(g))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:(P=n==null?void 0:n.clientlistbanner)!=null&&P.visibility&&a&&p?"border border-info mb-2":"",children:[a&&p&&e.jsx(q,{showhideStatus:(R=n==null?void 0:n.clientlistbanner)==null?void 0:R.visibility,title:"Banner",componentName:"clientlistbanner",showHideHandler:F,id:(B=n==null?void 0:n.clientlistbanner)==null?void 0:B.id}),((U=n==null?void 0:n.clientlistbanner)==null?void 0:U.visibility)&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[a&&p&&e.jsx(A,{editHandler:()=>j("banner",!0)}),e.jsx(ke,{getBannerAPIURL:`banner/clientBannerIntro/${m}-banner/`,bannerState:s.banner})]}),s.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ce,{editHandler:j,componentType:"banner",popupTitle:"Client List Banner",pageType:`${m}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:de(`${m}-banner`),dimensions:K("banner")})})]})]}),e.jsxs("div",{className:($=n==null?void 0:n.clientsbriefintro)!=null&&$.visibility&&a&&p?"border border-info mb-2":"",children:[a&&p&&e.jsx(q,{showhideStatus:(_=n==null?void 0:n.clientsbriefintro)==null?void 0:_.visibility,title:"A Brief Introduction Component",componentName:"clientsbriefintro",showHideHandler:F,id:(M=n==null?void 0:n.clientsbriefintro)==null?void 0:M.id}),((O=n==null?void 0:n.clientsbriefintro)==null?void 0:O.visibility)&&e.jsxs("div",{children:[a&&p&&e.jsx(A,{editHandler:()=>j("briefIntro",!0)}),e.jsx(me,{introState:s.briefIntro,pageType:m,introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center"}),s.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(pe,{editHandler:j,popupTitle:"Client list",componentType:"briefIntro",pageType:m})})]})]}),e.jsxs("div",{className:"container-fluid container-lg my-md-5 ",children:[e.jsx("div",{className:"row",children:a&&p&&e.jsx("div",{className:"col-md-12",children:e.jsx("div",{className:"d-flex justify-content-end align-items-center mb-3",children:e.jsxs("button",{type:"submit",className:"btn btn-primary px-3",onClick:()=>j("addSection",!0,{}),children:["Add New Client"," ",e.jsx("i",{className:"fa fa-plus ms-2","aria-hidden":"true"})]})})})}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6 fs-3 mt-4 mt-md-0",children:e.jsx(ge,{title:"Clients",cssClass:"fs-1 pageTitle"})}),e.jsx("div",{className:"col-md-6",children:e.jsx(Ce,{setObject:D,clientSearchURL:"/client/searchClientLogos/",adminSearchURL:"/client/createClientLogo/",clientDefaultURL:"/client/getAllClientLogos/",searchfiledDeatails:"client Title",setPageloadResults:l,setSearchquery:N,searchQuery:u,addStateChanges:s.addSection,editStateChanges:!s.editSection})})]}),s.editSection||s.addSection?e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(ve,{editHandler:j,category:"about",popupTitle:"Client",editCarousel:w,setEditCarousel:S,componentType:`${s.editSection?"editSection":"addSection"}`,imageGetURL:"client/createClientLogo/",imagePostURL:"client/createClientLogo/",imageUpdateURL:"client/updateClientLogo/",imageDeleteURL:"client/updateClientLogo/",imageLabel:"Add Client Logo",showDescription:!1,showExtraFormFields:xe(),dimensions:K("aboutus"),scrollEnable:!1})}):"",e.jsx("br",{}),a&&e.jsx(Ae,{note:"Use drag option to shuffle the Items"}),e.jsx(V,{children:e.jsx(Te,{clientsList:f,setClientsList:x,deleteAboutSection:W,editHandler:j,getClinetDetails:T})}),h!=null&&h.total_count?e.jsx(we,{paginationData:h,paginationURL:a?"/client/createClientLogo/":"/client/getAllClientLogos/",paginationSearchURL:u?`/client/searchClientLogos/${u}/`:a?"/client/createClientLogo/":"/client/getAllClientLogos/",searchQuery:u,setCurrentPage:k,currentPage:y,setResponseData:D,pageLoadResult:d}):""]})]})};export{Je as default};
