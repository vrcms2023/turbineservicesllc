import{k as Y,f as F,j as e,Y as Z,Z as W,e as $,E as L,L as X,d as ee,T as B,R as te,w as U,r as a,b as ie,A as se,O as ne,n as ae,a6 as oe,Q as re,S as le,y as ce}from"./index-DBsTX-kM.js";import{g as de,B as me,a as pe}from"./index-BYylpvxO.js";import{B as ge,I as fe}from"./index-CAj6khZB.js";import{i as P,g as xe,j as ue}from"./dynamicFormFields-p6VsA-z_.js";import{l as he}from"./DeleteDialog-D7NPAGRh.js";import{D as be}from"./DeleteDialog-C-UZTB6T.js";import{N as je}from"./index-DE0Cv6UC.js";import{S as Se}from"./index-Cwm_DpLA.js";import{C as ye}from"./CustomPagination-Hj3RTKJt.js";import{S as Ce}from"./SkeletonImage-kb66WsZN.js";import{D as we,C as ve,P as Le}from"./dnd.esm-CyBePkp5.js";import{N as Ne}from"./NoteComponent-DdH-dHGZ.js";import{S as De}from"./ShowHideToggle-CxswGZkb.js";import"./Ancher-ZqEQPHSC.js";import"./FileUpload-jOQ2j5TG.js";import"./Error-CoyZw7DD.js";const _=Y.div`
  // .clients hr:last-child {
  //   display: none;
  // }
  .clientAvatar img {
    width: 100px;
    height: 100px;
    object-fit: contain;
  }
 
  .clientFrontend  {
    // border-radius: 10px;
    
    .details p {
      margin: 0px
    }

    &.overlayContainer {
      //background: ${({theme:s})=>s.primaryColor};
      border: 1px solid ${({theme:s})=>s.gray999};
      border-radius: 2px;
      position: relative;
      // width: 50%;
      // max-width: 300px;
      min-height: 200px;
    }
    
    /* Make the image to responsive */
    .image {
      display: block;
      // width: 100%;
      // height: auto;
    }
  
    .overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      background: rgb(0, 0, 0);
      background: rgba(0, 0, 0, .8); /* Black see-through */
      color: #f1f1f1;
      width: 100%;
      transition: .5s ease;
      opacity:0;
      color: white;
      font-size: 20px;
      padding: 20px;
      // border-radius: 10px;
      height: 100%;
      max-height: 250px;
      overflow-y: auto;
      visibility: visible !important;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;


      &::before {
        font-size: 3rem;
        position: sticky;
        right: 15px !important;
        top: -10px;
        color: rgba(255, 165, 0, .8);  
        display: block;
        width: 100%;  
      }

      &::-webkit-scrollbar {
        width: 8px;
      }
      
      &::-webkit-scrollbar-track {
          -webkit-box-shadow: inset 0 0 6px rgba(225,242,253,0.3); 
          border-radius: 3px;
      }
      
      &::-webkit-scrollbar-thumb {
          border-radius: 10px;
          -webkit-box-shadow: inset 0 0 6px rgba(232,252,187,0.5); 
      }
      
    }

    p {
      font-size: .9rem;
      margin: 5px 0 !important;
      font-family: poppins
    }
  
    &.overlayContainer:hover .overlay {
      opacity: 1;
    }
  }

  .clientAdmin .details {
    display: flex;
    flex-direction: row;
    gap: 15px;
    flex-wrap: wrap;
  }
  
`,Ie=({clientsList:s,setClientsList:c,deleteAboutSection:o,editHandler:m})=>{const{isLoading:i}=F(n=>n.loader),b=async n=>{const{source:p,destination:r}=n;if(!r)return!0;const h=Z(s,p.index,r.index),j=W(h,"client_position"),x=await f(j);x.length>0&&c(x)},f=async n=>{var p;try{let r=await U.put("/client/updateindex/",n);if((p=r==null?void 0:r.data)!=null&&p.clientLogo)return r.data.clientLogo}catch{console.log("unable to save clinet position")}};return e.jsx("div",{children:e.jsx(_,{children:e.jsxs("div",{className:"clients my-5",children:[i&&e.jsx("div",{className:"",children:[1,2,3,4].map((n,p)=>e.jsx("div",{className:"col-12",children:e.jsx(Ce,{})},p))}),e.jsx(we,{onDragEnd:b,children:e.jsx(ve,{droppableId:"clientList",id:"clientList",children:(n,p)=>e.jsxs("div",{className:"row",ref:n.innerRef,...n.droppableProps,children:[(s==null?void 0:s.length)>0?s.map((r,h)=>e.jsx(Ae,{item:r,index:h,editHandler:m,deleteAboutSection:o},h)):e.jsx("div",{className:"text-center text-muted py-5",children:!i&&e.jsx("p",{children:"Please add page contents..."})}),n.placeholder]})})})]})})})},Ae=({item:s,index:c,editHandler:o,deleteAboutSection:m})=>{const{isAdmin:i,hasPermission:b}=$();return e.jsx(Le,{isDragDisabled:!i,draggableId:s.id,index:c,id:s.id,children:f=>e.jsx("div",{className:`${i?"col-12 clientAdmin":"col-md-3 clientFrontend "} image`,ref:f.innerRef,...f.draggableProps,...f.dragHandleProps,children:e.jsxs("div",{className:`mb-3 ${i?"border border-warning mb-3 position-relative":"clientFrontend overlayContainer p-3 d-flex justify-content-center aling-items-center flex-column"} ${c%2===0?"normalCSS":"flipCSS"}`,children:[i&&b&&e.jsxs(e.Fragment,{children:[e.jsx(L,{editHandler:()=>o("editSection",!0,s)}),e.jsx(X,{className:"deleteSection",onClick:()=>m(s),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsxs("div",{className:`${i?"d-md-flex p-3":""}`,children:[e.jsx("div",{className:"text-center clientAvatar",children:e.jsx("img",{src:ee(s.path),alt:"",className:"img-fluid shadow img-thumbnail"})}),e.jsxs("div",{className:"mt-3 d-flex justify-content-center align-items-center justify-content-md-center align-items-md-center flex-column  clientDetails ms-3",children:[s.client_title&&e.jsx(B,{title:s.client_title,cssClass:"fs-5 mb-2 text-center"}),e.jsx(te,{data:s.client_description,className:`details ${i?"":"overlay fa fa-map-marker"}`})]})]})]},s.id)})},s.id)},Me=()=>{var A,k,E,T;const s={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},c="clients",{isAdmin:o,hasPermission:m}=$(),[i,b]=a.useState(s),[f,n]=a.useState([]),[p,r]=a.useState(!1),[h,j]=a.useState({}),[x,H]=a.useState({}),[O,z]=a.useState(!1),[S,K]=a.useState(""),[Q,N]=a.useState(1),C=t=>{var g;if(((g=t==null?void 0:t.results)==null?void 0:g.length)>0){const d=ae(t.results,"client_position");n(d),H(oe(t)),N(1)}else n(t.clientLogo)};a.useEffect(()=>{(!i.addSection||!i.editSection)&&!S&&D()},[i.addSection,i.editSection]);const D=async()=>{try{const t=await ie.get("/client/getAllClientLogos/");(t==null?void 0:t.status)===200&&C(t.data)}catch{console.log("unable to access ulr because of server is down")}};a.useEffect(()=>{const t=document.getElementById("KnowledgeHubnavbarDropdown");t&&t.classList.add("active")});const u=(t,g,d)=>{b(v=>({...v,[t]:g})),r(!p),d!=null&&d.id?j(d):j({}),document.body.style.overflow="hidden"},q=t=>{const g=t.id,d=t.client_title,v=async()=>{if((await U.delete(`/client/updateClientLogo/${g}/`)).status===204){const M=f.filter(V=>V.id!==g);n(M),ce.success(`${d} is deleted`)}};he.confirmAlert({customUI:({onClose:R})=>e.jsx(be,{onClose:R,callback:v,message:`deleting the ${d} Service?`})})},[l,G]=a.useState([]),I=a.useRef(!0),w=se(),{error:ke,success:Ee,showHideList:y}=F(t=>t.showHide);a.useEffect(()=>{y.length>0&&G(de(y))},[y]),a.useEffect(()=>{y.length===0&&I.current&&(w(ne()),I.current=!1)},[y]);const J=async(t,g)=>{if(t)w(re(t));else{const d={componentName:g.toLowerCase(),pageType:c};w(le(d))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[o&&m&&e.jsx(L,{editHandler:()=>u("banner",!0)}),e.jsx(ge,{getBannerAPIURL:`banner/clientBannerIntro/${c}-banner/`,bannerState:i.banner})]}),i.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(fe,{editHandler:u,componentType:"banner",popupTitle:"Client List Banner",pageType:`${c}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:xe(`${c}-banner`),dimensions:P("banner")})}),e.jsxs("div",{className:(A=l==null?void 0:l.clientsbriefintro)!=null&&A.visibility&&o&&m?"border border-info mb-2":"",children:[o&&m&&e.jsx(De,{showhideStatus:(k=l==null?void 0:l.clientsbriefintro)==null?void 0:k.visibility,title:"A Brief Introduction Component",componentName:"clientsbriefintro",showHideHandler:J,id:(E=l==null?void 0:l.clientsbriefintro)==null?void 0:E.id}),((T=l==null?void 0:l.clientsbriefintro)==null?void 0:T.visibility)&&e.jsxs("div",{children:[o&&m&&e.jsx(L,{editHandler:()=>u("briefIntro",!0)}),e.jsx(me,{introState:i.briefIntro,pageType:c,introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center"}),i.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(pe,{editHandler:u,popupTitle:"Client list",componentType:"briefIntro",pageType:c})})]})]}),e.jsxs("div",{className:"container-fluid container-lg my-md-5 ",children:[e.jsx("div",{className:"row",children:o&&m&&e.jsx("div",{className:"col-md-12",children:e.jsx("div",{className:"d-flex justify-content-end align-items-center mb-3",children:e.jsxs("button",{type:"submit",className:"btn btn-primary px-3",onClick:()=>u("addSection",!0,{}),children:["Add New Client"," ",e.jsx("i",{className:"fa fa-plus ms-2","aria-hidden":"true"})]})})})}),e.jsxs("div",{className:"row",children:[e.jsx("div",{className:"col-md-6 fs-3 mt-4 mt-md-0",children:e.jsx(B,{title:"Clients",cssClass:"fs-1 pageTitle"})}),e.jsx("div",{className:"col-md-6",children:e.jsx(Se,{setObject:C,clientSearchURL:"/client/searchClientLogos/",adminSearchURL:"/client/createClientLogo/",clientDefaultURL:"/client/getAllClientLogos/",searchfiledDeatails:"client Title / client description ",setPageloadResults:z,setSearchquery:K,searchQuery:S,addStateChanges:i.addSection,editStateChanges:!i.editSection})})]}),i.editSection||i.addSection?e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(je,{editHandler:u,category:"about",popupTitle:"Client",editCarousel:h,setEditCarousel:j,componentType:`${i.editSection?"editSection":"addSection"}`,imageGetURL:"client/createClientLogo/",imagePostURL:"client/createClientLogo/",imageUpdateURL:"client/updateClientLogo/",imageDeleteURL:"client/updateClientLogo/",imageLabel:"Add Client Logo",showDescription:!1,showExtraFormFields:ue(),dimensions:P("aboutus"),scrollEnable:!1})}):"",e.jsx("br",{}),o&&e.jsx(Ne,{note:"Use drag option to shuffle the Items"}),e.jsx(_,{children:e.jsx(Ie,{clientsList:f,setClientsList:n,deleteAboutSection:q,editHandler:u,getClinetDetails:D})}),x!=null&&x.total_count?e.jsx(ye,{paginationData:x,paginationURL:o?"/client/createClientLogo/":"/client/getAllClientLogos/",paginationSearchURL:S?`/client/searchClientLogos/${S}/`:o?"/client/createClientLogo/":"/client/getAllClientLogos/",searchQuery:S,setCurrentPage:N,currentPage:Q,setResponseData:C,pageLoadResult:O}):""]})]})};export{Me as default};
