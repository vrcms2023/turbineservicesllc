import{k as Z,e as E,r as i,a as G,A as W,f as X,O as ee,j as e,E as T,L as d,T as O,M as te,b as ae,Q as se,S as re,l as ne,n as ie,a6 as oe,Y as le,Z as ce,d as me,R as de,w as R,y as ue}from"./index-B1-fbhTW.js";import{B as pe,I as fe}from"./index-DBQ5LthW.js";import{i as A,g as be,k as xe}from"./dynamicFormFields-p6VsA-z_.js";import{g as he,B as ge,a as je}from"./index-xVPY_hgB.js";import{N as Se}from"./index-C6Mo69rr.js";import{l as _e}from"./DeleteDialog-BPXCEzTV.js";import{D as we}from"./DeleteDialog-CxCWxmD0.js";import{S as ye}from"./index-r243oRVU.js";import{C as Ne}from"./CustomPagination-jQEPZ6Ar.js";import{D as ve,C as Te,P as Ce}from"./dnd.esm-D8WMKIXB.js";import{S as De}from"./ShowHideToggle-Bza_caTZ.js";import"./FileUpload-BBmeDerb.js";import"./Error-DZroW8UZ.js";import"./SkeletonImage-O3Q-g6Yp.js";import"./Ancher-_PdOlk3g.js";const ke=Z.div`
  background-color: ${({theme:t})=>t.transparent};

  .editIcon {
    top: 10px;
  }

  .title {
    color: ${({theme:t})=>t.teamTitleColor};
    font-weight: 500;
    font-size: 1.1rem;
  }


  // a {
  //   color: ${({theme:t})=>t.teamLinkColor};
  // }

  // .social {
  // border-top: 1px solid ${({theme:t})=>t.graye6};
  // }

  .social i {
    color: ${({theme:t})=>t.secondaryColor};

    font-size: 1.6rem;
    margin: 7px;
  }

  img {
    object-fit: contain;
    object-position: top;
    height: auto;
    max-height: 300px;
    width: 100%;
  }

  .aboutMe {
  }
  
  .ql-editor {
    padding: 0
  }

  .memberCard {
    background-color: ${({theme:t})=>t.white};
    // border:1px solid ${({theme:t})=>t.secondaryColor};
    border-radius: 5px;
    margin: 15px 0;
    overflow: hidden;

    .memberDetails {
      color: ${({theme:t})=>t.teamTextColor};

      small {
        font-size: 0.7rem;
        text-transform: uppercase;
        color: ${({theme:t})=>t.clientColor};
      }

      .strengths {
  //       display: -webkit-box;
  // -webkit-line-clamp: 4;
  // -webkit-box-orient: vertical;  
  // overflow: hidden;

  @media(max-width: 480px) {
    -webkit-line-clamp: none;
  }
        // p:before {
        //   content: "⬦  ";
        //   font-size: 16px;
        // }
        // p {
        //   margin-left: 10px;
        //   margin-bottom: 0px;
        // }
      }
    }
  }
`,Qe=()=>{var k,I,L,P;const t={banner:!1,briefIntro:!1,addSection:!1,editSection:!1},m="teams",{isAdmin:c,hasPermission:u}=E(),[n,w]=i.useState(t),[f,U]=i.useState(!1),[h,g]=i.useState([]),[j,y]=i.useState({}),[S,B]=i.useState({}),[F,H]=i.useState(!1),[b,V]=i.useState(""),[M,C]=i.useState(1),p=(a,r,s)=>{w(l=>({...l,[a]:r})),U(!f),s!=null&&s.id?y(s):y({}),document.body.style.overflow="hidden"},N=a=>{var r;if(((r=a==null?void 0:a.results)==null?void 0:r.length)>0){const s=ne(a.results[0]),l=ie(a.results,s);g(l),B(oe(a)),C(1)}else g([])};i.useEffect(()=>{const a=async()=>{try{const r=await ae.get("/ourteam/clentViewOurTeamDetails/");(r==null?void 0:r.status)===200&&N(r.data)}catch{console.log("unable to access ulr because of server is down")}};(!n.addSection||!n.editSection)&&!b&&a()},[n.addSection,n.editSection]);const q=a=>{const r=a.id,s=a.team_member_name,l=async()=>{if((await R.delete(`/ourteam/UpdateOurteamDetail/${r}/`)).status===204){const $=h.filter(Y=>Y.id!==r);g($),ue.success(`${s} is deleted`)}};_e.confirmAlert({customUI:({onClose:_})=>e.jsx(we,{onClose:_,callback:l,message:`deleting the ${s} Service?`})})};i.useEffect(()=>{G()},[]);const z=async a=>{const{source:r,destination:s}=a;if(!s)return!0;const l=le(h,r.index,s.index),_=ce(l,"team_member_position");(await K(_)).length>0&&g(l)},K=async a=>{var r;try{let s=await R.put("/ourteam/updateTeamindex/",a);if((r=s==null?void 0:s.data)!=null&&r.team)return s.data.team}catch{console.log("unable to save clinet position")}},[o,Q]=i.useState([]),D=i.useRef(!0),v=W(),{error:Le,showHideList:x}=X(a=>a.showHide);i.useEffect(()=>{x.length>0&&Q(he(x))},[x]),i.useEffect(()=>{x.length===0&&D.current&&(v(ee()),D.current=!1)},[x]);const J=async(a,r)=>{if(a)v(se(a));else{const s={componentName:r.toLowerCase(),pageType:m};v(re(s))}};return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"position-relative",children:[c&&u&&e.jsx(T,{editHandler:()=>p("banner",!0)}),e.jsx(pe,{getBannerAPIURL:`banner/clientBannerIntro/${m}-banner/`,bannerState:n.banner})]}),n.banner&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(fe,{editHandler:p,componentType:"banner",popupTitle:"Team Banner",pageType:`${m}-banner`,imageLabel:"Banner Image",showDescription:!1,showExtraFormFields:be(`${m}-banner`),dimensions:A("banner")})}),e.jsxs("div",{className:(k=o==null?void 0:o.teambriefintro)!=null&&k.visibility&&c&&u?"border border-info mb-2":"",children:[c&&u&&e.jsx(De,{showhideStatus:(I=o==null?void 0:o.teambriefintro)==null?void 0:I.visibility,title:"A Brief Introduction Component",componentName:"teambriefintro",showHideHandler:J,id:(L=o==null?void 0:o.teambriefintro)==null?void 0:L.id}),((P=o==null?void 0:o.teambriefintro)==null?void 0:P.visibility)&&e.jsxs("div",{children:[c&&u&&e.jsx(T,{editHandler:()=>p("briefIntro",!0)}),e.jsx(ge,{introState:n.briefIntro,linkCss:"btn btn-outline d-flex justify-content-center align-items-center",linkLabel:"Read More",moreLink:"",showLink:!1,introTitleCss:"fs-3 fw-medium text-md-center",introSubTitleCss:"fw-medium text-muted text-md-center",introDecTitleCss:"fs-6 fw-normal w-75 m-auto text-md-center",detailsContainerCss:"col-md-10 offset-md-1",anchorContainer:"d-flex justify-content-start align-items-start mt-4",anchersvgColor:"#17427C",pageType:m}),n.briefIntro&&e.jsx("div",{className:"adminEditTestmonial selected ",children:e.jsx(je,{editHandler:p,componentType:"briefIntro",popupTitle:"Team Brief",pageType:m})})]})]}),e.jsxs("div",{className:"container",children:[e.jsx("div",{className:"row",children:e.jsx("div",{className:"col-md-12 mt-4",children:c&&u&&e.jsx("div",{className:"text-end mb-4",children:e.jsxs(d,{to:"#",className:"btn btn-primary",onClick:()=>p("addSection",!0),children:["Add team",e.jsx("i",{className:"fa fa-plus ms-2","aria-hidden":"true"})]})})})}),e.jsxs("div",{className:"row mb-0 py-2 py-md-4",children:[e.jsx("div",{className:"col-md-6 fs-3 mt-4 mt-md-0",children:e.jsx(O,{title:"Our Team",cssClass:"fs-1 pageTitle"})}),e.jsx("div",{className:"col-md-6 mb-4",children:e.jsx(ye,{setObject:N,clientSearchURL:"/ourteam/OurteamSearchAPIView/",adminSearchURL:"/ourteam/createteam/",clientDefaultURL:"/ourteam/clentViewOurTeamDetails/",searchfiledDeatails:"Name",setPageloadResults:H,setSearchquery:V,searchQuery:b,addStateChanges:n.addSection,editStateChanges:!n.editSection})})]}),n.editSection||n.addSection?e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(Se,{editHandler:p,category:"team",popupTitle:"Team",editCarousel:j,setEditCarousel:y,componentType:`${n.editSection?"editSection":"addSection"}`,getImageListURL:"ourteam/createteam/",deleteImageURL:"ourteam/UpdateOurteamDetail/",imagePostURL:"ourteam/createteam/",imageUpdateURL:"ourteam/UpdateOurteamDetail/",imageLabel:"Add Profile Image",showDescription:!1,showExtraFormFields:xe(j==null?void 0:j.team_member_position),dimensions:A("teams")})}):"",e.jsx(ke,{children:e.jsx("div",{className:`${c?"":"teamFrontend"}`,children:e.jsx(ve,{onDragEnd:z,children:e.jsx(Te,{droppableId:"teamList",id:"teamList",children:(a,r)=>e.jsxs("div",{className:"row",ref:a.innerRef,...a.droppableProps,children:[h.length>0?h.map((s,l)=>e.jsx(Ie,{item:s,index:l,editHandler:p,deleteAboutSection:q},l)):e.jsx("p",{className:"text-center text-muted py-5",children:"Please add page contents..."}),a.placeholder]})})})})}),e.jsx("div",{className:"row my-5",children:(S==null?void 0:S.total_count)&&e.jsx(Ne,{paginationData:S,paginationURL:c?"/ourteam/createteam/":"/clieourteamnt/clentViewOurTeamDetails/",paginationSearchURL:b?`/ourteam/OurteamSearchAPIView/${b}/`:c?"/ourteam/createteam/":"/ourteam/clentViewOurTeamDetails/",searchQuery:b,setCurrentPage:C,currentPage:M,setResponseData:N,pageLoadResult:F})})]}),f&&e.jsx(te,{})]})},Ie=({item:t,index:m,deleteAboutSection:c,editHandler:u})=>{const{isAdmin:n,hasPermission:w}=E();return e.jsx(Ce,{isDragDisabled:!n,draggableId:t.id,index:m,id:t.id,children:f=>e.jsx("div",{className:"col-md-6 col-lg-4 px-4 px-md-3",ref:f.innerRef,...f.draggableProps,...f.dragHandleProps,children:e.jsxs("div",{className:`mx-md-1 mx-lg-1 memberCard border shadow-sm ${n?"border border-warning position-relative":""} ${m%2===0?"normalCSS":"flipCSS"}`,children:[n&&w&&e.jsxs(e.Fragment,{children:[e.jsx(T,{editHandler:()=>u("editSection",!0,t)}),e.jsx(d,{className:"deleteSection",onClick:()=>c(t),children:e.jsx("i",{className:"fa fa-trash-o text-danger fs-4","aria-hidden":"true"})})]}),e.jsx("div",{className:"text-center p-3",children:e.jsx("img",{src:me(t.path),className:"rounded rounded-1 mt-2 ",alt:""})}),e.jsxs("div",{className:" text-start py-2 p-4 memberDetails",children:[t.team_member_designation&&e.jsx("small",{className:"mb-1 fw-bold",children:t.team_member_designation}),t.team_member_name&&e.jsx(O,{title:t.team_member_name,cssClass:"fs-4 title "}),t.team_member_about_us&&e.jsx(de,{data:t.team_member_about_us,className:"strengths"}),t.team_member_email&&e.jsx("div",{className:"mt-3",children:e.jsx("a",{href:`mailto:${t.team_member_email}`,children:t.team_member_email})}),t.team_member_phone_number&&e.jsx("p",{children:t.team_member_phone_number}),e.jsxs("div",{className:"social",children:[t.facebook_url&&e.jsx(d,{to:t.facebook_url,target:"_blank",children:e.jsx("i",{className:"fa fa-facebook-square","aria-hidden":"true"})}),t.twitter_url&&e.jsx(d,{to:t.twitter_url,target:"_blank",children:e.jsx("i",{className:"fa fa-twitter-square","aria-hidden":"true"})}),t.youtube_url&&e.jsx(d,{to:t.youtube_url,target:"_blank",children:e.jsx("i",{className:"fa fa-youtube-play","aria-hidden":"true"})}),t.linkedIn_url&&e.jsx(d,{to:t.linkedIn_url,target:"_blank",children:e.jsx("i",{className:"fa fa-linkedin-square","aria-hidden":"true"})}),t.instagram_url&&e.jsx(d,{to:t.instagram_url,target:"_blank",children:e.jsx("i",{className:"fa fa-instagram","aria-hidden":"true"})}),t.vimeo_url&&e.jsx(d,{to:t.vimeo_url,target:"_blank",children:e.jsx("i",{className:"fa fa-vimeo","aria-hidden":"true"})}),t.pinterest_url&&e.jsx(d,{to:t.pinterest_url,target:"_blank",children:e.jsx("i",{className:"fa fa-pinterest","aria-hidden":"true"})})]})]})]},t.id)})},t.id)};export{Qe as default};
