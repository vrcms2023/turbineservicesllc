import{k as L,j as e,T as w,o as k,O as c,K as v,av as B,b as S,y as j,u as C,r as p,g as T,E as O,A as _,I as M,d as $,M as q,e as W}from"./index-KkEaZk_x.js";const H=({categoryId:a})=>{var h,n,l,d;const{register:i,reset:u,handleSubmit:x,formState:{errors:t}}=L({}),o=async m=>{m.categoryId=a||"";try{(await S.post("/contactus/",{...m})).status===201?(j.success("Your request is submit succuessfully"),u()):j.error("unable to process your request")}catch{j.error("unable to process your request")}};return e.jsxs(e.Fragment,{children:[e.jsx("small",{children:"SEND US EMAIL"}),e.jsx(w,{title:"Feel free to write",cssClass:"fs-4 mb-3 formTitle"}),e.jsxs("form",{className:"my-0 mx-auto contactForm",onSubmit:x(o),children:[e.jsx(k,{label:"Name",fieldName:"firstName",register:i,validationObject:c.firstName,error:(h=t==null?void 0:t.firstName)==null?void 0:h.message}),e.jsx(v,{label:"Email",fieldName:"email",register:i,validationObject:c.email,error:(n=t==null?void 0:t.email)==null?void 0:n.message}),e.jsx(v,{label:"Phone",fieldName:"phoneNumber",register:i,validationObject:c.phoneNumber,error:(l=t==null?void 0:t.phoneNumber)==null?void 0:l.message}),e.jsx(B,{label:"Message",fieldName:"description",register:i,validationObject:c.description,error:(d=t==null?void 0:t.description)==null?void 0:d.message}),e.jsx("div",{className:"mb-3 row",children:e.jsx("div",{className:"col-sm-12 mt-2",children:e.jsx("button",{type:"submit",className:"btn btn-primary",children:"Send Request"})})})]})]})},R=({cssClass:a,col1:i,col2:u,imageClass:x,dimensions:t,pageType:o="HomeWhoWeAre",componentFlip:h=!1,showForm:n=!1,categoryId:l})=>{const d={whoweare:!1},{isAdmin:m,hasPermission:b}=C(),[g,A]=p.useState(d),[y,F]=p.useState(!1),[s,E]=p.useState(""),N=(f,r)=>{A(I=>({...I,[f]:r})),F(!y),document.body.style.overflow="hidden"};return p.useEffect(()=>{const f=async()=>{try{const r=await S.get(`banner/clientBannerIntro/${o}/`);(r==null?void 0:r.status)===200&&E(r.data.imageModel)}catch{console.log("unable to access ulr because of server is down")}};g.whoweare||f()},[g.whoweare]),e.jsxs(e.Fragment,{children:[e.jsx("div",{className:`${i}`,children:e.jsx("img",{src:T(s==null?void 0:s.path),alt:"",className:x})}),e.jsxs("div",{className:`${u}`,children:[m&&b&&e.jsx(O,{editHandler:()=>N("whoweare",!0)}),s!=null&&s.banner_title?e.jsx(w,{title:s.banner_title,cssClass:a}):"",s.banner_subTitle?e.jsx(w,{title:s.banner_subTitle,cssClass:"fs-6 my-3"}):"",e.jsx("div",{children:e.jsx("p",{className:"lh-md",children:s!=null&&s.banner_descripiton?s.banner_descripiton:"Update description"})}),n&&e.jsx(H,{categoryId:l}),s.moreLink?e.jsx("div",{children:e.jsx(_,{AncherLabel:"more...",Ancherpath:s.moreLink?s.moreLink:"",AncherClass:"moreLink d-flex justify-content-center align-items-center gap-3",AnchersvgColor:"#ffffff"})}):""]}),g.whoweare&&e.jsx("div",{className:"adminEditTestmonial selected",children:e.jsx(M,{editHandler:N,componentType:"whoweare",pageType:o,popupTitle:"Who We Are Banner",imageLabel:"Banner Image",showDescription:!1,dimensions:t,showExtraFormFields:$(o)})}),y&&e.jsx(q,{})]})},U=W.div`
    .productForm {
        background: rgb(225,242,253);
        background: linear-gradient(90deg, rgba(225,242,253,1) 0%, rgba(255,255,255,1) 50%, rgba(225,242,253,1) 100%);
    }

    .randomServices {
        margin-top: 96px;
        margin-bottom: 96px;

        @media(max-width: 768px) {
            margin-top: 48px;
            margin-bottom: 48px;
        }

        img {
            height: 300px;
            // filter: grayscale(100%);
            transition: filter 0.3s ease-in-out, transform 0.3s ease-in-out;
            
            @media(max-width: 768px) {
                height: 200px;
            }

            &:hover {
                // filter: grayscale(0%);
                transform: scaleX(1.05);
            }
        }

        .imgStylingLeft {
            border-radius: 12px;
            // border-top-right-radius: 30px;
            // border-bottom-right-radius: 30px;

            // @media(max-width: 768px) {
            //     border-radius: 10px
            // }
        }

        .imgStylingRight {
            border-radius: 12px;
            // border-top-left-radius: 30px;
            // border-bottom-left-radius: 30px;

            // @media(max-width: 768px) {
            //     border-radius: 10px
            // }
        }
    }

    
    

    form {
        // padding: 30px 50px;
        border-radius: 15px;
        border: 1px solid ${({theme:a})=>a.lightgray};
        // background: ${({theme:a})=>a.white};

        @media(max-width: 576px) {
            padding: 30px;   
        }
    }
`;export{U as A,R as a};
